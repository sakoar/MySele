package com.bat.veo.test.Cart;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.pageObjects.sf_OrderConfirmationPage;
import com.veo.pageObjects.sf_Order_Continue_orCancel_page;
import com.veo.pageObjects.sf_ReviewOrder_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class OrderSharingByMultipleUser extends LocalTestBase {

	sf_LogIn_page logIn;
	sf_LogOut_page logOut;
	sf_HomePage home;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_Order_Continue_orCancel_page Continue;
	sf_ReviewOrder_page reviewPage;
	sf_OrderConfirmationPage confirmationPage;

 @Test(dataProvider="getTestData")
  public void OrderSharingAmongOtherUsers(
		  String country,
		  String usertype1,
		  String username1,
		  String password1,
		  String usertype2,
		  String username2,
		  String password2,
		  String usertype3,
		  String username3,
		  String password3,
		  String order_quantity) throws Exception{

	 driver.get(CONFIG.getProperty("stagging_url"));
	 
	 logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
	 OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	 Continue= PageFactory.initElements(driver, sf_Order_Continue_orCancel_page.class);
	 logOut = PageFactory.initElements(driver, sf_LogOut_page.class);
	try
	{
	 
		logIn.log_In(usertype1,username1,password1);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		prntResults("Logged in with "+username1+"/"+password1);
		prntResults("___________________________________________");

		OrderCreation.CreateOrderRetailer(driver,country);
		OrderCreation.enterQtyforRandomProduct("100");

		Thread.sleep(3000);
		logOut.logout();
		Thread.sleep(3000);
		prntResults("___________________________________________");

		logIn.log_In(usertype2,username2,password2);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		prntResults("Logged in with "+username2+"/"+password2);
		prntResults("___________________________________________");
		
		Thread.sleep(3000);
		OrderCreation.OrderSharedByMultiplierUsr();
		Thread.sleep(3000);
		logOut.logout();
		Thread.sleep(3000);
		prntResults("___________________________________________");

/*		logIn.log_In(usertype3,username3,password3);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		prntResults("Logged in with "+username3+"/"+password3);
		prntResults("___________________________________________");
		
		Thread.sleep(2000);
		OrderCreation.OrderSharedByMultiplierUsr();
		Thread.sleep(3000);
		logOut.logout();
		Thread.sleep(2000);
		prntResults("___________________________________________");*/

		logIn.log_In(usertype1,username1,password1);
		Thread.sleep(3000);
		prntResults("Logged in with "+username1+"/"+password1);
		prntResults("___________________________________________");
		
		OrderCreation.CancelOrder(driver);
		Thread.sleep(3000);
		logOut.logout();
		Thread.sleep(3000);
		prntResults("___________________________________________");

	}
	catch (Exception e) 
	{
		CaptureScreenshot_On_Failure();
		ErrorUtil.addVerificationFailure(e);		
		prntResults("Failed to validate siteacesss");		
		throw new Exception("Failed to validate siteacesss", e);
	}
	finally
	{			
		prntResults("___________________________________________");
	}
}

 @DataProvider
 public Object[][] getTestData(){
 	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
 }
}

