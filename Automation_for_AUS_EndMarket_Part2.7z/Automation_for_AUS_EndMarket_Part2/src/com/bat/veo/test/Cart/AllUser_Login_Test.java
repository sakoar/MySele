package com.bat.veo.test.Cart;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.TestUtil;

public class AllUser_Login_Test extends LocalTestBase{
	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_LogOut_page logOut;

 @Test(dataProvider="getTestData")
 public void CreateNewOrder(String usertype,String username, String password) throws Exception{
	 SoftAssert s_assert = new SoftAssert();
	 driver.get(CONFIG.getProperty("stagging_url"));
	 
	   // JavascriptExecutor js = (JavascriptExecutor) driver;
		// Get the Load Event End
		//long loadEventEnd = (Long) js.executeScript("return window.performance.timing.loadEventEnd;");
		// Get the Navigation Event Start
		//long navigationStart = (Long) js.executeScript("return window.performance.timing.navigationStart;");
		// Difference between Load Event End and Navigation Event Start is Page Load Time
		//prntResults("Page Load Time is " + (loadEventEnd - navigationStart)/1000 + " seconds.");

	 logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
	 home = PageFactory.initElements(driver, sf_HomePage.class);
	 logOut = PageFactory.initElements(driver, sf_LogOut_page.class);

	 try
	 {
		logIn.log_In(usertype,username,password);
		prntResults("Logged in with "+username+"/"+password);
		prntResults("__________________________________________________________");

		home.verifyHomeMenu(s_assert);
		home.verifyHomeFooter(s_assert);
		prntResults("Successfully Verified Homepage");
		prntResults("______________________________________________________________");
	 }
	catch(Exception exception)
	{
		CaptureScreenshot_On_Failure();
		System.err.println("Failed to Validate Login for All Users");
		prntResults("Failed to Validate Login for All Users");
		throw new Exception("Failed to Validate Login for All Users",exception);
	}
	finally
	{
		logOut.logout();
		prntResults("______________________________________________________________");
	}
 }

 @DataProvider
 public Object[][] getTestData(){	
 	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
 }
}