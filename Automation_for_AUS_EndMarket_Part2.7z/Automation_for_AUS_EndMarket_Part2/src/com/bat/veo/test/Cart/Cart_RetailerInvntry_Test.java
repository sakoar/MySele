package com.bat.veo.test.Cart;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.bo_Home_Page;
import com.veo.pageObjects.sf_Cart_inventry_Page;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.pageObjects.sf_OrderConfirmationPage;
import com.veo.pageObjects.sf_Order_Continue_orCancel_page;
import com.veo.pageObjects.sf_ReviewOrder_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class Cart_RetailerInvntry_Test extends LocalTestBase {
	bo_Home_Page home_BO;

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_LogOut_page logOff;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_Order_Continue_orCancel_page Continue;
	sf_Cart_inventry_Page cartInvntry;
	sf_ReviewOrder_page reviewPage;
	sf_OrderConfirmationPage confirmationPage;
	sf_Order_Continue_orCancel_page cancelOrder;

@Test (dataProvider="getTestData")
public void ValidateCartInventry(
		String country,
		String usertype,
		String username,
		String password,
		String productID,
		String invntryVlue) throws Exception { 

	driver.get(CONFIG.getProperty("stagging_url"));

	home_BO = PageFactory.initElements(driver,bo_Home_Page.class);
	
	logIn=PageFactory.initElements(driver, sf_LogIn_page.class);
	OrderCreation =PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	cartInvntry= PageFactory.initElements(driver, sf_Cart_inventry_Page.class);
	Continue = PageFactory.initElements(driver, sf_Order_Continue_orCancel_page.class);
	reviewPage = PageFactory.initElements(driver, sf_ReviewOrder_page.class);
	confirmationPage = PageFactory.initElements(driver, sf_OrderConfirmationPage.class);
	logOff=PageFactory.initElements(driver, sf_LogOut_page.class);

	try
	{
		home_BO.implicit_Wait_ID_Sree(logIn.SF_LoginPage_ClerkTab, 5000);		
		
		logIn.log_In(usertype,username,password);
		prntResults("Logged in with "+username+"/"+password);
		prntResults("__________________________________________________________");
		Thread.sleep(3000);
		
		home_BO.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);		
		
		OrderCreation.CreateOrderRetailer(driver,country); 
		
		home_BO.implicit_Wait_ID_Sree(OrderCreation.searchProductBox, 5000);	
		OrderCreation.cartSearchByID(driver,productID);
		
		Thread.sleep(20000);		
	/*	WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@id='cart-table']//td[@id='"+productID+"']/following-sibling::td[@class='col-product-id']/span[not(@class='product-id hidden')]")));
	*/		        
        WebElement searchResult = driver.findElement(By.xpath("//table[@id='cart-table']//td[@id='"+productID+"']/following-sibling::td[@class='col-product-id']/span[not(@class='product-id hidden')]"));
		Thread.sleep(9000);
		
		String locatorID = searchResult.getAttribute("id");
		System.out.println(locatorID);
		Thread.sleep(20000);			
		
		prntResults("LOCATOR ID IS: "+locatorID);		
		
		Thread.sleep(9000);
		int rowNum = locatorID.length()-1;
		String value = locatorID.substring(rowNum);
		Thread.sleep(3000);		
		
		home_BO.implicit_Wait_ID_Sree(OrderCreation.searchProductBox, 5000);	
		cartInvntry.targetInvntryValue(driver,productID,value,invntryVlue);		
		
		home_BO.implicit_Wait_ID_Sree(OrderCreation.searchProductBox, 5000);
		cartInvntry.InventryOnHand(driver,productID,value);			
		
		home_BO.implicit_Wait_ID_Sree(OrderCreation.searchProductBox, 5000);
		cartInvntry.OrderQntity.sendKeys("11");		
		
		home_BO.implicit_Wait_ID_Sree(Continue.Continue_button, 5000);		
		Continue.ContinueOrder(usertype);

		if(country.equalsIgnoreCase("AUS"))
		{
			home_BO.implicit_Wait_ID_Sree(Continue.CanOrderPopUpHeader, 5000);			
			Continue.CanOrderPopUP();
		}
		prntResults("Successfully Verified Cart page and Entered Quantity");
		prntResults("______________________________________________________________");
		
		home_BO.implicit_Wait_ID_Sree(reviewPage.ReviewOrderPage, 5000);		
		reviewPage.ReviewPageVerification();
		
		home_BO.implicit_Wait_ID_Sree(reviewPage.PlaceOrderButton, 5000);		
		reviewPage.PlacingOrder();
		//capturescreenshot(this.getClass().getSimpleName()+"_ReviewOrderpage");

		prntResults("Successfully Verified Review page");
		prntResults("______________________________________________________________");
		
		home_BO.implicit_Wait_ID_Sree(confirmationPage.OrderDetailsPage, 5000);		
		confirmationPage.reviewOrderConfirmPage();
		
		//capturescreenshot(this.getClass().getSimpleName()+"_OrderConfirmationPage");
		prntResults("Successfully Navigated to and Verified Order Confirmation page");
		prntResults("______________________________________________________________");

	}
	catch (Exception e) 
	{
		CaptureScreenshot_On_Failure();
		e.printStackTrace();
		System.err.println("Failed to validate Cart Retailer Inventory Test   : "+e.getMessage());
		ErrorUtil.addVerificationFailure(e);
		throw e;
	}
	finally
	{
		driver.get(CONFIG.getProperty("stagging_url"));
		logOff.logout();
		prntResults("__________________________________________________________");
	}
}

@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
	
}

}