package com.bat.veo.test.Cart;

/****************************************************************************************************	
 * CreatedBy : Sree
 * Date :  * 
 * Test Case: TC_SBN_GBL_001
 * Description: Search with all the possible keywords - Retailer,Clerk
 * Expected Results: Search Results should be displayed based on the search criteria
****************************************************************************************************/

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class Search_Products_Test extends LocalTestBase{

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_LogOut_page logout;

@Test(dataProvider = "getTestData")
	public void Search_Browse_Navigation(
			String usertype,
			String username,
			String password,
			String Product_Number,
			String Product_Name) throws Exception {

	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);	
	home = PageFactory.initElements(driver, sf_HomePage.class);
	logout = PageFactory.initElements(driver, sf_LogOut_page.class);

		driver.get(CONFIG.getProperty("stagging_url"));

		try
		{
		    logIn.log_In(usertype, username, password); // Login
			prntResults("Logged in with "+username+"/"+password);
			prntResults("___________________________________________");
			
		     home.isElementLoaded(home.errorDiv,100);
		    
			 home.Verify_HomePage_ProductSearch(driver,Product_Number);
					
			 home.isElementLoaded(home.errorDiv,100);
			
			home.Verify_HomePage_ProductSearch(driver, Product_Name);
			prntResults("___________________________________________");
		}
		catch (Exception e) 
		{
	        CaptureScreenshot_On_Failure();
			ErrorUtil.addVerificationFailure(e);		
			prntResults("Failed to Search products in Homepage");		
			throw new Exception("Failed to Search products in Homepage", e);
		}
		finally
		{
			logout.logout();
			Thread.sleep(2000);
			prntResults("___________________________________________");
		}
	}

@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
}

}