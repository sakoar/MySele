package com.bat.veo.test.Cart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_Cart_inventry_Page;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class MissingOrLowInvn_Test extends LocalTestBase{

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_LogOut_page logOut;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_Cart_inventry_Page cartInvntry;

@Test (dataProvider="getTestData")
public void MissingOrLowInvntry(
		String country,
		String usertype,
		String username,
		String password,
		String productID,
		String invntryVlue) throws Exception {
try
{
	driver.get(CONFIG.getProperty("stagging_url"));	  	  
	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
	OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	cartInvntry= PageFactory.initElements(driver, sf_Cart_inventry_Page.class);
	logOut = PageFactory.initElements(driver, sf_LogOut_page.class);

		logIn.log_In(usertype,username,password);
		prntResults("Logged in with "+username+"/"+password);
		prntResults("__________________________________________________________");

		OrderCreation.CreateOrderRetailer(driver,country);
		OrderCreation.cartSearchByID(driver,productID);
		Thread.sleep(2000);

		WebElement searchResult = driver.findElement(By.xpath("//*[@id='cart-table']/tbody/tr/td[@id='"+productID+"']/following-sibling::td[@class='col-product-id']/span[not(@class='product-id hidden')]"));
		String locatorID = 	searchResult.getAttribute("id");
		//System.out.println("LOCATOR ID IS: "+locatorID);

		int rowNum = locatorID.length()-1;
		String value =locatorID.substring(rowNum);

		cartInvntry.targetInvntryValue(driver,productID,value,invntryVlue);	
		cartInvntry.InventryOnHand(driver, productID, value);
	 	cartInvntry.lowerQty(driver, productID);
	 	cartInvntry.OrderQtyTest(driver, productID);
	 	prntResults("__________________________________________________________");

		Thread.sleep(2000);
		//logOut.logout();
		Thread.sleep(3000);
		prntResults("__________________________________________________________");
}
catch (Exception e) 
{
	CaptureScreenshot_On_Failure();
	ErrorUtil.addVerificationFailure(e);		
	prntResults("Failed to validate siteacesss");		
	throw new Exception("Failed to validate siteacesss", e);
}
finally
{			
	prntResults("___________________________________________");
}
}

@DataProvider
public Object[][] getTestData(){	
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
}
}

