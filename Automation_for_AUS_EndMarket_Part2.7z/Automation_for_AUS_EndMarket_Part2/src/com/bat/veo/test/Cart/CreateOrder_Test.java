package com.bat.veo.test.Cart;
/****************
 * This Test Created by Sandeep for Demo
 */
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.pageObjects.sf_OrderConfirmationPage;
import com.veo.pageObjects.sf_Order_Continue_orCancel_page;
import com.veo.pageObjects.sf_ReviewOrder_page;
import com.veo.util.TestUtil;

public class CreateOrder_Test extends LocalTestBase
{
	sf_LogIn_page logIn;
	sf_LogOut_page logout;
	sf_HomePage home;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_Order_Continue_orCancel_page Continue;
	sf_ReviewOrder_page reviewPage;
	sf_OrderConfirmationPage OrderConfirmation;

@Test(dataProvider="getTestData")
public void NewCreateOrder(
		String country,
		String usertype,
		String username,
		String password,
		String order_quantity) throws Exception{

	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);	
	home = PageFactory.initElements(driver, sf_HomePage.class);
	OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	Continue = PageFactory.initElements(driver, sf_Order_Continue_orCancel_page.class);
	reviewPage = PageFactory.initElements(driver, sf_ReviewOrder_page.class);
	OrderConfirmation =PageFactory.initElements(driver, sf_OrderConfirmationPage.class);
	logout = PageFactory.initElements(driver, sf_LogOut_page.class);

		driver.get(CONFIG.getProperty("stagging_url"));
		
		try
		{
			logIn.log_In(usertype,username,password);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			prntResults("Logged in with "+username+"/"+password);
			prntResults("___________________________________________");
			
			if(usertype.equalsIgnoreCase("Engagement Clerk"))
			{
				OrderCreation.CreateOrderClerk();
				Thread.sleep(2000);
			}

			if(usertype.equalsIgnoreCase("Retailer")||usertype.equalsIgnoreCase("Trusted Clerk")||usertype.equalsIgnoreCase("FullyTrusted Clerk"))
			{
				OrderCreation.CreateOrderRetailer(driver,country);
				prntResults("Successfully navigated to Cart Page");
				Thread.sleep(3000);
				OrderCreation.enterQtyforRandomProduct(order_quantity);
				Thread.sleep(2000);
				Continue.ContinueOrder(driver,usertype);
				Thread.sleep(2000);
			}
			if(usertype.equalsIgnoreCase("Retailer")||usertype.equalsIgnoreCase("FullyTrusted Clerk"))
			{
				Thread.sleep(2000);
				ignoreAndContinue(driver);
				//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				reviewPage.PlacingOrder();
				//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				OrderConfirmation.reviewOrderConfirmPage();
				//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Thread.sleep(4000);
			}
			prntResults("___________________________________________");
		}
		catch (Exception e) 
		{
			CaptureScreenshot_On_Failure();
			System.err.println("Failed to Create Order");
			prntResults(e.getMessage());
			e.printStackTrace();
			throw e;
		}
		finally
		{
			driver.get(CONFIG.getProperty("stagging_url"));
			logout.logout();
			prntResults("___________________________________________");
		}
}

@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
}
}
