package com.bat.veo.test.Cart;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.bo_Cart_Page;
import com.veo.pageObjects.bo_Home_Page;
import com.veo.pageObjects.bo_Login_Page;
import com.veo.pageObjects.bo_Logout_Page;
import com.veo.pageObjects.sf_Cart_inventry_Page;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.pageObjects.sf_OrderConfirmationPage;
import com.veo.pageObjects.sf_Order_Continue_orCancel_page;
import com.veo.pageObjects.sf_ReviewOrder_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;


public class Cart_ZeroProdQty_ZeroInv_Test extends LocalTestBase{
	sf_LogIn_page logIn;
	sf_LogOut_page logOut;
	sf_HomePage home;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_Order_Continue_orCancel_page Continue;
	sf_ReviewOrder_page reviewPage;
	sf_Cart_inventry_Page cartInvntry;
	sf_OrderConfirmationPage confirmationPage;	
	bo_Login_Page login_BO;
	bo_Home_Page home_BO;
	bo_Cart_Page cart_BO;
	bo_Logout_Page logOut_BO;

  @Test(dataProvider="getTestData")
  public void ZeroProductQty_or_ZeroInvntryQty(
		  String country,
		  String usertype,
		  String username,
		  String password,
		  String bo_username,
		  String bo_password,
		  String productID,
		  String invntryVlue,
		  String bo_message) throws Exception {

	  driver.get(CONFIG.getProperty("stagging_url"));  

	  logOut = PageFactory.initElements(driver, sf_LogOut_page.class);
	  logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
	  OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	  home_BO	= PageFactory.initElements(driver, bo_Home_Page.class);
	  cartInvntry= PageFactory.initElements(driver, sf_Cart_inventry_Page.class);
	  Continue= PageFactory.initElements(driver, sf_Order_Continue_orCancel_page.class);
	  OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	  reviewPage = PageFactory.initElements(driver,sf_ReviewOrder_page.class);
	  confirmationPage=PageFactory.initElements(driver, sf_OrderConfirmationPage.class);
	  login_BO=PageFactory.initElements(driver, bo_Login_Page.class);
	  logOut_BO = PageFactory.initElements(driver, bo_Logout_Page.class);
try
{
		logIn.log_In(usertype,username,password);
		prntResults("Logged in with "+username+"/"+password);
		prntResults("__________________________________________________________");

		OrderCreation.CreateOrderRetailer(driver,country); 
		Thread.sleep(3000);		
		cartInvntry.OrderWithLowOrZeroQty("0");
		Continue.Continue_button.click();
		cartInvntry.OrderPopUpZeroQty1();
		Thread.sleep(2000);
		prntResults("__________________________________________________________");

		OrderCreation.CreateOrderRetailer(driver,country);
		Thread.sleep(3000);
		cartInvntry.OrderWithLowOrZeroQty("50");
		Continue.ContinueOrder(driver, usertype);

		cartInvntry.OrderPopForNoInvntryQTY("Change Order");  //userDecision = Change Order or IgnoreNContinue
		Thread.sleep(2000);
		
		Continue.ContinueOrder(driver, usertype);
		cartInvntry.OrderPopForNoInvntryQTY("IgnoreNContinue");

		reviewPage.ReviewPageVerification();
		reviewPage.PlacingOrder();
		prntResults("__________________________________________________________");

		confirmationPage.reviewOrderConfirmPage();
		String OrderNumber=confirmationPage.OrderNumberGenerated.getText();
		prntResults("OrderNumber printed in Test: "+OrderNumber );

		Thread.sleep(3000);
		if(OrderCreation.Order_button.getText().equalsIgnoreCase("Order in progress")){
			Thread.sleep(1500);
			OrderCreation.CancelOrder(driver);
		}
		Thread.sleep(1500);
		logOut.logout();
		Thread.sleep(1500);
		prntResults("__________________________________________________________");

	 driver.get(CONFIG.getProperty("backoffice_url"));

		 login_BO.Login_Backoffice(bo_username,bo_password);
		 prntResults("Logged into Backoffice with " +bo_username+ "/" +bo_password);
		 Thread.sleep(3000);
		 home_BO.BO_ReasonColumn(driver,OrderNumber,bo_message);
		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		 logOut_BO.Backoffice_Logout();
		 Thread.sleep(2000);
}
catch (Exception e) 
{
	CaptureScreenshot_On_Failure();
	ErrorUtil.addVerificationFailure(e);		
	prntResults("Failed to validate siteacesss");		
	throw new Exception("Failed to validate siteacesss", e);
}
finally
{			
	prntResults("___________________________________________");
}}
  
  @DataProvider
  public Object[][] getTestData(){	
  	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
  }
}