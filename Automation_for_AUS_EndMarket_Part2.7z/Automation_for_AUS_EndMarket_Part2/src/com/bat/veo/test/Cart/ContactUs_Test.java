package com.bat.veo.test.Cart;
/****************************************************************************************************      
* CreatedBy : Ruth Angel 
* Date : 07.03.2017
* Test Case : TC_CONT_GBL_001
* Manual Test Scenarios: REG_00_VEO_Send Contact Us details_Retailer,Fully trusted Clerk,Trusted clerk,Engagement Clerk
* Description: Send Contact Us details_Retailer/Fully Trusted Clerk/Trusted Clerk/Engagement Clerk
* Expected Results: User should be able to view and Send Contact Us details
****************************************************************************************************/

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_ContactUsPage;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class ContactUs_Test extends LocalTestBase{

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_ContactUsPage contactus;
	sf_LogOut_page logout;

@Test(dataProvider="getTestData")
public void ContactUs(
		String UsrType,
		String username,
		String Password,
		String ContactusName,
		String ContactusEmail,
		String ContactusReason,
		String ContactusMsg) throws Exception{

	driver.get(CONFIG.getProperty("stagging_url"));

	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);	
	home = PageFactory.initElements(driver, sf_HomePage.class);
	contactus = PageFactory.initElements(driver, sf_ContactUsPage.class);
	logout = PageFactory.initElements(driver, sf_LogOut_page.class);

	logIn.log_In(UsrType,username,Password);
	prntResults("Logged in with "+username+"/"+Password);
	prntResults("___________________________________________");
	try
	{
		home.Home_Page_Help_Contact.click();
		prntResults("Clicked on Contact us Link");
		contactus.Send_ContactUs_Email(driver,ContactusName,ContactusEmail,ContactusReason,ContactusMsg);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}catch (Exception e) 
	{
		CaptureScreenshot_On_Failure();
		ErrorUtil.addVerificationFailure(e);
		System.err.println("Failed to Verify Contact US");
		prntResults("Failed to Verify Contact US");		
		throw new Exception("Failed to Verify Contact US", e);
	}
	finally
	{
		logout.logout();
		prntResults("___________________________________________");
	}

}
@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
}
}
