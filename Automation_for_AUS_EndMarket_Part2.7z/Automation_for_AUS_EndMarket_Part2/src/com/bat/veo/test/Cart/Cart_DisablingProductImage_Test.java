package com.bat.veo.test.Cart;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.pageObjects.sf_OrderConfirmationPage;
import com.veo.pageObjects.sf_Order_Continue_orCancel_page;
import com.veo.pageObjects.sf_ReviewOrder_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class Cart_DisablingProductImage_Test extends LocalTestBase{

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_Order_Continue_orCancel_page Continue;
	sf_ReviewOrder_page reviewPage;
	sf_OrderConfirmationPage confirmationPage;
	sf_LogOut_page logOff;

@Test(dataProvider="getTestData")
public void DisableProductImage(
		String country,
		String usertype,
		String username,
		String password,
		String order_quantity) throws Exception{
	
	driver.get(CONFIG.getProperty("stagging_url"));

	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
	logOff = PageFactory.initElements(driver, sf_LogOut_page.class);
	OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	Continue= PageFactory.initElements(driver, sf_Order_Continue_orCancel_page.class);
	reviewPage = PageFactory.initElements(driver, sf_ReviewOrder_page.class);
	confirmationPage = PageFactory.initElements(driver, sf_OrderConfirmationPage.class);
	logOff = PageFactory.initElements(driver, sf_LogOut_page.class);
	
	try
	{
		logIn.log_In(usertype,username,password);
		prntResults("Logged in with "+username+"/"+password);
		prntResults("__________________________________________________________");

		if(usertype.equalsIgnoreCase("Engagement Clerk"))
		{
			OrderCreation.CreateOrderClerk();
			Thread.sleep(2000);
		}
		if(usertype.equalsIgnoreCase("FullyTrusted Clerk")||usertype.equalsIgnoreCase("Retailer")||usertype.equalsIgnoreCase("Trusted Clerk"))
		{
			OrderCreation.CreateOrderRetailer(driver,country);
			OrderCreation.enterQtyforRandomProduct(order_quantity);
			OrderCreation.Disable_ProductImage();        //Disabling product image
			Continue.ContinueOrder(driver,usertype);
		}
		if((usertype.equalsIgnoreCase("Retailer"))||(usertype.equalsIgnoreCase("FullyTrusted Clerk")))
		{
			Thread.sleep(2000);
			ignoreAndContinue(driver);
			reviewPage.PlacingOrder();
			confirmationPage.reviewOrderConfirmPage();
			Thread.sleep(2000);
			prntResults("__________________________________________________________");
		}
	}
	catch (Exception e) 
	{
		CaptureScreenshot_On_Failure();
		System.err.println("Failed to validate Cart DisablingProductImage Test  : "+e.getMessage());
		ErrorUtil.addVerificationFailure(e);
		e.printStackTrace();
		throw e;
	}
	finally
	{
		driver.get(CONFIG.getProperty("stagging_url"));
		logOff.logout();
		prntResults("__________________________________________________________");
	}
}

@DataProvider
public Object[][] getTestData(){	
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
}
}
