package com.bat.veo.test.Cart;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.pageObjects.sf_Order_Continue_orCancel_page;
import com.veo.util.TestUtil;

public class Cancel_CreatedOrder_Test extends LocalTestBase{
	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_LogOut_page logOut;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_Order_Continue_orCancel_page Continue;
	sf_Order_Continue_orCancel_page cancel;
	
 @Test(dataProvider="getTestData")
  public void CancelStartedOrder(
		  String country,
		  String usertype,
		  String username,
		  String password,
		  String order_quantity) throws Exception{

	 driver.get(CONFIG.getProperty("stagging_url"));

		logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
		home = PageFactory.initElements(driver, sf_HomePage.class);
		OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
		cancel= PageFactory.initElements(driver, sf_Order_Continue_orCancel_page.class);
		logOut = PageFactory.initElements(driver, sf_LogOut_page.class);

		try
		{
			logIn.log_In(usertype,username,password);
			prntResults("Logged in with "+username+"/"+password);
			prntResults("__________________________________________________________");
			
			if(usertype.equalsIgnoreCase("Engagement Clerk"))
			{
				OrderCreation.CreateOrderClerk();
				
			}
			else
			{
				
				OrderCreation.implicit_Wait_ID(driver, 100);
							
				OrderCreation.CreateOrderRetailer(driver,country);				
				
				OrderCreation.implicit_Wait_ID2(driver, 100);
				
				OrderCreation.enterQtyforRandomProduct(order_quantity);
				
				OrderCreation.implicit_Wait_ID(driver, 100);	
				
				cancel.CancelOrder(driver); 
				//Go & Cancel the started Order
			}
		}
		catch (Exception e)
		{
			CaptureScreenshot_On_Failure();
			System.err.println("Failed to Cancel a Started Order");
			prntResults("Failed to Cancel a Started Order");
			throw new Exception("Failed to Cancel a Started Order",e);
		}
		finally
		{
			driver.get(CONFIG.getProperty("stagging_url"));
			/*if(!(usertype.equalsIgnoreCase("Engagement Clerk")))
			{
				if(OrderCreation.Order_button.getText().equalsIgnoreCase("Order in progress"))
				{
					Thread.sleep(3000);
					cancel.CancelOrder(driver);  
				}
			}*/
			logOut.logout();
			prntResults("______________________________________________________________");

		}
 }
 @DataProvider
 public Object[][] getTestData(){	
 	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
 }
}
