package com.bat.veo.test.Cart;

/****************************************************************************************************	
 * CreatedBy : Sree
 * Date :  * 
 * Test Case: TC_SBN_GBL_001
 * Description: Navigate to all Modules - Clerk
 * Expected Results: Navigation to all Modules
 * ****************************************************************************************************/

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.pageObjects.sf_MyAccount_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class Navigation_Test extends LocalTestBase
{
	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_LogOut_page logout;
	sf_MyAccount_page MyAccount;

@Test(dataProvider = "getTestData")
public void Navigation_pages(
		String country,
		String usertype,
		String username,
		String password) throws Exception{

		logIn = PageFactory.initElements(driver, sf_LogIn_page.class);	
		home = PageFactory.initElements(driver, sf_HomePage.class);
		MyAccount = PageFactory.initElements(driver, sf_MyAccount_page.class);
		logout = PageFactory.initElements(driver, sf_LogOut_page.class);

			driver.get(CONFIG.getProperty("stagging_url"));	
			prntResults("***************************************************************************************");
			prntResults("Executing Navigation Test");
			prntResults("***************************************************************************************");
			try
			{
				logIn.log_In(usertype,username,password);
				prntResults("Logged in with "+username+"/"+password);
				prntResults("___________________________________________");
	
			    home.MenuItems(driver,"Home");
				home.MenuItems(driver,"Products");
			    home.MenuItems(driver,"News & Events");
			    home.MenuItems(driver,"My Documents");
			    home.MenuItems(driver,"FAQ");
			    Thread.sleep(2000);
	
			    if(country.equalsIgnoreCase("CAN"))
			    {
				    home.MenuItems(driver,"My Performance");
				    home.Click_On_SubMenuItems(driver,"My Transactions");
				    if(usertype.equalsIgnoreCase("Engagement Clerk")||usertype.equalsIgnoreCase("Trusted Clerk"))
				    {
				    	home.Clerk_NotPermitted_OkButton.click();
				    	prntResults("Clicked on Ok Button");
				    	Thread.sleep(2000);
				    }

				    /*if(usertype.equalsIgnoreCase("Retailer")||usertype.equalsIgnoreCase("FullyTrusted Clerk"))
				    {
					    home.MenuItems(driver,"My Performance");
					    home.Click_On_SubMenuItems(driver,"My Investments and Profit");
				    }*/

				    home.MenuItems(driver,"My Programs");
				    home.Click_On_SubMenuItems(driver,"Listing Page");
				    if(usertype.equalsIgnoreCase("Engagement Clerk")||usertype.equalsIgnoreCase("Trusted Clerk"))
				    {
				    	home.Clerk_NotPermitted_OkButton.click();
				    	prntResults("Clicked on Ok Button");
				    	Thread.sleep(2000);
				    }

				    home.MenuItems(driver,"My Capture");
				    home.Click_On_SubMenuItems(driver,"Price Capture");
				    if(usertype.equalsIgnoreCase("Engagement Clerk"))
				    {
				    	home.Clerk_NotPermitted_OkButton.click();
				    	prntResults("Clicked on Ok Button");
				    	Thread.sleep(2000);
				    }

				    home.MenuItems(driver,"My Programs");
				    home.Click_On_SubMenuItems(driver,"Tracking Page");
				    if(usertype.equalsIgnoreCase("Engagement Clerk")||usertype.equalsIgnoreCase("Trusted Clerk"))
				    {
				    	home.Clerk_NotPermitted_OkButton.click();
				    	prntResults("Clicked on Ok Button");
				    	Thread.sleep(2000);
				    }

					home.MenuItems(driver,"My Capture");
					home.Click_On_SubMenuItems(driver,"Volume Capture");
				    if(usertype.equalsIgnoreCase("Engagement Clerk")||usertype.equalsIgnoreCase("Trusted Clerk"))
				    {
				    	home.Clerk_NotPermitted_OkButton.click();
				    	prntResults("Clicked on Ok Button");
				    	Thread.sleep(2000);
				    }

			    }

			    Thread.sleep(3000);
			    home.NavigateToOrderHistory(usertype);
			    Thread.sleep(2000);
			    MyAccount.NavigateToMyAccountPage(driver);


			    if(country.equalsIgnoreCase("CAN"))
			    {
			    	home.Click_On_FooterItems(driver,"Contact us");
			    	Thread.sleep(1000);
			    	home.Click_On_FooterItems(driver,"Terms & Conditions");
			    	Thread.sleep(1000);
			    }
			    else
			    {
			    	home.Click_On_FooterItems(driver,"Help & Contact");
			    	Thread.sleep(1000);
					home.Click_On_FooterItems(driver,"Terms And Conditions");
					Thread.sleep(1000);
			    }

				home.Click_On_FooterItems(driver,"Glossary");
				Thread.sleep(1000);
				home.Click_On_FooterItems(driver,"Privacy Policy");
				Thread.sleep(1000);
				if(country.equalsIgnoreCase("CAN"))
			    {
		   			home.Click_On_FooterItems(driver,"About Us");
		   			Thread.sleep(1000);
			    }
				else{
					home.Click_On_FooterItems(driver,"About us");
					Thread.sleep(1000);
				}
	   			
	   			String winHandleBefore = driver.getWindowHandle();
	   			for(String winHandle : driver.getWindowHandles()){
	   			    driver.switchTo().window(winHandle);
	   			}
	   			driver.close();
	   			Thread.sleep(1000);
	   			driver.switchTo().window(winHandleBefore);

		}catch (Exception e) 
		{
			CaptureScreenshot_On_Failure();
			ErrorUtil.addVerificationFailure(e);		
			prntResults("Failed to Validate Navigation Test");	
			e.printStackTrace();
			throw e;
		}
		finally
		{
			driver.get(CONFIG.getProperty("stagging_url"));	
		    logout.logout();
		    prntResults("________________________________________________________________");
		}

}

@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
}

}

