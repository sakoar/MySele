package com.bat.veo.test.Cart;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class Cart_AlterDaysofCoverage_Test extends LocalTestBase {

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_LogOut_page logout;

	/****************************************************************************************************	
	 * Test Case: TC_SBN_GBL_001
	 * Description: Search with all the possible keywords - Retailer
	 * Expected Results: Search Results should be displayed based on the search criteria
	****************************************************************************************************/

	@Test(dataProvider = "getTestData")
    public void creatingOrder(
    		String country,
    		String usertype,
    		String username,
    		String password,
    		String DaysofForecast_Value1,
    		String DaysofForecast_Value2) throws Exception{

    //=========================Initializing Page Objects===================//

		logIn = PageFactory.initElements(driver, sf_LogIn_page.class);	
		home = PageFactory.initElements(driver, sf_HomePage.class);
		OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
		logout = PageFactory.initElements(driver, sf_LogOut_page.class);

		driver.get(CONFIG.getProperty("stagging_url"));

		try
		{
			logIn.log_In(usertype,username,password);
			prntResults("Logged in with "+username+"/"+password);
			prntResults("________________________________________________________________");

			if(usertype.equalsIgnoreCase("Engagement Clerk"))
			{
				OrderCreation.CreateOrderClerk();
				Thread.sleep(2000);
			}
			else
			{

				OrderCreation.CreateOrderRetailer(driver,country);
			    String TargetInv_Before = driver.findElement(By.id("target-inv-0")).getAttribute("value");
			    prntResults("TARGET INV value before changing Days of Forecast is "+TargetInv_Before);  
		
			    OrderCreation.Recompute_DaysofForecast(DaysofForecast_Value1,DaysofForecast_Value2);
			    String TargetInv_After = driver.findElement(By.id("target-inv-0")).getAttribute("value");
			    prntResults("TARGET INV value after changing Days of Forecast is " +TargetInv_After);

			    if(!(TargetInv_Before.equalsIgnoreCase(TargetInv_After)))
			    {
			    	prntResults("As Expected Target Inventory doesnt match");
			    }
			    else{
			    	prntResults("Failed as Target Inventory is matching");
			    	throw new Exception("Failed as Target Inventory is matching");
			    }
			    Thread.sleep(3000);
			}
		}
		catch (Exception e) 
		{
			CaptureScreenshot_On_Failure();
			ErrorUtil.addVerificationFailure(e);
			prntResults(e.getMessage());
			e.printStackTrace();
			throw e;
		}
		finally
		{
			driver.get(CONFIG.getProperty("stagging_url"));
		/*	if(!(usertype.equalsIgnoreCase("Engagement Clerk")))
			{
				OrderCreation.CancelOrder(driver);
			}*/
			logout.logout();
		    prntResults("________________________________________________________________");
		}
}

@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName()) ;
}

}
