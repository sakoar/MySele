package com.bat.veo.test.Cart;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.TestUtil;

public class Cart_ClerkInvntry_Test extends LocalTestBase {

	sf_LogIn_page logIn;
	sf_LogOut_page logOff;
	sf_CreateOrder_n_Product_Selection OrderCreation;

	@Test(dataProvider = "getTestData")
	public void ValidateCartInventry(
			String country,
			String usertype,
			String username,
			String password) throws Exception {

		driver.get(CONFIG.getProperty("stagging_url"));

		logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
		OrderCreation = PageFactory.initElements(driver,sf_CreateOrder_n_Product_Selection.class);
		logOff = PageFactory.initElements(driver, sf_LogOut_page.class);
		
		try
		{
			logIn.log_In(usertype, username, password);
			prntResults("Logged in with "+username+"/"+password);
			prntResults("__________________________________________________________");

			if (usertype.equalsIgnoreCase("Trusted Clerk"))
			{
				OrderCreation.implicit_Wait_ID_Sree(OrderCreation.Order_button, 10000);			
			
				OrderCreation.CreateOrderRetailer(driver,country);
			}
			else
			{
				OrderCreation.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);			
			
				OrderCreation.CreateOrderClerk();
			prntResults("__________________________________________________________");
		}
		}
		catch (Exception e)
		{
			CaptureScreenshot_On_Failure();
			e.getMessage();
			System.err.println(e.getMessage());
			throw e;
		}
		finally
		{
			driver.get(CONFIG.getProperty("stagging_url"));
			if(!(usertype.equalsIgnoreCase("Engagement Clerk")))
			{
				OrderCreation.CancelOrder(driver);
			}
			logOff.logout();
			prntResults("__________________________________________________________");
		}
	}

	@DataProvider
	public Object[][] getTestData() {
		return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());

	}

}