package com.bat.veo.test.Cart;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.bo_Home_Page;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.TestUtil;

public class Cart_AddingColumns_Test extends LocalTestBase{
	bo_Home_Page home_BO;

	sf_LogIn_page logIn;
	sf_LogOut_page logout;
	sf_CreateOrder_n_Product_Selection OrderCreation;

@Test(dataProvider="getTestData")
public void AddingColumns(
		String country,
		String usertype,
		String username,
		String password,
		String OrderQty) throws Exception{

	   driver.get(CONFIG.getProperty("stagging_url"));
		home_BO = PageFactory.initElements(driver,bo_Home_Page.class);
		
	 	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
		OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
		logout = PageFactory.initElements(driver, sf_LogOut_page.class);

	try
	{
		home_BO.implicit_Wait_ID_Sree(logIn.SF_LoginPage_ClerkTab, 5000);		
		logIn.log_In(usertype,username,password);
		
		prntResults("Logged in with "+username+"/"+password);
		prntResults("___________________________________________");
		
		if(usertype.equalsIgnoreCase("Engagement Clerk"))
		{
			home_BO.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);			
			OrderCreation.CreateOrderClerk();
			//Thread.sleep(2000);
		}
		else
		{
			home_BO.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);			
			OrderCreation.CreateOrderRetailer(driver,country);
			
			home_BO.implicit_Wait_ID_Sree(OrderCreation.OrderQntity1, 5000);		
			OrderCreation.enterQtyforRandomProduct(OrderQty);
			
			home_BO.implicit_Wait_ID_Sree(OrderCreation.Settings_Ikon, 5000);	
			OrderCreation.addingColumns(driver);
			
			home_BO.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);			
			OrderCreation.CancelOrder_AddingColums(driver);
		}
	}
	catch(Exception e)
	{
		CaptureScreenshot_On_Failure();
		System.err.println("Failed to Add column in Cart");
	
		throw new Exception("Failed to Add column in Cart",e);
	}
	finally
	{
	    driver.get(CONFIG.getProperty("stagging_url"));
		logout.logout();
		Thread.sleep(2000);
		prntResults("___________________________________________");
	}
}

@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
	}
}
