package com.bat.veo.test.Cart;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.TestUtil;

public class AbilitytoSequenceCart_Test extends LocalTestBase{

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_LogOut_page logout;

@Test(dataProvider="getTestData")
public void Sequence_Cart(
		String country,
		String usertype,
		String username,
		String password) throws Exception{
	SoftAssert s_assert = new SoftAssert();

	driver.get(CONFIG.getProperty("stagging_url"));
	
	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);
	home=PageFactory.initElements(driver, sf_HomePage.class);
	OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	logout = PageFactory.initElements(driver, sf_LogOut_page.class);	
	
	try
	{
		logIn.log_In(usertype,username,password);		
	
		prntResults("Logged in with "+username+"/"+password);
		prntResults("___________________________________________");
		
		home.verifyHomeMenu(s_assert);
		
		home.verifyHomeFooter(s_assert);

		if(usertype.equalsIgnoreCase("Engagement Clerk"))
		{
			OrderCreation.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);			
			OrderCreation.CreateOrderClerk();
		}
		else
		{
			OrderCreation.implicit_Wait_ID_Sree(OrderCreation.Order_button, 10000);			
			OrderCreation.CreateOrderRetailer(driver,country);	
			
			OrderCreation.implicit_Wait_ID_Sree(OrderCreation.Settings_Ikon, 10000);			
			OrderCreation.SequenceOrderInCart(driver);
			
		}
	}
	catch(Exception e)
	{
		CaptureScreenshot_On_Failure();
		System.err.println("Failed to Sequence Cart   :  "+e.getMessage());
		e.printStackTrace();
		throw e;
	}
	finally
	{
		s_assert.assertAll();
		driver.get(CONFIG.getProperty("stagging_url"));
		/*if(!(usertype.equalsIgnoreCase("Engagement Clerk")))
		{
			OrderCreation.CancelOrder(driver);
		}*/
		logout.logout();
		prntResults("___________________________________________");
	}

}
@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
	}
}
