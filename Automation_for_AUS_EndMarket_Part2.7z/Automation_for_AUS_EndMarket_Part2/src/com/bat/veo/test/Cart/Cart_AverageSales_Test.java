package com.bat.veo.test.Cart;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.veo.base.LocalTestBase;
import com.veo.pageObjects.sf_CreateOrder_n_Product_Selection;
import com.veo.pageObjects.sf_HomePage;
import com.veo.pageObjects.sf_LogIn_page;
import com.veo.pageObjects.sf_LogOut_page;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class Cart_AverageSales_Test extends LocalTestBase{

	sf_LogIn_page logIn;
	sf_HomePage home;
	sf_CreateOrder_n_Product_Selection OrderCreation;
	sf_LogOut_page logout;

	/****************************************************************************************************	
	 * Test Case: TC_SBN_GBL_001
	 * Description: Search with all the possible keywords - Retailer
	 * Expected Results: Search Results should be displayed based on the search criteria
	****************************************************************************************************/

@Test(dataProvider = "getTestData")
public void Cart_AverageSales_Validation(
		String country,
		String usertype,
		String username,
		String password,
		String weeks) throws Exception{


	logIn = PageFactory.initElements(driver, sf_LogIn_page.class);	
	home = PageFactory.initElements(driver, sf_HomePage.class);
	OrderCreation = PageFactory.initElements(driver, sf_CreateOrder_n_Product_Selection.class);
	logout = PageFactory.initElements(driver, sf_LogOut_page.class);
	
	         SoftAssert s_assert = new SoftAssert();
	
		driver.get(CONFIG.getProperty("stagging_url"));
		
		try
		{
			logIn.log_In(usertype,username,password);
			prntResults("Logged in with "+username+"/"+password);
			prntResults("________________________________________________________________");

				
			home.verifyHomeMenu(s_assert);
			
			home.verifyHomeFooter(s_assert);
			
			prntResults("Successfully verified Homepage");
			prntResults("___________________________________________");

			if(usertype.equalsIgnoreCase("Engagement Clerk"))
			{
				OrderCreation.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);				
				OrderCreation.CreateOrderClerk();
			}
			else
			{
				OrderCreation.implicit_Wait_ID_Sree(OrderCreation.Order_button, 5000);				
				OrderCreation.CreateOrderRetailer(driver,country);
				
				OrderCreation.implicit_Wait_ID_Sree(OrderCreation.SelectItems_Dropdown, 5000);					
				OrderCreation.selectOrders(driver,weeks);
			}
		}catch (Exception e) 
		{
			CaptureScreenshot_On_Failure();
			ErrorUtil.addVerificationFailure(e);		
			prntResults("Failed to Validate Cart Average Sales Test");		
			throw new Exception("Failed to Validate Cart Average Sales Test", e);
		}
		finally
		{
			s_assert.assertAll();
			
			driver.get(CONFIG.getProperty("stagging_url"));
			/*if(!(usertype.equalsIgnoreCase("Engagement Clerk")))
			{
				OrderCreation.CancelOrder(driver);
			}*/
		    logout.logout();
		    prntResults("________________________________________________________________");
		}
	} 

@DataProvider
public Object[][] getTestData(){
	return TestUtil.getData(Veo_TestData_XLS, this.getClass().getSimpleName());
			
}

}
