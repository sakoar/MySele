package com.veo.base;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class ParallelGrid {
//Declare ThreadLocal Driver for ThreadSafe Tests
	protected ThreadLocal<RemoteWebDriver> driver=null;
	
@BeforeTest
@Parameters({ "nodeURL", "OS", "browser" })
public void setUp(String nodeURL, Platform OS, String browser) throws Throwable {
		driver=new ThreadLocal<RemoteWebDriver>(); //Assign driver to a ThreadLocal
		
		DesiredCapabilities cap = new DesiredCapabilities(); //Set DesiredCapabilities
		cap.setPlatform(OS);
	
		if(browser.equalsIgnoreCase("firefox"))
			cap=DesiredCapabilities.firefox();
		if(browser.equalsIgnoreCase("chrome"))
			cap=DesiredCapabilities.chrome();
		if(browser.equalsIgnoreCase("Internet Explorer"))
			cap=DesiredCapabilities.internetExplorer();
		if(browser.equalsIgnoreCase("safari"))
			cap=DesiredCapabilities.safari();
		
		try {
			driver.set(new RemoteWebDriver(new URL(nodeURL),cap));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Exception("Browser Could not Launch in "+nodeURL +"machine. Please check the Grid set up.");
			}
		}
		public WebDriver getDriver() {
	        return driver.get();
	    }
		
		@AfterClass
	    public void tearDown() throws Exception {
	        getDriver().quit();
	    }

}
