package com.veo.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverFactory {
	private DriverFactory(){
		
		//Do-nothing. Do not allow to initialize this class from outside.
	}

	private static DriverFactory instance= new DriverFactory();
	
	public static DriverFactory getInstance(){
		return instance;
	}
	static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();//{ We are making WebDriver Thread- Safe with the help of ThreadLocal
/*@Override
protected WebDriver initialValue(){
	return new FirefoxDriver();
		}
	};*/
public static WebDriver getDriver(){
	return driver.get();
	}

public static void removeDriver(){
	
	System.out.println("Error may be here");
	driver.get().quit();
	driver.remove();
	}

/*
public static void removeDriver(){
	System.out.println("Error may be here");
	driver.get().quit();
	driver.remove();
	}*/
}
