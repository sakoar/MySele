package com.veo.base;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.veo.base.DriverFactory;
import com.veo.util.ErrorUtil;
import com.veo.util.Xls_Reader;


public class LocalTestBase {

	 public WebDriver driver = DriverFactory.getInstance().getDriver();
	 public static Properties CONFIG=null;
	 public static Xls_Reader Aus_Veo_TestData_XLS= null;
	 public static Xls_Reader Aus_Veo_TestData_XLS2= null;
	 public static Xls_Reader Reporting_Veo_XLS= null;
	 public static Xls_Reader Veo_TestData_XLS= null;
	 
	 public static boolean isInitalized=false;
	 public static Logger APP_LOGS=null;
	 public static int count=-1;

@Parameters({ "nodeURL", "OS", "browser","testEnv" })
@BeforeClass
public void setUp(String nodeURL, Platform OS, String browser, String testEnv) throws Throwable {
	initialize(testEnv);
	
	DesiredCapabilities cap = new DesiredCapabilities();
	cap.setPlatform(OS);
	if(browser.equalsIgnoreCase("firefox")) {
		cap=DesiredCapabilities.firefox();
	}
	if(browser.equalsIgnoreCase("chrome")) {
		cap=DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		/*Proxy proxy = new Proxy();
		proxy.setHttpProxy("qastaging.can.veo.bat.biz:443");
		cap.setCapability(CapabilityType.PROXY, proxy);
		*/System.out.println("Inside Chrome");
		}
	if(browser.equalsIgnoreCase("Internet Explorer")) {
		cap=DesiredCapabilities.internetExplorer();
	}
	if(browser.equalsIgnoreCase("safari")) {
		cap=DesiredCapabilities.safari();
	}
	try {
		driver = new RemoteWebDriver(new URL(nodeURL),cap);
		driver.manage().window().maximize();
	} 
	catch (MalformedURLException e)
	{
		e.printStackTrace();
		throw new Exception("Browser Could not Launch in "+nodeURL +"machine. Please check the Grid set up.");
	}
}
//=======================================================================================
/*	public void setUp(String nodeURL, Platform OS, String browser,String testEnv) throws Throwable {
	//public void localTest(){
		initialize(testEnv);
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setPlatform(OS);
		if(browser.equalsIgnoreCase("firefox"))
			cap=DesiredCapabilities.firefox();
		if(browser.equalsIgnoreCase("chrome"))
			cap=DesiredCapabilities.chrome();
		if(browser.equalsIgnoreCase("Internet Explorer"))
			cap=DesiredCapabilities.internetExplorer();
		if(browser.equalsIgnoreCase("safari"))
			cap=DesiredCapabilities.safari();

		try {
			driver = new RemoteWebDriver(new URL(nodeURL),cap);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Exception("Browser Could not Launch in "+nodeURL +"machine. Please check the Grid set up.");

		}
		
		driver.get(CONFIG.getProperty("stagging_url"));*/
//=======================================================================================
/*		driver.get(CONFIG.getProperty("staggingAUS_Site"));
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		prntResults("Browser Up and Launched the App URL");
*/
}


public void initialize(String Env) throws Exception
{
	if(!isInitalized)
	{
		APP_LOGS = Logger.getLogger("devpinoyLogger");
		Reporting_Veo_XLS = new Xls_Reader(System.getProperty("user.dir")+"//WebAnalytics_Reports//WebAnalytics_Reports.xlsx"); 
		CONFIG = new Properties();
		if(Env.equalsIgnoreCase("DEV"))
		{
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config//DEVconfig.properties");
			CONFIG.load(ip);
			prntResults("############## The Environment parameter is chosen as "+Env);
			Veo_TestData_XLS =  new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Veo_TestData_DEV.xlsx");
		}
		else if(Env.equalsIgnoreCase("QA"))
		{
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config//QAconfig.properties");
			CONFIG.load(ip);
			prntResults("############### The Environment parameter is chosen as "+Env);
			Veo_TestData_XLS =  new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Veo_TestData_QA.xlsx");
		}
		else if(Env.equalsIgnoreCase("STAGING"))
		{
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config//STAGINGconfig.properties");
			CONFIG.load(ip);
			prntResults("############## The Environment parameter is chosen as "+Env);
			Veo_TestData_XLS =  new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Veo_TestData_STAGING.xlsx");
		}
		isInitalized=true;
		prntResults("Loaded All Files");
	}
}

@AfterClass
public void TearDown() throws InterruptedException{
	Thread.sleep(2000);
	//driver.close();
	driver.quit();
	//DriverFactory.getInstance().removeDriver();
	prntResults("------- End of Test Case -------");
}

//WAIT FOR ELEMENT
public void WaitUntil_element_tobe_clicked(WebElement element,int Time)throws Exception
{
	try
	{
	WebDriverWait wait = new WebDriverWait(driver, Time); 
	wait.until(ExpectedConditions.elementToBeClickable(element)); 
	}
	catch (Exception e) 
	{			
		// reports		
		ErrorUtil.addVerificationFailure(e);		
		APP_LOGS.debug("Could not wait until element to be clicked"+element);		
		Reporter.log("Could not wait until element to be clicked"+element);	
		throw new Exception('\n'+"==============================="+'\n'+"Hello Human: I could not wait until element to be clicked, please check it manually"+element);
}
}
//initializing the Tests
	public void initialize() throws Exception
	{
		// logs
		if(!isInitalized)
		{
			APP_LOGS = Logger.getLogger("devpinoyLogger");
			APP_LOGS.debug("Loading Property files");
			Reporter.log("Loading Property files");
			Reporting_Veo_XLS = new Xls_Reader(System.getProperty("user.dir")+"//WebAnalytics_Reports//WebAnalytics_Reports.xlsx"); 
		
			CONFIG = new Properties();
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config/config.properties");
			CONFIG.load(ip);

			APP_LOGS.debug("Loaded Property files successfully");
			Reporter.log("Loaded Property files successfully");
			APP_LOGS.debug("Loading XLS Files");
			Reporter.log("Loading XLS Files");

			// xls file
			Aus_Veo_TestData_XLS = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Aus_Desktop_Cart_Suite.xlsx");
			Aus_Veo_TestData_XLS2 = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Aus_Desktop_Cart_Suite2.xlsx");
			Veo_TestData_XLS =  new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Veo_TestData.xlsx");
			APP_LOGS.debug("Loaded XLS Files successfully");
			isInitalized=true;
			prntResults("Loaded All Files");
		}
	}
	
	public static void prntResults(String sMessage)
	{
		System.out.println(sMessage);
		APP_LOGS.debug(sMessage);
		Reporter.log(sMessage);
		}
	public void capturescreenshot(String filename) throws IOException
	{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\"+filename.substring(0, filename.indexOf('_'))+"\\"+filename+".jpg"));
	}
	public void moveToElement(WebDriver driver, WebElement element)throws Exception
	{
	try {
		
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
		APP_LOGS.debug("Moved to specified element successfully");
		Reporter.log("Moved to specified element successfully");
		System.out.println("Moved to specified element successfully");
		
	} catch (Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		APP_LOGS.debug("Failed: Cannot able to move to the specified element");
		Reporter.log("Failed: Cannot able to move to the specified element");
		throw new Exception("Failed: Cannot be able to move to the specified element", e);
		}
	}

	public boolean verifyPageSourceContains(String PageName, String sMessage) throws Exception
	{              
		Thread.sleep(2000);	
		if(driver.getPageSource().contains(sMessage))
		{
			prntResults("As Expected page Source of "+PageName+" page has "+sMessage);
			return true;
		}
		else{
			prntResults("Failed as Expected page Source of the page "+PageName+" doesnt have "+sMessage);
			throw new Exception("Failed as Expected page Source of the page "+PageName+" doesnt have "+sMessage);
		}
	}
	
	/***************************************************************************
	 * Function Name: switchTonextTab
	 * Description: Opens a New Tab
	 * Parameters: None
	 * Created on: 05/01/2017
	 * Created By: Suren
	 ***************************************************************************/

	public void switchTonextTab()throws Exception 
	{
		//opens a new tab
		try
		{
			//Switching between tabs using CTRL + tab keys.
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL ,"t");				 
			//Switch to current selected tab's content.
			//driver.switchTo().defaultContent();  
			prntResults("opening new window tab");
			Thread.sleep(1000);
		}
		catch (Exception exception) 
		{
			 ErrorUtil.addVerificationFailure(exception);
			 prntResults("Failed to open to new tab and Failed to navigate to ValidationPage");
			 throw new Exception("Failed: Failed to open to new tab and Failed to navigate to ValidationPage" ,exception);
        }
	
	}
//#########################  SREE #########################
	
public void rightClick(WebDriver driver,String locator)throws Exception
{
	try
	{
		WebElement element = driver.findElement(By.xpath(locator));
	     Actions act2 = new Actions(driver);
	     act2.moveToElement(element).contextClick(element).perform();
	     prntResults("Sucessfully Right clicked on the Element --"+element);    
	}
	catch (Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		prntResults("FAILED: Not able to Right click on the Element --"+locator);
		throw new Exception("FAILED: Not able to Right click on the Element", e);
	}
}

public static boolean isAlertPresent(WebDriver driver)throws Exception{
 
try
{
	Alert alert = driver.switchTo().alert();
	System.out.println(alert.getText());
	Thread.sleep(3000);
	alert.accept();
	prntResults("Swicthed to Alert popup and Clicked on OK Button");
    return true;
}
catch(NoAlertPresentException exception)
{
	prntResults("Couldnot handle the Alert popup");    	
	throw new Exception("Failed: Couldnot handle the Alert popup",exception);
}

}

public void DoubleClick(WebDriver driver,String locator)throws Exception
{
try
{	    
	WebElement element2 = driver.findElement(By.xpath(locator));
	Actions action = new Actions(driver).doubleClick(element2);
	action.build().perform();	     
	prntResults("Double Click on the Element " +locator);
}
catch (Exception e) 
{
	ErrorUtil.addVerificationFailure(e);
	prntResults("Failed: Double Click on Element " + locator);
	throw new Exception("Failed: Double Click on Element "+locator+" ---", e);
}
}

public void dropdownByVisibleText(WebDriver driver, WebElement element,String str)throws Exception
{
	try
	{
		Select sel = new Select(element);
		sel.selectByVisibleText(str);
		prntResults("Selected the option "+str+" from the dropdown");
	}
	catch(Throwable exception)
	{
		ErrorUtil.addVerificationFailure(exception); 
		prntResults("Failed: Couldnot select the option "+str+" from the dropdown");
		throw new Exception("Failed: Couldnot select the option "+str+" from the dropdown", exception);
	}
}
public String[] return_local_time() throws Exception
{

	final SimpleDateFormat f = new SimpleDateFormat("hh:mm:ss a");
	f.setTimeZone(TimeZone.getTimeZone("UTC"));

	String date = f.format(new Date());
	Date d = f.parse(f.format(new Date())); 
	Calendar cal = Calendar.getInstance();
	cal.setTime(d);


	cal.add(Calendar.MINUTE, 01);
	cal.add(Calendar.SECOND, 45);
	String newTime1 = f.format(cal.getTime());

	cal.add(Calendar.MINUTE, 20);
	String newTime2 = f.format(cal.getTime());

	Date date2 = new Date();
	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/YYYY");
	String datee = formatter.format(date2);

	 String output[] = new String[5];
	 output[0]= datee;
	 output[1] =  newTime1;
	 output[2] = newTime2;
     return output;
}
//#######################################  RUTH & SUREN ##############################
public void ignoreAndContinue(WebDriver driver) throws Exception
{
try{
int num = driver.findElements(By.xpath(".//*[@id='ignore-soft-block']")).size();
System.out.println("Ignore & Cont size is = "+num);
	if (!(num == 0)) 
		{
			prntResults("Clicking on Ignore & continue button");
			driver.findElement(By.cssSelector("#ignore-soft-block")).click();
		}
	else{
			prntResults("Landing in Order Review Page");
		}
	Thread.sleep(3000);
}
catch(Throwable exception){
		
		ErrorUtil.addVerificationFailure(exception); 
		prntResults("Failed: Not able to click on Ignore and continue");
		throw new Exception("Failed: Not able to click on Ignore and continue Link", exception);	
		}
}
public String BackofficeFindElements(WebDriver driver,String xpath,int j) throws Exception
{
	String linkText ="";
try
{
		int size1 = driver.findElements(By.xpath(xpath)).size();
		prntResults("Element size is :"+size1);
		if(!(size1 == 0))
		{
			linkText = driver.findElements(By.xpath(xpath)).get(j).getText();
		}
		else
		{
			capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			System.err.println("ERROR --- No Search Results Found");
			throw new Exception("ERROR --- No Search Results Found");
		}
	}

catch(Exception e) 
{
ErrorUtil.addVerificationFailure(e); 
prntResults("Not able to get the "+j+" row orders"); 
throw e;
}
return linkText;
}  

public void press_Tab_button(WebDriver driver) throws Exception
{
	try
	{
		prntResults("Pressing TAB button");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.TAB); 
	}
	catch(Throwable exception){
		ErrorUtil.addVerificationFailure(exception);
		prntResults("Failed to Press TAB");
		throw new Exception("Failed to Press TAB");
	}
}
public void dropdownByValue(WebDriver driver, WebElement element,String str)throws Exception 
{
	try
	{
		Select sel = new Select(element);
		sel.selectByValue(str);
		prntResults("Selected option "+str+" from the dropdown");
	}
	catch(Throwable exception)
	{
		ErrorUtil.addVerificationFailure(exception); 
		prntResults("Failed: Couldnot select the option "+str+" from the dropdown");
		throw new Exception("Failed: Couldnot select the option "+str+" from the dropdown", exception);
	}
}
public void press_Enter_button(WebDriver driver) throws Exception
{
	try
	{
		prntResults("Pressing Enter button");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ENTER); 
	}
	catch(Throwable exception){
		ErrorUtil.addVerificationFailure(exception);
		prntResults("Failed to Press Enter");
		throw new Exception("Failed to Press Enter");
	}
}
public void open_New_Tab(WebDriver driver)throws Exception 
{
	//opens a new tab
	try
	{
		//Switching between tabs using CTRL + tab keys.
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL ,"t");				 
		//Switch to current selected tab's content.
		//driver.switchTo().defaultContent();  
		prntResults("opening new window tab");
		Thread.sleep(2000);
	}

	catch (Exception exception) 
	{
		 ErrorUtil.addVerificationFailure(exception);
		 prntResults("Failed to open to new tab");
		 throw new Exception("Failed: Failed to open to new tab " ,exception);
    }
}	

public void switchToTab()throws Exception 
{
	try
	{
		//Switching between tabs using CTRL + tab keys.
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"\t");				 
		//Switch to current selected tab's content.
		driver.switchTo().defaultContent();
		prntResults("Switching to new window tab");
		Thread.sleep(2000);
	}
	catch (Exception exception) 
	{
		  // reports
		  ErrorUtil.addVerificationFailure(exception);
		  prntResults("Failed to switch to new tab and Failed to navigate to ValidationPage");
		  throw new Exception("Failed: Failed to switch to new tab and Failed to navigate to ValidationPage" ,exception);
		  //return false;
	}
 }	

public String resetPassword(String password) throws Exception
{
	int myNum=795;	
	Random rand = new Random();
	int myNewNo= rand.nextInt(myNum+1);
	String myNewStr =Integer.toString(myNewNo);
	String myNewPassword = password+myNewStr;

	prntResults("The Dynamically modified passsword is: "+myNewPassword);
	return myNewPassword;

}

public void DoubleClick_Element(WebDriver driver,WebElement element)throws Exception
{
try
{
	Actions action = new Actions(driver).doubleClick(element);
	action.build().perform();	     
	prntResults("Double Click on the Element " +element);
}
catch (Exception e) 
{
	ErrorUtil.addVerificationFailure(e);
	prntResults("Failed: Double Click on Element " + element);
	throw new Exception("Failed: Double Click on Element "+element+" ---", e);
}
}
public void capturescreenshot() throws IOException
{
	/*File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\"+filename.substring(0, filename.indexOf('_'))+"\\"+filename+".jpg"));*/
	
	    File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    String filename1 =  new SimpleDateFormat("yyyyMMddhhmmss'.txt'").format(new Date());
	    String filename2 =  this.getClass().getSimpleName();
	    File dest = new File(System.getProperty("user.dir")+"\\screenshots\\"+filename1+"_"+filename2+".jpg");
        FileUtils.copyFile(scr, dest);
	}

public void CaptureScreenshot_On_Failure() throws IOException
{
	    File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);		
	    String filename2 =  this.getClass().getSimpleName();	    
	    String filename1 =  new SimpleDateFormat("yyyyMMddhhmmss'.txt'").format(new Date());	  
	    String filename3 =  filename2.substring(0,filename2.indexOf('_'));    
	    File dest = new File(System.getProperty("user.dir")+"\\screenshots\\"+filename1+"_"+filename2+"_"+filename3+".jpg");
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\"+filename2.substring(0, filename2.indexOf('_'))+"\\"+filename1+"_"+filename2+"_"+filename3+".jpg"));  
}

public static WebElement isElementPresnt(WebDriver driver,String xpath,int time)
{
  
WebElement ele = null;
 
for(int i=0;i<time;i++)
{
try{
ele=driver.findElement(By.xpath(xpath));
break;
}
catch(Exception e)
{
try 
{
Thread.sleep(3000);
} catch (InterruptedException e1) 
{
System.out.println("Waiting for element to appear on DOM");
}
} 
}
return ele;
}

}

