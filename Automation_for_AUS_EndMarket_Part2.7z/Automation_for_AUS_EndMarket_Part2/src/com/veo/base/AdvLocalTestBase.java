package com.veo.base;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import com.veo.util.ErrorUtil;
import com.veo.util.Xls_Reader;


public class AdvLocalTestBase {

	public ThreadLocal<RemoteWebDriver> driver = null;
	public static Properties CONFIG=null;
	public static Xls_Reader Aus_Veo_TestData_XLS= null;
	public static boolean isInitalized=false;
	public static Logger APP_LOGS=null;


@Parameters({ "nodeURL", "OS", "browser" })
@BeforeClass
public void setUp(String nodeURL, Platform OS, String browser) throws Throwable {
	//Assign driver to a ThreadLocal
    driver = new ThreadLocal<>();
    	//public void localTest(){
			initialize();
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setPlatform(OS);
		if(browser.equalsIgnoreCase("firefox"))
			cap=DesiredCapabilities.firefox();
		if(browser.equalsIgnoreCase("chrome"))
			cap=DesiredCapabilities.chrome();
		if(browser.equalsIgnoreCase("Internet Explorer"))
			cap=DesiredCapabilities.internetExplorer();
		if(browser.equalsIgnoreCase("safari"))
			cap=DesiredCapabilities.safari();

		try {
			 cap.setCapability("browserName", browser);
		     driver.set(new RemoteWebDriver(new URL(nodeURL), cap));
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Exception("Browser Could not Launch in "+nodeURL +"machine. Please check the Grid set up.");

		}
		
		getDriver().navigate().to((CONFIG.getProperty("staggingAUS_Site")));
		//getDriver().(CONFIG.getProperty("staggingAUS_Site"));
		/*driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();*/
		prntResults("Browser Up and Launched the App URL");

	}
	public WebDriver getDriver() {
       return driver.get();
 	}

	@AfterClass
	public void tearDown() throws Exception {
		getDriver().quit();
	}


//initializing the Tests
	public void initialize() throws Exception
	{
		// logs
		if(!isInitalized)
		{
			APP_LOGS = Logger.getLogger("devpinoyLogger");
			APP_LOGS.debug("Loading Property files");
			Reporter.log("Loading Property files");

			CONFIG = new Properties();
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"//src//com//veo//config/config.properties");
			CONFIG.load(ip);

			APP_LOGS.debug("Loaded Property files successfully");
			Reporter.log("Loaded Property files successfully");
			APP_LOGS.debug("Loading XLS Files");
			Reporter.log("Loading XLS Files");

			// xls file
			Aus_Veo_TestData_XLS = new Xls_Reader(System.getProperty("user.dir")+"//src//com//veo//xls//Aus_Desktop_Cart_Suite.xlsx");
			APP_LOGS.debug("Loaded XLS Files successfully");
			isInitalized=true;
			prntResults("Loaded All Files");
		}
	}
	public static void prntResults(String sMessage)
	{
		System.out.println(sMessage);
		APP_LOGS.debug(sMessage);
		Reporter.log(sMessage);
		}
	public void capturescreenshot(String filename) throws IOException
	{
		File scrFile = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\"+filename.substring(0, filename.indexOf('_'))+"\\"+filename+".jpg"));
	}
	public void moveToElement(WebElement element)throws Throwable,Exception
	{
	try {
		Actions action = new Actions(getDriver());
		action.moveToElement(element).build().perform();
		APP_LOGS.debug("Moved to specified element successfully");
		Reporter.log("Moved to specified element successfully");
		System.out.println("Moved to specified element successfully");
	} catch (Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		APP_LOGS.debug("Failed: Cannot able to move to the specified element");
		Reporter.log("Failed: Cannot able to move to the specified element");
		throw new Exception("Failed: Cannot be able to move to the specified element", e);
	
		}
	}

}
