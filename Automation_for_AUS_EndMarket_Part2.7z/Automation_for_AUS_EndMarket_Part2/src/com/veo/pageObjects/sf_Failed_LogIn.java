package com.veo.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class sf_Failed_LogIn extends sf_LogIn_page{

	public sf_Failed_LogIn(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
	}

}
