package com.veo.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class bo_Cart_Page extends LocalTestBase{
	String BfrDeliveryDate=null;

@FindBy(css="#amend-order-button")
public WebElement bo_CartPage_AmendBtn;

@FindBy(css="#cancelAmend")
public WebElement bo_CartPage_CancelBtn;

@FindBy(css="#a-cancel-order-yes")
public WebElement bo_CartPage_Cancel_YesBtn;

@FindBy(css="#modal-cancel-existing-order-block>div>div>div.modal-footer>div>button")
public WebElement bo_CartPage_Cancel_NoBtn;

@FindBy(css="#revert-changes-button")
public WebElement bo_CartPage_RevertBtn;

@FindBy(xpath="//*[@id='on-hand-inv-carton-0']")
public WebElement bo_CartPage_Invntry_OnHandCT;

@FindBy(xpath="//*[@id='on-hand-inv-pack-0']")
public WebElement bo_CartPage_Invntry_OnHandPK;

@FindBy(xpath="//*[@id='quantity-0']")
public WebElement bo_CartPage_OrderQntity;

@FindBy(css="a[title='Continue']")
public WebElement bo_CartPage_Continue;

@FindBy(css="#review-success-place-order")
public WebElement bo_CartPage_PlaceOrder;

@FindBy(css="button[class='refresh z-button-os']")
public WebElement bo_HomePage_RefreshBtn;

@FindBy(css="input[class='z-datebox-inp'][tabindex='11']")
public WebElement bo_HomePage_StartDate;

@FindBy(css="input[class='z-datebox-inp'][tabindex='12']")
public WebElement bo_HomePage_EndDate;

@FindBy(css="span[ytestid='emergencyCheckBox']>input[type='checkbox']")
public WebElement bo_HomePage_EmergencyCheckBox;

@FindBy(css="input[ytestid='erpTextBox']")
public WebElement bo_HomePage_ERP_TxtBox;

@FindBy(css="input[class='z-combobox-inp'][tabindex='15']")
public WebElement bo_HomePage_OrderType;

@FindBy(css="i[ytestid='statusComboBox']>input[class='z-combobox-inp']")
public WebElement bo_HomePage_OrderStatus;

@FindBy(css="i[ytestid='orderCountToDisplay']>input[class='z-combobox-inp']")
public WebElement bo_HomePage_OrderCountDisplay;

@FindBy(css="#emergency-cb")
public WebElement bo_CartPage_EmergencyCheckbox;

@FindBy(css="#deliveryDate")
public WebElement bo_CartPage_DeliveryDateTxtBox;

@FindBy(css="#close-amend-button")
public WebElement bo_CartPage_SaveandCloseBtn;

@FindBy(css="#close-amend-link")
public WebElement bo_CartPage_SaveandClose_Yes;

@FindBy(css=".btn.btn-default.btn-sm.fl.enabled")
public WebElement bo_CartPage_SaveandClose_No;
@FindBy(xpath=".//*[@id='cart-filter']")
public WebElement bo_CartPage_FilterSearch;

public void implicit_Wait_ID(WebDriver driver,long time) throws Exception{

    for(int i=0;i<20;i++)
    {
        try
        {   
         int number = driver.findElements(By.cssSelector("#amend-order-button")).size();
         System.out.println(number);          
         if((number>0))
         {
        	prntResults("Validating the presence of amend button");  
        	break;
         }
         else
         {
            Thread.sleep(time);
         }
         }        
        catch(Exception e)
        {
        	Thread.sleep(time);
        }
    }    
}
public void implicit_Wait_ID2(WebDriver driver,long time) throws Exception{

    for(int i=0;i<20;i++)
    {
        try
        {   
         int number = driver.findElements(By.cssSelector("#revert-changes-button")).size();
         System.out.println(number);          
         if((number>0))
         {
        	prntResults("Validating the presence of revert button");  
        	break;
         }
         else
         {
            Thread.sleep(time);
         }
         }        
        catch(Exception e)
        {
        	Thread.sleep(time);
        }
    }    
}


public void BO_Cancellation_Order(WebDriver driver,String OrderStatus,String CancelStatus) throws Exception
{
	try
	{
		int amendBtnCount = driver.findElements(By.cssSelector("#amend-order-button")).size();
		if((amendBtnCount>0))
		{
			if((CancelStatus.equalsIgnoreCase("Yes"))&&(OrderStatus.equalsIgnoreCase("Flagged")))
			{
				bo_CartPage_AmendBtn.click();
				Thread.sleep(3000);
				bo_CartPage_CancelBtn.click();
				bo_CartPage_Cancel_YesBtn.click();
				Thread.sleep(3000);
			}
			else if((CancelStatus.equalsIgnoreCase("No"))&&(OrderStatus.equalsIgnoreCase("Flagged")))
			{
				bo_CartPage_AmendBtn.click();
				Thread.sleep(2000);
				bo_CartPage_CancelBtn.click();
				Thread.sleep(1000);
				bo_CartPage_Cancel_NoBtn.click();
				Thread.sleep(2000);
			}		
			else
			{
			}
		}
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e);
		System.err.println("Not able to cancel the selected order");
		throw new Exception("Not able to cancel the selected order",e);
	}
}


@FindBy(xpath=".//*[@id='ignore-soft-block']")
public WebElement Ignore_SoftBlock;

public void BO_Amending_Order(WebDriver driver,int Qty) throws Exception
{
	if(bo_CartPage_RevertBtn.isDisplayed())
	{
		prntResults("Revert Button is displayed !!!");
		bo_CartPage_OrderQntity.clear();
		bo_CartPage_OrderQntity.sendKeys(Integer.toString(Qty));
		bo_CartPage_Continue.click();
		//Thread.sleep(3000);		
		 implicit_Wait_ID_Sree(Ignore_SoftBlock,5000);			
		 ignoreAndContinue(driver);		 
		 implicit_Wait_ID_Sree(bo_CartPage_PlaceOrder,5000);				
		//Thread.sleep(2000);
		 bo_CartPage_PlaceOrder.click();
		 //implicit_Wait_ID_Sree(bo_CartPage_AmendBtn, 5000);				
		//Thread.sleep(3000);
		prntResults("Success: Order is placed Successfully !!!");

	}
	else
	{
		prntResults("Revert Button is not displayed !!!");
		throw new Exception("Revert Button is not displayed !!!");
	}
}
public void implicit_Wait_ID_Sree(WebElement element,long time) throws Exception{

	/*int z= 20;
	Time*/
    for(int i=0;i<40;i++)
    {    
    	try
        { 
         Dimension number = element.getSize();
         System.out.println(number); 

         int x = number.getHeight();
         int y = number.getWidth();
         
         if((x>0)||(y>0))
         {
        	prntResults("Validating the presence of "+element);  
        	break;
         }
         else
         {
            Thread.sleep(time);
         }
        
} 
   catch(Exception e)
{
	Thread.sleep(time);
}
    }}

public String New_BO_Set_Unset_EmergencyFlag() throws Exception
{
	try
	{
		bo_CartPage_AmendBtn.click();
		if((bo_CartPage_EmergencyCheckbox.isSelected()))
		{
			prntResults("This is an Emergency Order");
			BfrDeliveryDate = bo_CartPage_DeliveryDateTxtBox.getAttribute("Value");
			prntResults("Expected Delivery Date before changing is: "+BfrDeliveryDate);
			Thread.sleep(1000);
			bo_CartPage_EmergencyCheckbox.click();
			prntResults("Unchecked the Emergency Flag");
			Thread.sleep(2000);
			bo_CartPage_SaveandCloseBtn.click();
			prntResults("Clicked on Save and Close Button");
			Thread.sleep(2000);
			bo_CartPage_SaveandClose_Yes.click();
			prntResults("Clicked on Yes in Save and Close Button");	
			Thread.sleep(2000);
}
		else
		{
			BfrDeliveryDate = bo_CartPage_DeliveryDateTxtBox.getAttribute("Value");
			prntResults("Expected Delivery Date before changing is: "+BfrDeliveryDate);
			bo_CartPage_EmergencyCheckbox.click();
			prntResults("Checked the Emergency Flag");
			Thread.sleep(2000);
			bo_CartPage_FilterSearch.click();			
			Thread.sleep(2000);
			bo_CartPage_SaveandCloseBtn.click();
			prntResults("Clicked on Save and Close Button");
			Thread.sleep(2000);
			bo_CartPage_SaveandClose_Yes.click();
			prntResults("Clicked on Yes in Save and Close Button");	
			Thread.sleep(2000);
		}
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		prntResults("Failed in Delivery Date Calculation step");
		throw new Exception("Failed in Delivery Date Calculation step", e);
	}
	return BfrDeliveryDate;
}
public String deliveryDateValidation(String BfrDeliveryDate) throws Exception
{
	String AftrDeliveryDate=null;
	try
	{

			AftrDeliveryDate = bo_CartPage_DeliveryDateTxtBox.getAttribute("Value");
			prntResults("Expected Delivery Date After removing Emergency falg is: "+AftrDeliveryDate);
			Thread.sleep(2000);
			prntResults("Deliveerryyyyy : "+BfrDeliveryDate);
			Assert.assertFalse(BfrDeliveryDate.equals(AftrDeliveryDate),"\n===================="+"\nHello Human: Test FAILED ---- Delivery Date is not Changed, Pls check manually"+"\n=================================");
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		prntResults("Failed in Delivery Date Calculation step");
		throw new Exception("Failed in Delivery Date Calculation step", e);
	}
	return BfrDeliveryDate;
}
}
