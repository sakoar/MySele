package com.veo.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class sf_HomePage extends LocalTestBase {

@FindBy(css="h1.text-center")
public WebElement Home_Page_CenterText;

@FindBy(id="popover-menu")
public WebElement Home_Page_Menu_button;

@FindBy(id="button-header-create-order")
public WebElement Home_Page_CreateOrder_button;

@FindBy(id = "main-search")
public WebElement Home_Page_MainSearch;

@FindBy(id="store-info-menu")
public WebElement Home_Page_InfoMenu;

@FindBy(id="my-account-menu")
public WebElement Home_Page_ManIcon;

@FindBy(linkText="Privacy Policy")
public WebElement Home_Page_PrivacyPolicy;

@FindBy(linkText="Glossary")
public WebElement Home_Page_Glossary;

@FindBy(css = "#about>ul>li>a[href='/contactUs']")
public WebElement Home_Page_Help_Contact;

@FindBy(css = "#about>ul>li>a[title*='About']")
public WebElement Home_Page_About_us;

@FindBy(css="#about>ul>li>a[title*='Terms']")
public WebElement Home_Page_TermsandConditions;

@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>a[title='My Capture']")
public WebElement Menu_MyCapture;

@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>ul>li>a[title='Price Capture']")
public WebElement Menu_MyCapture_PriceCapture;
	
@FindBy(css="div[id='error-modal']>div>div>div>div>div>p")
public WebElement Clerk_NotPermitted_Message;

@FindBy(xpath="//button[contains(.,'OK')]")
public WebElement Clerk_NotPermitted_OkButton;

@FindBy(xpath=".//*[@id='main-search']")
public WebElement Home_Page_SearchBox;

@FindBy(xpath="//h1[contains(.,'Search Results')]")
public WebElement Home_Page_ResultsFound_Products;

@FindBy(xpath=".//*[@id='header-widget']/header-widget-container/header-widget-avatar")
public WebElement Home_Page_Comarch_IKon;

@FindBy(xpath="//div/div[2]/nav/ul/li[1]/a/i")
public WebElement ManIcon_MyAccount_Button;

@FindBy(xpath="//div/div[2]/nav/ul/li[2]/a/i")
public WebElement ManIcon_OrderHistory_Button;

@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>a[title='My Programs']")
public WebElement Menu_MyPrograms;

@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>ul>li>a[title='Listing Page']")
public WebElement Menu_MyPrograms_ListingPage;

@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>ul>li>a[title='Tracking Page']")
public WebElement Menu_MyPrograms_TrackingPage;

@FindBy(css=".popover-content>.popover-in-header.popover-xxs>ul>li>a[href='/my-account/orders']")
public WebElement ManIkon_OrderHistory;

@FindBy(xpath=".//*[@id='error-modal']/div/div/div[2]/div/div[2]/p")
public WebElement Clerk_NotPermitted;

@FindBy(xpath=".//*[@id='error-modal']/div/div/div[3]/button")
public WebElement Clerk_OkButton;


public void verifyHomeMenu(SoftAssert s_assert) throws Exception{
	try{
		//Home page center text
		s_assert.assertTrue(Home_Page_CenterText.isDisplayed(),"Home_Page_CenterText Failed");
		s_assert.assertTrue(Home_Page_CenterText.isEnabled(),"Home_Page_CenterText Failed");
		s_assert.assertEquals(Home_Page_CenterText.getText(),"HOME","Home_Page_CenterText Failed");
		}
	      catch(Exception e)
			{
			System.err.println("Failed to verify the presence of HOME in center");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("No HOME text found on the top center of the page, please check once manually", e);
			}

	try{
		//Menu Button 
		s_assert.assertTrue(Home_Page_Menu_button.isDisplayed());
		s_assert.assertTrue(Home_Page_Menu_button.isEnabled());
		}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of Menu Button");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("Menu text found on the top center of the page, please check once manually", e);
			}

	try{
		//Search box
		s_assert.assertTrue(Home_Page_MainSearch.isDisplayed());
		s_assert.assertTrue(Home_Page_MainSearch.isEnabled());
		}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of Search box");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("Search box not found on the HOME page, please check once manually",e);
			}
	try{
		//Home page info
		s_assert.assertTrue(Home_Page_InfoMenu.isDisplayed());
		s_assert.assertTrue(Home_Page_InfoMenu.isEnabled());
			}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of Info Icon in center");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("Info icon not found on the home page, please check once manually", e);
			}
	try{
		//Man Icon info
		s_assert.assertTrue(Home_Page_ManIcon.isDisplayed());
		s_assert.assertTrue(Home_Page_ManIcon.isEnabled());
			}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of Man Icon in center");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("Man icon not found on the home page, please check once manually", e);
			}
}


public void verifyHomeFooter(SoftAssert s_assert) throws Exception{
	
	try{
	//Help & Contact Link
		s_assert.assertTrue(Home_Page_Help_Contact.isDisplayed());
		s_assert.assertTrue(Home_Page_Help_Contact.isEnabled());
	//Assert.assertEquals("Help & Contact", Home_Page_Help_Contact.getText());
	}catch(Exception e)
		{
		System.err.println("Failed to verify the presence of link Help & Contact");
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("No Help & Contact link found, please check once manually", e);
		}
	try{
	//About Us link
		s_assert.assertTrue(Home_Page_About_us.isDisplayed());
		s_assert.assertTrue(Home_Page_About_us.isEnabled());
	//Assert.assertEquals("About us", Home_Page_About_us.getText());
	}catch(Exception e)
		{
		System.err.println("Failed to verify the presence of link About Us");
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("No About Us link found, please check once manually", e);
		}

	try{
	//Privacy Policy Link
		s_assert.assertTrue(Home_Page_PrivacyPolicy.isDisplayed());
		s_assert.assertTrue(Home_Page_PrivacyPolicy.isEnabled());
		s_assert.assertEquals("Privacy Policy", Home_Page_PrivacyPolicy.getText());
	}catch(Exception e)
		{
		System.err.println("Failed to verify the presence of link Privacy Policy");
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("No Privacy Policy link found, please check once manually", e);
		}

	try{
	//Glossary Link
		s_assert.assertTrue(Home_Page_Glossary.isDisplayed());
		s_assert.assertTrue(Home_Page_Glossary.isEnabled());
		s_assert.assertEquals("Glossary", Home_Page_Glossary.getText());
	}catch(Exception e)
		{
		System.err.println("Failed to verify the presence of link Glossary");
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("No Glossary link found, please check once manually", e);
		}
	}

public void MenuItems(WebDriver driver,String item) throws Exception
{
	//The item values: Home,Products,News & Events,FAQ,, My Documents, Alternative Product Guide
	try
	{	Thread.sleep(1000);
		Home_Page_Menu_button.click();
		Thread.sleep(1000);
		String locator = "div[class='popover-content']>nav>ul>li>a[title='"+item+"']";
		driver.findElement(By.cssSelector(locator)).click();
		prntResults("Successfully navigated to "+item+" page");
		Thread.sleep(1000);
	}catch(Exception exception)
	{
		System.err.println("Failed to click on "+item+" from menu");
		prntResults("Failed to click on "+item+" from menu");
		ErrorUtil.addVerificationFailure(exception);
		throw new Exception("Failed to click on "+item+" from menu", exception);
	}
}

public void Click_On_SubMenuItems(WebDriver driver,String item) throws Exception
{ 
	try
	{
		String locator = "div[class='popover-content']>nav>ul>li[class='second-level']>ul>li>a[title='"+item+"']";
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(locator)).click();
		prntResults("clicked on "+item+" from menu");
		Thread.sleep(3000);
	}catch(Exception exception)
	{
		System.err.println("Failed to click on "+item+" from menu");
		prntResults("Failed to click on "+item+" from menu");
		ErrorUtil.addVerificationFailure(exception);
		throw new Exception("Failed to click on "+item+" from menu", exception);
       }
}


public void MainSearchBox(String productname) throws Exception
{
	Home_Page_SearchBox.click();
	System.out.println("clicked searchBox");
	Home_Page_SearchBox.clear();
	System.out.println("Searcgh Clear");
	Home_Page_SearchBox.sendKeys(productname);
	System.out.println("Send Keys on search");
	Home_Page_SearchBox.sendKeys(Keys.RETURN);
}

public void Click_On_FooterItems(WebDriver driver, String item) throws Exception
{ 
	try
	{
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("div[id='about']>ul>li>a[title='"+item+"']")).click();
		Thread.sleep(2000);
		prntResults("clicked on "+item+" in Footer Section"); 
	}catch(Exception exception)
	{
		System.err.println("Failed to click on "+item+" in Footer Section");
		prntResults("Failed to click on "+item+" in Footer Section");
		ErrorUtil.addVerificationFailure(exception);
		throw new Exception("Failed to click on "+item+" in Footer Section", exception);
       }
} 

public void Verify_HomePage_ProductSearch(WebDriver driver, String productname) throws Exception
{
	//Thread.sleep(2000);
	Home_Page_SearchBox.click();
	prntResults("clicked Product SearchBox");
	Thread.sleep(1000);
	Home_Page_SearchBox.clear();
	Home_Page_SearchBox.sendKeys(productname);
	prntResults("Entered product name as "+productname);
	Thread.sleep(1000);
	Home_Page_SearchBox.sendKeys(Keys.RETURN);
	prntResults("Pressed Enter Key");
	Thread.sleep(2000);
	String results = Home_Page_ResultsFound_Products.getText();
	Assert.assertEquals("SEARCH RESULTS", results);
	prntResults("Validation successfull for MainSearchBox for Product Name "+productname);
}

public void NavigateToMyAccountPage() throws Exception
{
	Home_Page_ManIcon.click();
	Thread.sleep(1000);
	ManIcon_MyAccount_Button.click();
	Thread.sleep(1000);
	prntResults("Successfully navigated to My Account page");
}

public void NavigateToOrderHistory() throws Exception
{
	Home_Page_ManIcon.click();
	Thread.sleep(1000);
	ManIcon_OrderHistory_Button.click();
	Thread.sleep(1000);
	prntResults("Successfully navigated to My Account page");
}

public void NavigateToOrderHistory(String usertype) throws Exception
{
	Home_Page_ManIcon.click();
	Thread.sleep(1000);
	ManIcon_OrderHistory_Button.click();
	Thread.sleep(2000);
	if(usertype.equalsIgnoreCase("Engagement Clerk"))
    {
    	Clerk_NotPermitted_OkButton.click();
    	prntResults("Clicked on Ok Button");
    	Thread.sleep(2000);
    }else
    {
    	prntResults("Successfully navigated to My Account page");
    }
}

public void verifyCT_PA_values_homePage(WebDriver driver,String CT_value, String PA_value) throws Exception
{
	String locator = ".//*[@id='right-content']/div[2]/div[contains(.,'"+CT_value+"') and contains(.,'"+PA_value+"')]";
	if(driver.findElement(By.xpath(locator)).isDisplayed())
	{
		prntResults("As Expected CT and PA values are displayed as "+ CT_value+" and "+PA_value +" in homepage");
	}
	else{
		throw new Exception("Failed : As CT and PA values are displayed as "+ CT_value+" and "+PA_value +" in homepage");
	}
}

public void Navigate_MyPrograms(WebDriver driver,String MyProgram_Name,String UserType) throws Exception{

	try
	{		
		if(MyProgram_Name.equalsIgnoreCase("Listing Page"))
		{
			if(UserType.equalsIgnoreCase("Retailer")|| UserType.equalsIgnoreCase("FullyTrusted Clerk")) {
				Home_Page_Menu_button.click();
				Thread.sleep(1000);
				Menu_MyPrograms.click();
				Thread.sleep(1000);
				Menu_MyPrograms_ListingPage.click();
				Thread.sleep(2000);
			}
			else if(UserType.equalsIgnoreCase("Trusted Clerk")||UserType.equalsIgnoreCase("Engagement Clerk"))
			{
				Home_Page_Menu_button.click();
				Thread.sleep(1000);
				Menu_MyPrograms.click();
				Thread.sleep(1000);
				Menu_MyPrograms_ListingPage.click();
				Thread.sleep(1000);
				Assert.assertEquals(Clerk_NotPermitted.getText(), "Your permissions do not allow you to view my programs page.");
				Thread.sleep(2000);
				Clerk_OkButton.click();
				Thread.sleep(2000);
			}
		}
		else
		{
			if(UserType.equalsIgnoreCase("Retailer")|| UserType.equalsIgnoreCase("FullyTrusted Clerk")) 
			{
				Home_Page_Menu_button.click();
				Thread.sleep(1000);
				Menu_MyPrograms.click();
				Thread.sleep(1000);
				Menu_MyPrograms_TrackingPage.click();
				Thread.sleep(1000);
			}
			else if(UserType.equalsIgnoreCase("Trusted Clerk")||UserType.equalsIgnoreCase("Engagement Clerk"))
			{
				Home_Page_Menu_button.click();
				Thread.sleep(1000);
				Menu_MyPrograms.click();
				Thread.sleep(1000);
				Menu_MyPrograms_TrackingPage.click();
				Thread.sleep(1000);
				Assert.assertEquals(Clerk_NotPermitted.getText(), "Your permissions do not allow you to view my performance page.");
				Thread.sleep(1000);
				Clerk_OkButton.click();
				Thread.sleep(1000);
			}
		}
	}
	catch(Exception e)
		{
		System.err.println("Failed to click My Programs ->"+MyProgram_Name+" Page");
		capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("Failed to click My Programs ->"+MyProgram_Name+" Page", e);
		}
}
/*public static final String ERROR_DIV_ID = "main-search";

@FindBy(id = "main-search")
private WebElement errorDiv;

public void WaitUntil_Presenceof_ElementLocated(int Time)throws Exception
{
	try
	{
	WebDriverWait wait = new WebDriverWait(driver, Time); 
	wait.until(ExpectedConditions.presenceOfElementLocated((By.id(ERROR_DIV_ID))));
	}
	catch (Exception e) 
	{			
		// reports		
		ErrorUtil.addVerificationFailure(e);		
		
		throw new Exception("Failed:Could not wait until element to be present in the page"+xpathKey);
}*/


@FindBy(id = "main-search")
public WebElement errorDiv;

public WebElement isElementLoaded(WebElement elementToBeLoaded,int Time) {
    WebDriverWait wait = new WebDriverWait(driver, Time);
    WebElement element = wait.until(ExpectedConditions.visibilityOf(elementToBeLoaded));
    return element;
}
}

