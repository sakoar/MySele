package com.veo.pageObjects;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;

public class sf_Cart_inventry_Page extends LocalTestBase {

@FindBy(id="target-inv-1")
public WebElement targetInvntryValue;

@FindBy(xpath="//*[@id='on-hand-inv-carton-1']")
public WebElement onHandInvntryCarton;

@FindBy(xpath="//*[@id='on-hand-inv-pack-1']")
public WebElement onHandInvntryPack;

@FindBy(xpath="//*[@id='soq-1']")
public WebElement SOQ_Qty;


@FindBy(xpath="//*[@id='on-hand-inv-carton-1']")   //....///////////////////////////////////////////////////////////////////////////
public WebElement onHandInvntryCarton1;

@FindBy(xpath="//*[@id='on-hand-inv-pack-1']") //....///////////////////////////////////////////////////////////////////////////
public WebElement onHandInvntryPack1;

//@FindBy(xpath="//*[@id='soq-1']")
//public WebElement SOQ_Qty1;

@FindBy(xpath="//*[@id='quantity-1']")
public WebElement OrderQntity1;

public void OrderWithLowOrZeroQty(String OrdrQty) throws Exception{
	Thread.sleep(3000);
	onHandInvntryCarton1.clear();
	onHandInvntryPack1.clear();
	OrderQntity1.sendKeys(OrdrQty);
	OrderQntity1.sendKeys(Keys.TAB);
	}

public void targetInvntryValue(WebDriver driver,String productID,String value,String InvntryQty) throws Exception{
	Thread.sleep(8000);
	String TargetInventryLocator="//*[@id='target-inv-"+value+"']"; 
	WebElement TargetInvntry = driver.findElement(By.xpath(TargetInventryLocator));
	Thread.sleep(5000);
	prntResults("Invntry value is:"+TargetInvntry.getAttribute("value") );
	Assert.assertEquals(TargetInvntry.getAttribute("value"), InvntryQty);  //This is to check if correct order returned after search
	}


public void targetInvntryValue(String InvntryQty) throws Exception
{
	Thread.sleep(5000);
	Assert.assertEquals(targetInvntryValue.getAttribute("value"), InvntryQty);
}


public void InventryOnHand(WebDriver driver,String ProductID,String ele) throws InterruptedException, Exception{
	System.out.println("In InventryOnHand method");
	//String value= targetInvntryValue.getAttribute("value");
	//Target Invntry Value
		//String locator = ".//*[@id='cart-table']/tbody/tr/td[@id='"+ProductID+"']/following-sibling::td[@class='col-target-inv']/span[@class='product-col-val']/input[@class='r-o tac sortdata']";
		//WebElement targetInvntryValue = driver.findElement(By.xpath(locator));
	Thread.sleep(2000);
	String TargetInventryLocator="//*[@id='target-inv-"+ele+"']"; 
	WebElement targetInvntryValue = driver.findElement(By.xpath(TargetInventryLocator));
	
	String value= targetInvntryValue.getAttribute("value");
		
	Double CTtoPK = Double.parseDouble(value)*10; //converting CARTON value to PACKET -it is in double
	int CTtoPKInt = Integer.valueOf(CTtoPK.intValue()); //converting double to int
		
	Random rand = new Random();
	int PK_Total= rand.nextInt(CTtoPKInt+1); //applying random in PK total
	System.out.println("PK Tot"+PK_Total);
	int CT = Math.round(PK_Total/10);
	int PK = rand.nextInt((CTtoPKInt/10-CT)*10);
	
	System.out.println("CT: "+CT);
	System.out.println("PK: "+PK);
	
	String CT_Value=Integer.toString(CT); //String conversion for SENDKEYS
	String PK_Value=Integer.toString(PK); 
	
//On Hand Inventry Carton	
	//WebElement onHandInvntryCarton = driver.findElement(By.xpath(".//*[@id='cart-table']/tbody/tr/td[@id='"+ProductID+"']/following-sibling::td[@class='col-inv-onhand-c']/span/input[not(@type='hidden')]"));
	
	WebElement onHandInvntryCarton =driver.findElement(By.xpath("//*[@id='on-hand-inv-carton-"+ele+"']"));
	//*[@id='on-hand-inv-carton-1']
//On Hand Invntry Pack
	//WebElement onHandInvntryPack = driver.findElement(By.xpath(".//*[@id='cart-table']/tbody/tr/td[@id='"+ProductID+"']/following-sibling::td[@class='col-inv-onhand-p']/span/input[not(@type='hidden')]"));
	WebElement onHandInvntryPack = driver.findElement(By.xpath(".//*[@id='on-hand-inv-pack-"+ele+"']"));
	
	onHandInvntryCarton.sendKeys(CT_Value);
	onHandInvntryPack.sendKeys(PK_Value);
	onHandInvntryPack.sendKeys(Keys.TAB);
	Thread.sleep(1500);


	
//Expected Value Calculation	
	double CTtoPK1=Math.round(Double.parseDouble(value))*10;
	System.out.println("CTtoPK1: "+CTtoPK1);  //Master Value
	
	//Carton Value as in CT
	System.out.println(" Entered CT value: "+CT);
	double CTdbl = (double)CT*10;        //Entered Value in CT field
	System.out.println("CTNew double value:"+CTdbl);
	
	//Packet Value as in PK
	System.out.println("Entered PK value: "+PK);
	//Now Entered value of PK gets Converted into CT
	double PKtoCT=(double)PK;
	System.out.println("double PKtoCT value: "+PKtoCT);
	//double PK2CTNew=Math.round(PKtoCT); //Calculation of Entered PK value 
	//System.out.println("CTNew value: "+PK2CTNew);
	System.out.println("Before SOQ_Calucate "+(CTtoPK1-(CTdbl+PKtoCT))/10);
	double SOQ_Calculated = Math.round((CTtoPK1-(CTdbl+PKtoCT))/10);
	System.out.println("SOQ_Calculated value in double round off format"+SOQ_Calculated);
	int SOQ_Value=(int)SOQ_Calculated;
	System.out.println("SOQ_ExpectedValue in int format : "+SOQ_Value);	
	String SOQ_Expected =Integer.toString(SOQ_Value); 	
	WebElement SOQ_Qty = driver.findElement(By.xpath(".//*[@id='cart-table']/tbody/tr/td[@id='"+ProductID+"']/following-sibling::td[@class='soq col-soq']/span[@class='product-col-val']/input[@class='r-o tac']"));
	System.out.println("SOQ Actual:" +SOQ_Qty.getAttribute("value"));		
	//Assert.assertEquals(SOQ_Qty.getAttribute("value"), SOQ_Expected);
	Assert.assertEquals(SOQ_Qty.getAttribute("value"), SOQ_Expected, "Hello Humann: SOQ Value Check Fails, please log a defect");	
	//capturescreenshot(this.getClass().getSimpleName()+"_SOQ_Assertion_Screen");
	System.out.println("Assertion Successful");
	
	 }
public void InventryOnHand() throws Exception{
	System.out.println("In InventryOnHand method");
	String value= targetInvntryValue.getAttribute("value");
		
	Double CTtoPK = Double.parseDouble(value)*10; //converting CARTON value to PACKET -it is in double
	int CTtoPKInt = Integer.valueOf(CTtoPK.intValue()); //converting double to int
		
	Random rand = new Random();
	int PK_Total= rand.nextInt(CTtoPKInt+1); //applying random in PK total
	System.out.println("PK Tot "+PK_Total);
	int CT = Integer.parseInt("5");
			//Integer.parseInt(CTValue);Math.round(PK_Total/10);
	int PK = Integer.parseInt("2");
			//rand.nextInt((CTtoPKInt/10-CT)*10)Integer.parseInt(PKValue);;
	
	System.out.println("CT: "+CT);
	System.out.println("PK: "+PK);
	
	String CT_Value=Integer.toString(CT); //String conversion for SENDKEYS
	String PK_Value=Integer.toString(PK); 
	
	onHandInvntryCarton.sendKeys(CT_Value);
	onHandInvntryPack.sendKeys(PK_Value);
	onHandInvntryPack.sendKeys(Keys.TAB);
	Thread.sleep(1500);
	
	System.out.println("SOQ Actual:" +SOQ_Qty.getAttribute("value"));
	
	//Expected Value Calculation	
	double CTtoPK1=Math.round(Double.parseDouble(value))*10;
	System.out.println("CTtoPK1: "+CTtoPK1);  //Master Value
	
	//Carton Value as in CT
	System.out.println(" Entered CT value: "+CT);
	double CTdbl = (double)CT*10;        //Entered Value in CT field
	System.out.println("CTNew double value:"+CTdbl);
	
	//Packet Value as in PK
	System.out.println("Entered PK value: "+PK);
	//Now Entered value of PK gets Converted into CT
	double PKtoCT=(double)PK;
	System.out.println("double PKtoCT value: "+PKtoCT);
	//double PK2CTNew=Math.round(PKtoCT); //Calculation of Entered PK value 
	//System.out.println("CTNew value: "+PK2CTNew);
	double SOQ_Calculated = Math.round((CTtoPK1-(CTdbl+PKtoCT))/10);
	int SOQ_Value=(int)SOQ_Calculated;
	System.out.println("SOQ_ExpectedValue : "+SOQ_Value);
	
	String SOQ_Expected =Integer.toString(SOQ_Value); 
			
	Assert.assertEquals(SOQ_Qty.getAttribute("value"), SOQ_Expected);
	System.out.println("Assertion Successful");
	
}

@FindBy(xpath="//*[@id='quantity-1']")
public WebElement OrderQntity;

@FindBy(id="continue")
public WebElement Continue_button;

//PopUp check
@FindBy(xpath="//*[@id='modal-soft-block']/div/div/div[1]/h2")
public WebElement popUpTitle;

@FindBy(xpath="//*[@id='modal-soft-block']/div/div/div[2]/div/div[2]/p[2]")
public WebElement popUpMesage;

@FindBy(id="button-soft-block-amend-order")
public WebElement ChangeOrderButton;

@FindBy(xpath="//*[@id='page-content']/div/div[2]/p")
public WebElement messageOnCartPage;

public void OrderPopUpLowQty() throws Exception{
	if(popUpTitle.getText().equalsIgnoreCase("Please check your order")){
	Assert.assertEquals(popUpTitle.getText(), "Please check your order");
	Assert.assertEquals(popUpMesage.getText(), "Please increase your order to a minimum of 10 whole cartons.");
	ChangeOrderButton.click();
	Assert.assertEquals(messageOnCartPage.getText(), "Please increase your order to a minimum of 10 whole cartons.");
	}
	else{
		throw new Exception('\n'+"=================================="+'\n'+"Hello Human: I can't see the D-Rule pop up for Low or Zero order quantity."+'\n'+"Please log a defect."+'\n'+"==================================");
	}
}


public void OrderQtyTest(WebDriver driver, String ProductID) throws Exception{
WebElement OrderQntity = driver.findElement(By.xpath(".//*[@id='cart-table']/tbody/tr/td[@id='"+ProductID+"']/following-sibling::td[@class='order-qty col-order-qty']/span/input"));	
		OrderQntity.clear();
for(int i=9;i<=11;i++){
	System.out.println("Order Qty is: "+i);
	OrderQntity.clear();
	OrderQntity.sendKeys(Integer.toString(i));
	OrderQntity.sendKeys(Keys.TAB);
	Continue_button.click();
	Thread.sleep(2000);
		if(i>=10){
			break;	
			}
	OrderPopUpLowQty();
	}
try{
	System.out.println("Should be able to continue in Review page");
	Continue_button.click();
	}catch (Exception e){
		throw new Exception('\n'+"========================="+'\n'+"Hello Human: Issue with D-Rules.It's a Defect."+'\n'+"Pop Up restriction is still showing for Order Quantity equal to 10 or more."+'\n'+"=========================");
	}
}

public void OrderQtyTest() throws Exception
{
		OrderQntity.clear();
for(int i=9;i<=11;i++){
	OrderQntity.clear();
	OrderQntity.sendKeys(Integer.toString(i));
	OrderQntity.sendKeys(Keys.TAB);
	Continue_button.click();
	Thread.sleep(2000);
	if(i>=10){
			break;	
		}
	OrderPopUpLowQty();
	}
try{
	System.out.println("Should be able to continue in Review page");
	Continue_button.click();
	}catch (Exception e){
		throw new Exception('\n'+"========================="+'\n'+"Hello Human: Issue with D-Rules.It's a Defect."+'\n'+"Pop Up restriction is still showing for Order Quantity equal to 10 or more."+'\n'+"=========================",e);
	}
}

/**************************
 * Check for Lower Quantity
 *******************/
@FindBy (css="div.popover-content")
public WebElement softAllertOnLoqQnty;

public void lowerQty(WebDriver driver, String ProductID) throws Exception{
	System.out.println("In targetInvntryValue() method");
	WebElement searchResult = driver.findElement(By.xpath("//*[@id='cart-table']/tbody/tr/td[@id='"+ProductID+"']/following-sibling::td[@class='col-product-id']/span[not(@class='product-id hidden')]"));
	Thread.sleep(1000);
	String locatorID = 	searchResult.getAttribute("id");
	
	System.out.println("LOCATOR ID IS: "+locatorID);
	
	int rowNum = locatorID.length()-1;
	Character Char = locatorID.charAt(rowNum);
	System.out.println("Ele re Ele...kaisi e paheli again: "+Char);

	//SOQ	
		WebElement SOQ_Qty = driver.findElement(By.xpath("//*[@id='soq-"+Char+"']"));
	String SOQ=SOQ_Qty.getAttribute("value");
	System.out.println("The SOQ value in application is "+SOQ);
	int SOQint = Integer.parseInt(SOQ);
	double lowQty = Math.round(SOQint*0.8);
	System.out.println("80% of qty: "+(int)lowQty);
	int testQnty = new Random().nextInt((int)lowQty);
	System.out.println("Random Nxt Qty:"+testQnty);
	WebElement OrderQntity=driver.findElement(By.xpath("//*[@id='quantity-"+Char+"']"));
	
	String SOQLowValue = Integer.toString(testQnty);
			OrderQntity.sendKeys(SOQLowValue);
			System.out.println("Qty entered: "+SOQLowValue);
			OrderQntity.sendKeys(Keys.TAB);
		System.out.println("Soft Message: "+softAllertOnLoqQnty.getText());	
		Assert.assertEquals(softAllertOnLoqQnty.getText(), "Your order quantity is low");
		
	}
public void lowerQty(){
	String SOQ=SOQ_Qty.getAttribute("value");
	int SOQint = Integer.parseInt(SOQ);
	double lowQty = Math.round(SOQint*0.8);
	System.out.println("80% of qty: "+(int)lowQty);
	int testQnty = new Random().nextInt((int)lowQty);
	System.out.println("Random Nxt Qty:"+testQnty);
	String SOQLowValue = Integer.toString(testQnty);
			OrderQntity.sendKeys(SOQLowValue);
			System.out.println("Qty entered: "+SOQLowValue);
			OrderQntity.sendKeys(Keys.TAB);
		System.out.println("Soft Message: "+softAllertOnLoqQnty.getText());	
		Assert.assertEquals(softAllertOnLoqQnty.getText(), "Your order quantity is low");
		
	}
/*****************************
 * Order Test with 0 order quantity
 */
@FindBy(xpath="//*[@id='modal-soft-block']/div/div/div[2]/div/div[2]/p[3]")
public WebElement NoQtyMesage;


@FindBy(xpath="//*[@id='page-content']/div/div[2]/p[2]")
public WebElement NoQtyMesage2;

@FindBy(xpath="//*[@id='modal-soft-block']/div/div/div[2]/div/div[2]/p[2]")
			   
public WebElement NoQtyMesage3;

@FindBy(css="p.fr.tar")
public WebElement MsgeNextToQtyBox;

@FindBy(xpath="//*[@id='ignore-soft-block']")
public WebElement Ignore_nContinue;


public void OrderPopUpZeroQty1() throws Exception{
	if(popUpTitle.getText().equalsIgnoreCase("Please check your order")){
		System.out.println("In if condition for Zero Ordr Qty"+popUpTitle.getText());
		Assert.assertEquals(popUpTitle.getText(), "Please check your order");
		Assert.assertEquals(popUpMesage.getText(), "Please increase your order to a minimum of 10 whole cartons.");
		Assert.assertEquals(NoQtyMesage.getText(), "Order with zero value cannot be submitted");
		ChangeOrderButton.click();
	
	Assert.assertEquals(NoQtyMesage2.getText(), "Order with zero value cannot be submitted");
	System.out.println("Test Passed for: OrderPopUpZeroQty method");
	}
	else{
		System.err.println('\n'+"=================================="+'\n'+"Hello Human:  The D-Rule pop up is not displaying for Low or Zero order quantity."+'\n'+"Please log a defect."+'\n'+"==================================");
		prntResults('\n'+"=================================="+'\n'+"Hello Human:  The D-Rule pop up is not displaying for Low or Zero order quantity."+'\n'+"Please log a defect."+'\n'+"==================================");
		throw new Exception('\n'+"=================================="+'\n'+"Hello Human:  The D-Rule pop up is not displaying for Low or Zero order quantity."+'\n'+"Please log a defect."+'\n'+"==================================");
	}
	}

public void OrderPopUpZeroQty() throws Exception{
	if(popUpTitle.isDisplayed()==true){
		System.out.println("In if condition for Zero Ordr Qty"+popUpTitle.getText());
	Assert.assertEquals(popUpTitle.getText(), "Please check your order");
	Assert.assertEquals(popUpMesage.getText(), "Please increase your order to a minimum of 10 whole cartons.");
	Assert.assertEquals(NoQtyMesage.getText(), "Order with zero value cannot be submitted");
	ChangeOrderButton.click();
	
	Assert.assertEquals(NoQtyMesage2.getText(), "Order with zero value cannot be submitted");
	System.out.println("Test Passed for: OrderPopUpZeroQty method");
	}
	else{
		System.out.println("In else condition for Zero Ordr Qty");
		throw new Exception('\n'+"=================================="+'\n'+"Hello Human: I can't see the D-Rule pop up for Low or Zero order quantity."+'\n'+"Please log a defect."+'\n'+"==================================");
	}
	}
	
public void OrderPopForNoInvntryQTY(String userDecision) throws Exception{ //userDecision = Change Order or Continue
	Assert.assertEquals(popUpTitle.getText(), "Please check your order");
	//Assert.assertEquals(popUpMesage.getText(), "Please increase your order to a minimum of 10 whole cartons.");
	//Assert.assertEquals(NoQtyMesage.getText(), "Order with zero value cannot be submitted");
	Assert.assertEquals(NoQtyMesage3.getText(), "Products are missing from your on-hand inventory.");
		if(userDecision.equalsIgnoreCase("Change Order")){
			ChangeOrderButton.click();
			Assert.assertEquals(MsgeNextToQtyBox.getText(), "On-hand inventory missing for product.");
			System.out.println("Test Passed for: OrderPopForNoInvntryQTY method");
		}
		else if(userDecision.equalsIgnoreCase("IgnoreNContinue")){
			Ignore_nContinue.click();
		}
	}
}


