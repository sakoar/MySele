package com.veo.pageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class sf_Home extends LocalTestBase{

	/***************************************************************************
		The Top Menu Bar of HOME Page
	***************************************************************************/	
	@FindBy(css="h1.text-center")
	public WebElement Home_Page_CenterText;

	@FindBy(id="popover-menu")
	public WebElement Home_Page_Menu_button;

	@FindBy(id="button-header-create-order")
	public WebElement Home_Page_CreateOrder_button;

	@FindBy(id="main-search")
	public WebElement Home_Page_MainSearch;

	@FindBy(id="store-info-menu")
	public WebElement Home_Page_InfoMenu;

	@FindBy(id="my-account-menu")
	public WebElement Home_Page_ManIcon;



	public void verifyHomeMenu() throws Exception{
		
		try{
			//Home page center text
			Assert.assertTrue(Home_Page_CenterText.isDisplayed());
			Assert.assertTrue(Home_Page_CenterText.isEnabled());
			Assert.assertEquals(Home_Page_CenterText.getText(),"HOME");
			}catch(Exception e)
				{
				System.err.println("Failed to verify the presence of HOME in center");
				ErrorUtil.addVerificationFailure(e);
				throw new Exception("No HOME text found on the top center of the page, please check once manually");
				}

		try{
			//Menu Button 
			Assert.assertTrue(Home_Page_Menu_button.isDisplayed());
			Assert.assertTrue(Home_Page_Menu_button.isEnabled());
			}catch(Exception e)
				{
				System.err.println("Failed to verify the presence of Menu Button");
				ErrorUtil.addVerificationFailure(e);
				throw new Exception("Menu text found on the top center of the page, please check once manually");
				}

		try{
			//Search box
			Assert.assertTrue(Home_Page_MainSearch.isDisplayed());
			Assert.assertTrue(Home_Page_MainSearch.isEnabled());
			}catch(Exception e)
				{
				System.err.println("Failed to verify the presence of Search box");
				ErrorUtil.addVerificationFailure(e);
				throw new Exception("Search box not found on the HOME page, please check once manually");
				}
		try{
			//Home page info
			Assert.assertTrue(Home_Page_InfoMenu.isDisplayed());
			Assert.assertTrue(Home_Page_InfoMenu.isEnabled());
				}catch(Exception e)
				{
				System.err.println("Failed to verify the presence of Info Icon in center");
				ErrorUtil.addVerificationFailure(e);
				throw new Exception("Info icon not found on the home page, please check once manually");
				}
		try{
			//Man Icon info
			Assert.assertTrue(Home_Page_ManIcon.isDisplayed());
			Assert.assertTrue(Home_Page_ManIcon.isEnabled());
				}catch(Exception e)
				{
				System.err.println("Failed to verify the presence of Man Icon in center");
				ErrorUtil.addVerificationFailure(e);
				throw new Exception("Man icon not found on the home page, please check once manually");
				}
		
	}

	/***************************************************************************
	The Footer of HOME Page
	***************************************************************************/	
	@FindBy(linkText="Help & Contact")
	public WebElement Home_Page_Help_Contact;

	@FindBy(linkText="About us")
	public WebElement Home_Page_About_us;


	@FindBy(linkText="Privacy Policy")
	public WebElement Home_Page_PrivacyPolicy;


	@FindBy(linkText="Glossary")
	public WebElement Home_Page_Glossary;

	@FindBy(linkText="Terms And Conditions")
	public WebElement Home_Page_TermsandConditions;



	public void verifyHomeFooter() throws Exception{
		
		try{
		//Help & Contact Link
		Assert.assertTrue(Home_Page_Help_Contact.isDisplayed());
		Assert.assertTrue(Home_Page_Help_Contact.isEnabled());
		Assert.assertEquals("Help & Contact", Home_Page_Help_Contact.getText());
		}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of link Help & Contact");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("No Help & Contact link found, please check once manually");
			}
		try{
		//About Us link
		Assert.assertTrue(Home_Page_About_us.isDisplayed());
		Assert.assertTrue(Home_Page_About_us.isEnabled());
		Assert.assertEquals("About us", Home_Page_About_us.getText());
		}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of link About Us");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("No About Us link found, please check once manually");
			}

		try{
		//Privacy Policy Link
		Assert.assertTrue(Home_Page_PrivacyPolicy.isDisplayed());
		Assert.assertTrue(Home_Page_PrivacyPolicy.isEnabled());
		Assert.assertEquals("Privacy Policy", Home_Page_PrivacyPolicy.getText());
		}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of link Privacy Policy");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("No Privacy Policy link found, please check once manually");
			}

		try{
		//Glossary Link
		Assert.assertTrue(Home_Page_Glossary.isDisplayed());
		Assert.assertTrue(Home_Page_Glossary.isEnabled());
		Assert.assertEquals("Glossary", Home_Page_Glossary.getText());
		}catch(Exception e)
			{
			System.err.println("Failed to verify the presence of link Glossary");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("No Glossary link found, please check once manually");
			}
		}

	/*
	 
				ErrorUtil.addVerificationFailure(exception);
				capturescreenshot(this.getClass().getSimpleName() + "_" + count);
				throw exception;
	 */
	/*
		public By Home_page_HelpandContact_Link = By.cssSelector("a[title*='Help & Contact']");
		public By Menu_button = By.cssSelector("#popover-menu");
		public By FAQ_button = By.cssSelector(".fa.fa-question-circle.fa-1-7x");
		public By MyDocuments_button = By.cssSelector("div[class*='popover-content']>nav>ul>li>a[title*='My Documents']");
		public By Homepage_header = By.cssSelector("div[class='col-xs-12']>h1");
		public By Create_Order_button = By.cssSelector("a[href^='/cart']");
		
		*/

	public void MenuItems(WebDriver driver, String item) throws Exception
	{
		//The item values: Home,Products,News & Events,FAQ,, My Documents, Alternative Product Guide
		try
		{
			Home_Page_Menu_button.click();
			driver.findElement(By.cssSelector("div[class='popover-content']>nav>ul>li>a[title='"+item+"']")).click();
			prntResults("Successfully navigated to "+item+" page");
		}catch(Exception exception)
		{
			System.err.println("Failed to click on "+item+" from menu");
			prntResults("Failed to click on "+item+" from menu");
			ErrorUtil.addVerificationFailure(exception);
			throw new Exception("Failed to click on "+item+" from menu");
		}
	}

	@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>a[title='My Capture']")
	public WebElement Menu_MyCapture;


	@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>ul>li>a[title='Price Capture']")
	public WebElement Menu_MyCapture_PriceCapture;
		

	@FindBy(xpath="//div/div[2]/nav/ul/li[1]/a/i")
	public WebElement ManIcon_MyAccount_Button;

	@FindBy(xpath="//div/div[2]/nav/ul/li[2]/a/i")
	public WebElement ManIcon_OrderHistory_Button;


	public void NavigateToMyAccountPage() throws Exception
	{
		Home_Page_ManIcon.click();
		ManIcon_MyAccount_Button.click();
		prntResults("Successfully navigated to My Account page");

	}


	public void NavigateToOrderHistory() throws Exception
	{
		Home_Page_ManIcon.click();
		ManIcon_OrderHistory_Button.click();
		prntResults("Successfully navigated to My Account page");

	}



	@FindBy(xpath=".//*[@id='right-content']/div[2]/div")
	public WebElement Home_ExciseMonitor_Values;


	public void verifyCT_PA_values_homePage(WebDriver driver,String CT_value, String PA_value) throws Exception
	{
		
		if(CT_value.equalsIgnoreCase("")||PA_value.equalsIgnoreCase(""))
		{
			int count = driver.findElements(By.xpath(".//*[@id='right-content']/div[2]/div")).size();
			if(count>0)
			{
				prntResults("Failed as CT and PA values are displayed in Home page");
				throw new Exception("Failed as CT and PA values are displayed in Home page");
			}
			else{
				prntResults("As Expected CT and PA values are not displayed in Home page");
			}
		}
		else
		{
		String locator = ".//*[@id='right-content']/div[2]/div[contains(.,'"+CT_value+"') and contains(.,'"+PA_value+"')]";
		if(driver.findElement(By.xpath(locator)).isDisplayed())
		{
			prntResults("As Expected CT and PA values are displayed as "+ CT_value+" and "+PA_value +" in homepage");
		}
		else{
			throw new Exception("Failed : As CT and PA values are displayed as "+ CT_value+" and "+PA_value +" in homepage");
		}
		}
	}




	@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>a[title='My Programs']")
	public WebElement Menu_MyPrograms;

	@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>ul>li>a[title='Listing Page']")
	public WebElement Menu_MyPrograms_ListingPage;

	@FindBy(css="div[class='popover-content']>nav[class='popover-in-header popover-xs']>ul>li[class='second-level']>ul>li>a[title='Tracking Page']")
	public WebElement Menu_MyPrograms_TrackingPage;


	@FindBy(css=".popover-content>.popover-in-header.popover-xxs>ul>li>a[href='/my-account/orders']")
	public WebElement ManIkon_OrderHistory;


	@FindBy(xpath=".//*[@id='error-modal']/div/div/div[2]/div/div[2]/p")
	public WebElement Clerk_NotPermitted;

	@FindBy(xpath=".//*[@id='error-modal']/div/div/div[3]/button")
	public WebElement Clerk_OkButton;


	public void Navigate_MyPrograms(WebDriver driver,String MyProgram_Name,String UserType) throws Exception{
		
		try{
			
			if(MyProgram_Name.equalsIgnoreCase("Listing Page"))
			{
				if(UserType.equalsIgnoreCase("Retailer")|| UserType.equalsIgnoreCase("FullyTrusted Clerk")) {
					Home_Page_Menu_button.click();
					Menu_MyPrograms.click();
					Menu_MyPrograms_ListingPage.click();
				}
				else if(UserType.equalsIgnoreCase("Trusted Clerk")||UserType.equalsIgnoreCase("Engagement Clerk"))
				{
					Home_Page_Menu_button.click();
					Menu_MyPrograms.click();
					Menu_MyPrograms_ListingPage.click();
					Assert.assertEquals(Clerk_NotPermitted.getText(), "Your permissions do not allow you to view my programs page.");
					Clerk_OkButton.click();
				}
			}
			else
			{
				if(UserType.equalsIgnoreCase("Retailer")|| UserType.equalsIgnoreCase("FullyTrusted Clerk")) 
				{
					Home_Page_Menu_button.click();
					Menu_MyPrograms.click();
					Menu_MyPrograms_TrackingPage.click();
				}
				else if(UserType.equalsIgnoreCase("Trusted Clerk")||UserType.equalsIgnoreCase("Engagement Clerk"))
				{
					Home_Page_Menu_button.click();
					Menu_MyPrograms.click();
					Menu_MyPrograms_TrackingPage.click();
					Assert.assertEquals(Clerk_NotPermitted.getText(), "Your permissions do not allow you to view my performance page.");
					Clerk_OkButton.click();
				}
			}
	}
		catch(Exception e)
			{
			System.err.println("Failed to click My Programs ->"+MyProgram_Name+" Page");
			capturescreenshot(this.getClass().getSimpleName()+"_"+MyProgram_Name);
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("Failed to click My Programs ->"+MyProgram_Name+" Page");
			}
		}

	}


