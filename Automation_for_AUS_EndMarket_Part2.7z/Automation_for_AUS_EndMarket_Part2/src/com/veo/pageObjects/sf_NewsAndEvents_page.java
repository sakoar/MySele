package com.veo.pageObjects;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;

public class sf_NewsAndEvents_page extends LocalTestBase {

@FindBy(css=".row>h1")
public WebElement NewEventHeader;

@FindBy(css=".fa.fa-chevron-right")
public WebElement Msg_Nextbtn;

@FindBy(css="#newsCarousel>article>.clearfix.mt15>h3")
public WebElement MsgItemHeader;

@FindBy(css = "[id='widget-calendar']>div[class='controls veo-yellow']>a>i[class='fa fa-chevron-right']")
public WebElement Right_Navigation_Arrow;

@FindBy(css = "[id='widget-calendar']>div[class='controls veo-yellow']>a>i[class='fa fa-chevron-left']")
public WebElement Left_Navigation_Arrow;

@FindBy(css = "#date-pickerSelectBoxItText")
public WebElement MonthPicker;

@FindBy(css = ".fc-header-title>h2")
public WebElement CurrentMonthHeader;

@FindBy(xpath = "//tr[3]/td[2]/div")
public WebElement CalenderRandomDay;

@FindBy(xpath = "//a[contains(.,'Add event')]")
public WebElement AddEvent;

@FindBy(xpath = ".//*[@id='new-event-title']")
public WebElement NewEventTitleTextBox;

@FindBy(xpath = ".//*[@id='new-event-start-date']")
public WebElement NewEventStartDateTextBox;

@FindBy(xpath = ".//*[@id='new-event-end-date']")
public WebElement NewEventEndDateTextBox;

@FindBy(xpath = ".//*[@id='new-event-description']")
public WebElement NewEventDescriptionTextBox;

@FindBy(xpath = ".//*[@id='save-event']")
public WebElement NewEventSubmitButton;

@FindBy(css = ".fc-event.fc-event-hori.fc-event-start.fc-event-end.personal")
public WebElement CreatedPersonalEvent;

@FindBy(css = ".event-popover-info.fl")
public WebElement CreatedPersonalEventTitle;

@FindBy(css = ".fa.fa-edit.fa-lg")
public WebElement EditCreatedPersonalEvent;

@FindBy(css = ".delete-event")
public WebElement DeleteCreatedPersonalEvent;


public boolean verifyMonth(String str) throws Exception
{
	if(str.equalsIgnoreCase("currentmonth")){
		String month=getMonth("currentmonth");
		if((CurrentMonthHeader.getText()).equalsIgnoreCase(month)){
			prntResults("The displayed month is : "+month);
			return true;
		}
	}
	else if(str.equalsIgnoreCase("previousmonth")){
		String month=getMonth("previousmonth");
		if((CurrentMonthHeader.getText()).equalsIgnoreCase(month)){
			prntResults("The displayed month is : "+month);
			return true;	
		}
	}
	else if(str.equalsIgnoreCase("nextmonth")){
		String month=getMonth("nextmonth");
		if((CurrentMonthHeader.getText()).equalsIgnoreCase(month)){
			prntResults("The displayed month is : "+month);
			return true;	
		}
	}
	else
		throw new Exception("Unknown Parameter");
	return false;
}

public String getMonth(String str) throws Exception
{
	Calendar c = new GregorianCalendar();
	c.setTime(new Date());
	SimpleDateFormat sdf = new SimpleDateFormat("MMMM YYYY");
	
	if(str.equalsIgnoreCase("currentmonth"))
		return sdf.format(c.getTime());	// Current month

	else if(str.equalsIgnoreCase("previousmonth"))
	{
		c.add(Calendar.MONTH, -1);	return sdf.format(c.getTime());	// One month ago
	}

	else if(str.equalsIgnoreCase("nextmonth"))
	{
		c.add(Calendar.MONTH, +1);	return sdf.format(c.getTime());   // one month later
	}
	else
		throw new Exception("Unknown Parameter passed, expected parameters are currentmonth, previousmonth, nextmonth ");
}

public void pickAndVerifyMonth(WebDriver driver, String str) throws Exception
{
	MonthPicker.click();
	prntResults("Clicked on Month Picker");
	String locator =".//*[@id='date-pickerSelectBoxItOptions']/li[*]/a[contains(text(),'"+str+"')]";
	driver.findElement(By.xpath(locator)).click();
	Thread.sleep(1000);
	if(MonthPicker.getText().equalsIgnoreCase(str))
		prntResults("Successfully verified that, "+str+" is displayed");
	else
		throw new Exception("Failed to verify that, "+str+" is displayed");
	Thread.sleep(2000);
}

public void createEvent(WebDriver driver,String month, String EventTitle, String StartDate, String EndtDate, String Description) throws Exception
{
	pickAndVerifyMonth(driver,month);
	moveToElement(driver, CalenderRandomDay);
	AddEvent.click();
	prntResults("Clicked on Add Event");
	Thread.sleep(3000);
	NewEventTitleTextBox.clear();
	NewEventTitleTextBox.sendKeys(EventTitle);
	prntResults("Entered Event Title as "+EventTitle);
	NewEventStartDateTextBox.clear();
	NewEventStartDateTextBox.sendKeys(StartDate);
	prntResults("Entered Start Date as "+StartDate);
	NewEventEndDateTextBox.clear();
	NewEventEndDateTextBox.sendKeys(EndtDate);
	prntResults("Entered End Date as "+EndtDate);
	NewEventDescriptionTextBox.click();
	NewEventDescriptionTextBox.clear();
	NewEventDescriptionTextBox.sendKeys(Description);
	prntResults("Entered Description as "+Description);
	Thread.sleep(2000);
	NewEventSubmitButton.click();
	prntResults("Clicked on Submit Button");
	Thread.sleep(5000);
	CreatedPersonalEvent.click();
	prntResults("Clicked on Created Personal Event");
	Thread.sleep(2000);
	if(!(CreatedPersonalEventTitle.getText().equalsIgnoreCase(EventTitle)))
	{
		prntResults("Failed : The Created Event is not displayed as Expected");
		throw new Exception("Failed : The Created Event is not displayed as Expected");
	}
	prntResults("The Event is created and verified successfully");
	Thread.sleep(4000);
}

public void modifyEvent(WebDriver driver, String month, String OldEventTitle, String NewEventTitle) throws Exception
{
	pickAndVerifyMonth(driver, month);
	CreatedPersonalEvent.click();
	Thread.sleep(2000);
	prntResults("Clicked on Created Personal Event");
	if(!(CreatedPersonalEventTitle.getText().equalsIgnoreCase(OldEventTitle)))
	{
		prntResults("Failed : The Created Event is not displayed as Expected");
		throw new Exception("Failed : The Created Event is not displayed as Expected");
	}
	EditCreatedPersonalEvent.click();
	Thread.sleep(1000);
	prntResults("Clicked on Edit Event button");
	NewEventTitleTextBox.clear();
	NewEventTitleTextBox.sendKeys(NewEventTitle);
	Thread.sleep(1000);	
	NewEventTitleTextBox.click();
	prntResults("Entered Event Title as "+NewEventTitle);
	Thread.sleep(2000);
	NewEventSubmitButton.click();
	prntResults("Clicked on Submit Button");
	Thread.sleep(6000);
	CreatedPersonalEvent.click();
	prntResults("Clicked on Created Personal Event");
	Thread.sleep(3000);
	if(!(CreatedPersonalEventTitle.getText().equalsIgnoreCase(NewEventTitle)))
	{
		prntResults("Failed : The Edited Event Title is not displayed as Expected");
		throw new Exception("Failed : The Edited Event Title is not displayed as Expected");
	}
	prntResults("The Event is modified and verified successfully");
	Thread.sleep(4000);
}

public void deleteEvent(WebDriver driver, String month, String EventTitle) throws Exception
{
	pickAndVerifyMonth(driver,month);
	if(CreatedPersonalEvent.isDisplayed())
	{
		Thread.sleep(2000);
		CreatedPersonalEvent.click();
		prntResults("Clicked on Created Personal Event");
		Thread.sleep(2000);
		if(CreatedPersonalEventTitle.getText().equalsIgnoreCase(EventTitle))
		{
			DeleteCreatedPersonalEvent.click();
			prntResults("Clicked on Delete button");
			Thread.sleep(2000);
		}
		else
		{
			prntResults("The Expected Event is not displayed");
		}
	}
	else
	{
		prntResults("Expected Event is not available to delete");
	}
	Thread.sleep(3000);
}

public void newsandevents_HeaderValidation(String MsgHeader) throws Exception {
	String PageHeader = NewEventHeader.getText();
	prntResults(""+PageHeader);
	Thread.sleep(3000);
	Assert.assertFalse(PageHeader.equalsIgnoreCase(MsgHeader),"Hello Human: Test FAILED ---- Header validation failed for News and Events Pages");	
	
}

public void valid_IntersectingGroup(WebDriver driver,String MsgHeader) throws Exception {
	int NewsHeader_Size = driver.findElements(By.xpath(".//*[@id='hp-messages']/h2")).size();
	if(NewsHeader_Size > 0) 
	{
		String MsgTxt = MsgItemHeader.getText();
		if(!(MsgTxt.equals(MsgHeader)))
		{
			for(int i=1;i<=20;i++) 
			{
				Msg_Nextbtn.click();
				prntResults("Clicked on Next button in home message");
				String header_txt1 = MsgItemHeader.getText();
				prntResults("header text: "+header_txt1);
				if(header_txt1.equals(MsgHeader)) 
				{
					break;
				}
				else 
				{
					if(i>20) 
					{
						throw new Exception("Failed -- verification failed for Intersecting Gropus");
					}
				}
			}
		}
		else 
		{
			prntResults("Successfully verified message Items for Intersecting Gropus");
		}
	}
}

public void Invalid_IntersectingGroup(WebDriver driver) throws Exception {
	int NewsHeader_Size = driver.findElements(By.xpath(".//*[@id='hp-messages']/h2")).size();
	if (NewsHeader_Size == 0) 
	{
		prntResults("PASSED because no News and Event message displayed for Non Intersecting Group");		
	} 
	else {
		System.err.println("FAILED because News and Event message displayed for Non Intersecting Group");
		throw new Exception("FAILED because News and Event message displayed for Non Intersecting Group");
	}
}

}
