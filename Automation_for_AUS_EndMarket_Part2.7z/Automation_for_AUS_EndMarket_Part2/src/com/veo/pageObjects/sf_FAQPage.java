package com.veo.pageObjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;

public class sf_FAQPage extends LocalTestBase {

/***************************************************************************
	The Top Menu Bar of HOME Page
***************************************************************************/	
@FindBy(css="div[id='page-content']>div[class='container']>div[class='row']>*>.content")
public WebElement FAQ_Page_Content;


public void verifyContent(String page_content) throws Exception{

	if(driver.getPageSource().contains(page_content))
	{
		prntResults("As expected the content is displayed as "+page_content);
	}
	else{
		System.err.println("Failed as the content is not displayed as "+page_content);
		prntResults("Failed as the content is not displayed as "+page_content);
		throw new Exception("Failed as the content is not displayed as "+page_content);
	}
}
}
