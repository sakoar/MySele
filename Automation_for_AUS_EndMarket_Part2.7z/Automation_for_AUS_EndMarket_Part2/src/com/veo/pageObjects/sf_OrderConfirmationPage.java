package com.veo.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;

public class sf_OrderConfirmationPage extends LocalTestBase {

@FindBy(css="div.row > h1")
public WebElement OrderDetailsPage;

@FindBy(css="h2.upper.large  > span")
public WebElement OrderStatus;

@FindBy(id="dd-order-code")
public WebElement OrderNumberGenerated;

public String reviewOrderConfirmPage() throws Exception{
	Assert.assertEquals(OrderDetailsPage.getText(),"ORDER DETAILS");
	Assert.assertEquals(OrderStatus.getText(), "ORDER SUBMITTED");
	String OrderNumber=OrderNumberGenerated.getText();
	prntResults("Order Number Generated: "+OrderNumber);
	Thread.sleep(5000);
	return OrderNumber;
}

}
