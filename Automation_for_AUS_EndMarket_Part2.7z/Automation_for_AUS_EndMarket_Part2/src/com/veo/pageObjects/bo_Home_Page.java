package com.veo.pageObjects;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.reporters.jq.TimesPanel;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;


public class bo_Home_Page extends LocalTestBase{
	
@FindBy(css="button[class*='refresh z-button']")
public WebElement bo_HomePage_RefreshBtn;

@FindBy(css="input[class*='z-datebox-inp'][tabindex='11']")
public WebElement bo_HomePage_StartDate;

@FindBy(css="input[class*='z-datebox-inp'][tabindex='12']")
public WebElement bo_HomePage_EndDate;

@FindBy(css="div[class='z-row-content']>span[class='z-checkbox']>input[type='checkbox']")
public WebElement bo_HomePage_EmergencyCheckBox;

@FindBy(css="div[class='z-row-content']>input[class='z-textbox']")
public WebElement bo_HomePage_ERP_TxtBox;

@FindBy(css="input[class='z-combobox-input'][tabindex='15']")
public WebElement bo_HomePage_OrderType;

@FindBy(css="tr[class='z-row z-grid-odd']>td[class='z-row-inner']>div[class='z-row-content']>span[class='z-combobox']>input[class='z-combobox-input'][tabindex='16']")
public WebElement bo_HomePage_OrderStatus;

@FindBy(css="input[class='z-combobox-input'][value='']")
public WebElement bo_HomePage_OrderCountDisplay;

@FindBy(css="button[class*='createOrderButton']")
public WebElement bo_HomePage_CreateOrderBtn;

@FindBy(css="input[class='z-textbox'][tabindex='1']")
public WebElement bo_HomePage_CreateOrder_ERP;

@FindBy(xpath="//button[contains(.,'Ok')]")
public WebElement bo_HomePage_CreateOrder_OkBtn;

@FindBy(css="div[class='z-window-highlighted-header z-window-highlighted-header-move']")
public WebElement bo_HomePage_InvalidDialog;

@FindBy(css="div[class='z-messagebox-window z-window z-window-highlighted z-window-shadow']>div[class='z-window-header z-window-header-move']")
public WebElement bo_HomePage_InvalidERPDialog;

@FindBy(css="textarea[class='z-textbox']")
public WebElement bo_HomePage_CommentTxtBox;

@FindBy(xpath="//tr[@valign='top']/td/button[contains(.,'Add')]")
public WebElement bo_HomePage_Comment_AddButton;

@FindBy(xpath="//div[@class='z-window-header z-window-header-move']/div[@class='z-window-icon z-window-close']")
public WebElement bo_HomePage_Comment_CloseBtn;

@FindBy(xpath=".//div[@class='z-listheader-content' and starts-with(.,'Date')]")
public WebElement bo_HomePage_Date;

@FindBy(xpath="//span[contains(.,'No permission to create Order')]")
public WebElement bo_Disableduser_CreateOrder;

@FindBy(xpath="//button[@class='z-messagebox-button z-button']")
public WebElement bo_Disableduser_CreateOrder_OkBtn;

@FindBy(css="input[class*='z-datebox-inp'][tabindex='11']")
public WebElement bo_HomePage_StartDate1;


public void implicit_Wait_ID(WebDriver driver,long time) throws Exception{

    for(int i=0;i<20;i++)
    {
        try
        {          	
         int number = driver.findElements(By.cssSelector("input[class*='z-datebox-inp'][tabindex='11']")).size();
         System.out.println(number); 
         
         if((number>0))
         {
        	prntResults("Validating the presence of emergency checkbox");  
        	break;
         }
         else
         {
            //Thread.sleep(time);
         }
         }        
        catch(Exception e)
        {
        	Thread.sleep(time);
        }
    }    
}


public void implicit_Wait_ID_Sree(WebElement element,long time) throws Exception{

	/*int z= 20;
	Time*/
    for(int i=0;i<40;i++)
    {    
    	try
        { 
         Dimension number = element.getSize();
         System.out.println(number); 

         int x = number.getHeight();
         int y = number.getWidth();
         
         if((x>0)||(y>0))
         {
        	prntResults("Validating the presence of"+element);  
        	break;
         }
         else
         {
            Thread.sleep(time);
         }
        
} 
   catch(Exception e)
{
	Thread.sleep(time);
}
}
}

        








public WebElement isElementLoaded(WebDriver driver, WebElement elementToBeLoaded,int Time) 
{
    WebDriverWait wait = new WebDriverWait(driver, Time);
    WebElement element = wait.until(ExpectedConditions.visibilityOf(elementToBeLoaded));
    return element;
}


public void BO_ReasonColumn(WebDriver driver,String ActualOrder_No,String RuleMessage) throws Exception
{
	int order_rowcount = driver.findElements(By.xpath("//div[@ytestid='veobackoffice-order-list']/div/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@ytestid='mainListBox']/div[@class='z-listbox-body']/table/tbody[2]/tr")).size();
	prntResults("No.Of.Orders found in first page is : "+order_rowcount);
	//System.out.println("order_rowcount"+order_rowcount);
	
	for(int i=1;i<=order_rowcount;i++)
	{
		String orderno_txt = driver.findElement(By.xpath("//div[@ytestid='veobackoffice-order-list']/div/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@ytestid='mainListBox']/div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[3]/div/span/button")).getText();
		prntResults("Order.No in "+i+" row is: "+orderno_txt);
		//System.out.println(("Order.No in "+i+" row is: "+orderno_txt));
		
		if(ActualOrder_No.equals(orderno_txt))
		{
			driver.findElement(By.xpath("//div[@ytestid='veobackoffice-order-list']/div/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@ytestid='mainListBox']/div[@class='z-listbox-body']/table/tbody[2]/tr["+i+"]/td[6]/div/img")).click();
			System.out.println("Clicked on Reason Column of the Matched Order Number");
			
				String rulereason=driver.findElement(By.xpath("html/body/div[3]/div/div/span/table/tbody/tr[4]/td[2]")).getText();
				Assert.assertEquals(rulereason, RuleMessage);
			break;
			}
		}
	}
@FindBy(xpath="//span[@class='z-html']/button")
public WebElement DateColumn_Button;

public void BO_SortingDateColumn(WebDriver driver) throws Exception
{
	String a = null;
	String b = null;
	try
	{
		int rowcount;
		List<WebElement> tablerow = null;
		Thread.sleep(5000);
		
		if((driver.findElement(By.xpath("//span[@class='z-html']/button")).isDisplayed()))
		{
			tablerow = driver.findElements(By.xpath("//span[@class='z-html']/button"));
			rowcount=tablerow.size();
			prntResults("Row Size: "+tablerow.size());
		}
		else
		{
			prntResults("Failed: Could not find the search results data in the Homepage");
			//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Failed: Could not find the search results data in the Homepage");
		}

		String str[] = new String[tablerow.size()];	
		String str1[] = new String[tablerow.size()];	
		
		driver.findElement(By.xpath("//div/div/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div/div[@class='z-listbox-header']/table/tbody/tr[@class='yw-listview-colhead z-listhead']/th/div[contains(.,'Date')]")).click();
		prntResults("Clicked on Date Column first time");
		Thread.sleep(3000);

		prntResults("First time Date values");
		
		int l=driver.findElements(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr")).size();
		if(!(l==0))
		{
			for (int i=0;i<rowcount;i++)
			{
			int j=i+1;
			str[i]= driver.findElement(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr["+j+"]/td[5]/div")).getText();
			a = driver.findElement(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr[1]/td[5]/div")).getText();
			prntResults(str[i]);
			}	
		}
		else
		{
			prntResults("Failed: Could not find the search results data in Date column");
			//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Failed: Could not find the search results data in Date column");
		}
//=================================== Clicking on Date Column Second time ===================================//	
		driver.findElement(By.xpath("//div/div/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div/div[@class='z-listbox-header']/table/tbody/tr[@class='yw-listview-colhead z-listhead']/th/div[contains(.,'Date')]")).click();
		prntResults("Clicked on Date Column first time");
		Thread.sleep(3000);
		prntResults("Second time Date values");
		
		int m=driver.findElements(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr")).size();
		if(!(m==0))
		{
			for (int j=0;j<rowcount;j++) 
			{
			int k=j+1;
			str1[j]= driver.findElement(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr["+k+"]/td[5]/div")).getText();
			b = driver.findElement(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr[1]/td[5]/div")).getText();
				
			prntResults(str1[j]); //Printing Date Values in console
		    }							
		}
		
		else
		{
			System.err.println("Failed: Could not find the search results data in Date column");
		//	capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Failed: Could not find the search results data in Date column");
		}
		String[] stringParts1 = a.split(" ");
		System.out.println("a value 1st part: "+stringParts1[0]);
		System.out.println("a value 2nd part: "+stringParts1[1]);
		
		String[] stringParts2 = b.split(" ");
		System.out.println("b value 1st part: "+stringParts2[0]);
		System.out.println("b value 2nd part: "+stringParts2[1]);
		
		
		if(!((stringParts1[0] == stringParts2[0])&&(stringParts1[1] == stringParts2[1])))
			{
			prntResults("Validation Success: Compared date values are not same and columns filter is reversed.");
			}
		else
		{
			System.err.println("Validation FAILED: Compared date values are same and columns filter is not reversed.");
		//	capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("Validation FAILED: Compared date values are same and columns filter is not reversed.");
		}					

	}
catch(Exception e) 
{
ErrorUtil.addVerificationFailure(e); 
System.err.println("FAILED --- Problem in sorting the columns in Backoffice"); 
throw e;
}
}


public void BO_AddingComments(WebDriver driver, String Comments) throws Exception
{
	try
	{
		WebElement CommentsCol = driver.findElement(By.xpath("//table/tbody[1]/tr[1]/td[1]/div/button[@class='orderButton z-button']"));
		CommentsCol.click();
		prntResults("Clicked on Comments Column");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		bo_HomePage_CommentTxtBox.sendKeys(Comments);
		prntResults("Entered Comments in Comments Box");
		bo_HomePage_Comment_AddButton.click();
		prntResults("Clicked on Add Button");
		bo_HomePage_Comment_CloseBtn.click();
		prntResults("Clicked on Close Button");
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("FAILED --- Problem in Adding Comments in Backoffice"); 
		throw new Exception("FAILED --- Problem in Adding Comments in Backoffice",e);
	}
}

/*public WebElement isElementLoaded(WebDriver driver, WebElement elementToBeLoaded,int Time) 
{
    WebDriverWait wait = new WebDriverWait(driver, Time);
    WebElement element = wait.until(ExpectedConditions.visibilityOf(elementToBeLoaded));    
    return element;
}
*/

public void BO_Click_OrderBtn(WebDriver driver,int j) throws Exception
{
	try
	{
		String Ordernumber = BackofficeFindElements(driver,"//span[@class='z-html']/button",j);
		prntResults("The Selected Order No is: "+Ordernumber);
		driver.findElement(By.xpath("//button[contains(.,'"+Ordernumber+"')]")).click();
		prntResults("Clicked on the Order Number: "+Ordernumber);
		Thread.sleep(2000);
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("Not able to click on "+j+" row of order");
		throw new Exception("Not able to click on "+j+" row of order",e);
	}
}
@FindBy(xpath="//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr[1]/td[2]/div/span/a")
public WebElement BO_ERPnumber;
public void BO_Click_ERPLink(WebDriver driver) throws Exception
{
	try
	{
		Thread.sleep(2000);
		String ERPNumber = driver.findElement(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr[1]/td[2]/div/span/a")).getText();
		driver.findElement(By.xpath("//div[@class='yw-uk_co_portaltech_bat_veo_backoffice_widgets_extlistview widget_body z-div']/div[@class='z-vlayout']/div[@class='z-vlayout-inner']/div[@class='yw-listview-listcontainer z-div']/div[@class='z-listbox']/div[@class='z-listbox-body']/table/tbody[1]/tr[1]/td[2]/div/span/a")).click();
		Thread.sleep(2000);
		prntResults("Clicked on ERP Number :"+ERPNumber);
		
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		System.err.println("FAILED : Not able to click ERP Link in Backoffice");
		throw new Exception("FAILED : Not able to click ERP Link in Backoffice", e);
	}
}

public void BO_CreateOrder(WebDriver driver,String ERPNumber) throws Exception
{
	try
	{
		bo_HomePage_CreateOrderBtn.click();
		prntResults("Clicked on Create Order Button");
		bo_HomePage_CreateOrder_ERP.clear();
		bo_HomePage_CreateOrder_ERP.sendKeys(ERPNumber);
		prntResults("Entered the ERP Number");
		bo_HomePage_CreateOrder_OkBtn.click();
		prntResults("Clicked on Ok Button");
		List<WebElement> DialogCount = driver.findElements(By.cssSelector("div[class='z-messagebox-window z-window z-window-highlighted z-window-shadow']>div[class='z-window-header z-window-header-move']"));
		if((DialogCount.size())>=1 && (bo_HomePage_InvalidERPDialog.isDisplayed()))
		{
			System.err.println("ERROR --- Invalid ERP; Please amend ERP");
			//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			throw new Exception("ERROR --- Invalid ERP; Please amend ERP");
		}
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("Failed in Create order Backoffice");
		throw new Exception("Failed in Create order Backoffice", e);
	}
}

public void BO_OrderStatusCheck(WebDriver driver,String xpath,String Expected_OrderNo) throws Exception
{
	try
	{
		List<WebElement> elements = driver.findElements(By.xpath(xpath));
		prntResults("Element size is :"+elements.size());
		if(!(elements.size() == 0))
		{
			for(int j=0;j<=elements.size();j++)
			{
				prntResults(elements.get(j).getText());
				String linkText = elements.get(j).getText();
				Thread.sleep(1000);
				if(linkText.equals(Expected_OrderNo))
				{
					prntResults("Order Amended Successfully!!!");
					break;
				}
				else
				{
					if(j>elements.size())
					{
						System.err.println("ERROR --- Order is not Amended");
				//		capturescreenshot(this.getClass().getSimpleName()+"_"+count);
						throw new Exception("ERROR --- Order is not Amended");
					}
				}
			}
		}

	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
	//	capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		System.err.println("FAILED : Order Status is not changed as expected");
		throw new Exception("FAILED : Order Status is not changed as expected",e);
	}
}

public void verify_Order_Availabe(WebDriver driver,String order_no,String erp_no) throws Exception
{
	bo_HomePage_StartDate.clear();
	bo_HomePage_ERP_TxtBox.clear();
	bo_HomePage_ERP_TxtBox.sendKeys(erp_no);
	bo_HomePage_RefreshBtn.click();
	bo_HomePage_Date.click();
	Thread.sleep(3000);
	bo_HomePage_Date.click();
	Thread.sleep(3000);
	String locator = "//span[@class='z-html']/button[contains(.,'"+order_no+"')]";
	if(driver.findElement(By.xpath(locator)).isDisplayed())
	{
		prntResults("Successfully Verified Order "+order_no+" in Backoffice");
	}
	else
	{
		throw new Exception("Failed to verify Order "+order_no);
	}
}

public void verify_Order_in_BO(WebDriver driver, String order_no, String erp_no, String Order_status, String error_reason) throws Exception
{
	verify_Order_Availabe(driver,order_no,erp_no);
	
	String locator1 = "//span[@class='z-html']/button[contains(.,'"+order_no+"')]/../../../../td/div[contains(.,'"+Order_status+"')]";
	if(driver.findElement(By.xpath(locator1)).isDisplayed())
	{
		prntResults("As Expected the Order "+order_no+" has status as "+Order_status);
	}
	else{
		prntResults("Failed as the Order "+order_no+" doesnot have status as "+Order_status);
		throw new Exception("Failed as the Order "+order_no+" doesnot have status as "+Order_status);
	}
	
	String locator2 = "//span[@class='z-html']/button[contains(.,'"+order_no+"')]/../../../../td/div/img[@class='z-image']";
	Thread.sleep(20000);
	driver.findElement(By.xpath(locator2)).click();
	Thread.sleep(10000);
	String locator3 = "//td[contains(.,'"+error_reason+"')]";
	boolean val = driver.findElement(By.xpath(locator3)).isDisplayed();
	prntResults("the val is "+val); 
	if(driver.findElement(By.xpath(locator3)).isDisplayed())
	{
		prntResults("As Expected the Error message is "+error_reason);
	}
	else{
		prntResults("Failed as the Error message is not displayed as "+error_reason);
		throw new Exception("Failed as the Error message is not displayed as "+error_reason);
	}
}


public void BO_CreateOrder_DisabledUsr(WebDriver driver,String DisabledUsrname) throws Exception
{
	try
	{
		bo_HomePage_CreateOrderBtn.click();
		prntResults("Clicked on Create Order Button");
		
		Thread.sleep(5000);
		
		bo_HomePage_CreateOrder_ERP.sendKeys(DisabledUsrname);
		prntResults("Entered the ERP Number");
		
		Thread.sleep(10000);
		
		bo_HomePage_CreateOrder_OkBtn.click();
		prntResults("Clicked on Ok Button");
		Thread.sleep(5000);
		int DialogCount = driver.findElements(By.xpath("//span[contains(.,'No permission to create Order')]")).size();
		int DiaglogTxtCount =driver.findElements(By.xpath("//span[contains(.,'No permission to create Order')]")).size();
		
		System.out.println(DialogCount);
		
		System.out.println(DiaglogTxtCount);
		Thread.sleep(5000);
		if((DialogCount >= 1)&&(DiaglogTxtCount>=1))
		{
			prntResults("Success -- Validated the access for inactive account in Backoffice");
			Thread.sleep(3000);
			bo_Disableduser_CreateOrder_OkBtn.click();
			prntResults("Clicked on OK Buuton in Error Dialog Box");
		}
		else
		{
			CaptureScreenshot_On_Failure();
			System.err.println("\n===================="+"\nFAILED -- Validation failed for inactive user account in Backoffice, Check manually"+"\n====================");
			throw new Exception("\n===================="+"\nFAILED -- Validation failed for inactive user account in Backoffice, Check manually"+"\n====================");
		}
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("FAILED --- Problem in Disbled User Create Order Functionality in Backoffice"); 
		System.err.println("FAILED --- Problem in Disbled User Create Order Functionality in Backoffice");
		throw e;
	}
}



}
