package com.veo.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;


public class PCM_Logout_Page extends LocalTestBase{

	@FindBy(xpath="html/body/div[1]/div/div[2]/div/div/div/div[2]/div[1]/div[1]/div[2]/div/div[2]/div[1]/div/table/tbody/tr/td[5]/div/div/span")
	public WebElement PCM_Home_Menu;
	
	@FindBy(xpath="//div[3]/ul/li[4]/a[contains(.,'Logout')]")
	public WebElement PCM_Home_Logout;

	public void PMS_logout() throws Exception
	{
		try
		{
			PCM_Home_Menu.click();
			PCM_Home_Logout.click();
			Thread.sleep(5000);
			prntResults("Logout Successful");
		}
		catch (Exception exception) 
		{
			System.err.println("Failed to Logout of Product Cockpit");
			prntResults("Failed to Logout of Product Cockpit");
			capturescreenshot(this.getClass().getSimpleName() +"_Logout_Failed");
			throw new Exception("Failed to Logout of Product Cockpit", exception);
		} 
	}
}
