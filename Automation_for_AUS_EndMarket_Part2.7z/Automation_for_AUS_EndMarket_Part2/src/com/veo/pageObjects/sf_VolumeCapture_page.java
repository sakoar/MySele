package com.veo.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;

public class sf_VolumeCapture_page extends LocalTestBase{

	/******************************************************************
	 * Volume Capture
	 ******************************************************************/
		
	@FindBy(css = "#cancel")
	public WebElement VolumeCapture_Cancel_Button;

	@FindBy(css="#continue")
	public WebElement VolumeCapture_Submit_Button;

	@FindBy(css="#save-exit")
	public WebElement VolumeCapture_SaveExit_Button;	
	
	@FindBy(css="#quantity_0")
	public WebElement VolumeCapture_Quantity_Input;	
	
	@FindBy(css=".btn.btn-default.btn-sm.fl")
	public WebElement VolumeCapture_Cancel_No_Button;	
	
	@FindBy(xpath="//a[contains(.,'Yes')]")
	public WebElement VolumeCapture_Cancel_Yes_Button;
	
	@FindBy(css="#okclick>span")
	public WebElement VolumeCapture_Submit_Ok_Button;
	
	

	/******************************************************************
	 ***************** Methods Used In VolumeCapture ******************
	 ******************************************************************/
	public void Cancel_VolumeCapture(String Volume) throws Exception
	{
		Thread.sleep(3000);
		VolumeCapture_Quantity_Input.clear();
		VolumeCapture_Quantity_Input.sendKeys(Volume);
		Thread.sleep(2000);
		VolumeCapture_Cancel_Button.click();
		Thread.sleep(2000);
		VolumeCapture_Cancel_No_Button.click();
		Thread.sleep(2000);
		VolumeCapture_Cancel_Button.click();
		Thread.sleep(2000);
		VolumeCapture_Cancel_Yes_Button.click();
		Thread.sleep(3000);
		prntResults("Successfully cancelled Volume Capture");
		
	}	
	
	public void Submit_VolumeCapture(String Volume) throws Exception
	{
		Thread.sleep(2000);
		VolumeCapture_Quantity_Input.clear();
		VolumeCapture_Quantity_Input.sendKeys(Volume);
		Thread.sleep(2000);
		VolumeCapture_Submit_Button.click();
		Thread.sleep(2000);
		VolumeCapture_Submit_Ok_Button.click();	
		Thread.sleep(3000);
	}

}
