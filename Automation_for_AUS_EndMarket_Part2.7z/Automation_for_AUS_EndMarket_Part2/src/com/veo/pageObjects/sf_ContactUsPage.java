package com.veo.pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class sf_ContactUsPage extends LocalTestBase{

@FindBy(css=".row>h1")
public WebElement ContactUsPage_Header;

@FindBy(css="#contact-name")
public WebElement ContactUsPage_Name;

@FindBy(css="#contact-email")
public WebElement ContactUsPage_Email;

@FindBy(css="#contact-reasonSelectBoxIt")
public WebElement ContactUsPage_ReasonForContact;

@FindBy(css="#contact-message")
public WebElement ContactUsPage_Message;

@FindBy(css="#contact-copy")
public WebElement ContactUsPage_CopyEmail_Checkbox;

@FindBy(css="button[title='Send']")
public WebElement ContactUsPage_SendBtn;

@FindBy(css="#div-global-message-information>p")
public WebElement ContactUsPage_EmailSentMsg;


public void Send_ContactUs_Email(WebDriver driver, String Name,String Email,String Reason,String Message) throws Exception
{	
	try
	{
		//Help & Contact Link
		Assert.assertEquals(ContactUsPage_Header.getText(),"CONTACT US");
		prntResults("Verified Contact Us Page");
		ContactUsPage_Name.clear();
		ContactUsPage_Name.sendKeys(Name);
		prntResults("Entered the Name");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ContactUsPage_Email.clear();
		ContactUsPage_Email.sendKeys(Email);
		prntResults("Entered the Email Id");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ContactUsPage_ReasonForContact.sendKeys(Reason);
		prntResults("Selected the Reason for Contact as "+Reason);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ContactUsPage_Message.clear();
		ContactUsPage_Message.sendKeys(Message);
		prntResults("Entered the Message");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ContactUsPage_CopyEmail_Checkbox.click();
		prntResults("Clicked on Copy Email Checkbox");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ContactUsPage_SendBtn.click();
		prntResults("Clicked on Send Button");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Assert.assertEquals(ContactUsPage_EmailSentMsg.getText(), "Email sent successfully");
		prntResults("Email Sent Successfully");

	}
	catch(Exception e)
	{
		capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		System.err.println("Failed to Send Email in Contact Us Page");
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("Failed to Send Email in Contact Us Page", e);
	}
}

	
}
