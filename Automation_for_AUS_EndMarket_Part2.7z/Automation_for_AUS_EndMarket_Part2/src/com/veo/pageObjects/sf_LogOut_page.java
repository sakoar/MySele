package com.veo.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;

public class sf_LogOut_page extends LocalTestBase{

@FindBy(id="my-account-menu")
public WebElement Home_Page_ManIcon;
	
@FindBy(xpath="html/body/header/div/div/div[2]/ul/div/div[2]/nav/ul/li[3]/a")
public WebElement LogOut_Button; 

public void logout() throws Exception{
	Thread.sleep(2000);
	Home_Page_ManIcon.click();
	Thread.sleep(1000);
	LogOut_Button.click();
	Thread.sleep(3000);
	prntResults("Logout successful");
}

public void logout1(){

	Home_Page_ManIcon.click();
	LogOut_Button.click();
}
public void logout(WebDriver driver) throws Exception{
	Home_Page_ManIcon.click();
	Thread.sleep(1000);
	LogOut_Button.click();
	prntResults("Logout successful");
}

}
