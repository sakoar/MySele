package com.veo.pageObjects;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class sf_CreateOrder_n_Product_Selection extends LocalTestBase{

	
	
	@FindBy(css="#emergency-check-submit")
	public WebElement Emergency_Check;
	
@FindBy(xpath=".//*[@id='modal-show-last-edited-by']/div/div/div[1]/h2")
public WebElement POP_Up_used_by_otherUser; 

@FindBy(xpath=".//*[@id='modal-show-last-edited-by']/div/div/div[3]/button")
public WebElement POP_Up_used_by_otherUser_Continue; 

@FindBy(xpath=".//html/body/header/div/div/div[1]/a")
public WebElement Order_button; 

@FindBy(xpath="//span[contains(.,'CT')]/following-sibling::input[@id='footerPK']")
public WebElement CT_value_CartPage;

@FindBy(id="cancel")
public WebElement Cancel_button;

@FindBy(xpath="//*[@id='base-product-id-0']")
public WebElement ClickOnOrderFirstRowSimplyToOffsetNotification;

@FindBy(xpath="//*[@id='modal-cancel-order-block']/div/div/div[1]/h2")
public WebElement CancelOrdrPopUP;

@FindBy(xpath="//*[@id='modal-cancel-order-block']/div/div/div[3]/div/button")
public WebElement NoButton;

@FindBy(xpath="//*[@id='modal-cancel-order-block']/div/div/div[3]/div/a")
public WebElement YesButton;

@FindBy(css="#error-modal>div>div>.modal-header>h2")
public WebElement ClerkPopUpHeader;

@FindBy(css="button[type='submit']")
public WebElement ClerkPopUPOKButton;

@FindBy(xpath="//*[@id='modal-off-route-block']/div/div/div/h2")
public WebElement PopUp_Header;  //text()="Off Schedule Order"

@FindBy(xpath="//*[@id='emergency-check']/div[1]/div/div[2]/p[2]/strong")
public WebElement PopUp_question;   //text()="Is this an Off Schedule Order?"

@FindBy(id="off-route")
public WebElement PopUp_Yes;

@FindBy(id="emergency")
public WebElement PopUp_No;
	
@FindBy(id="emergency-check-submit")
public WebElement PopUp_ContinueButton;

@FindBy(xpath="//*[@id='modal-off-route-block']/div/div/div/h2")
public WebElement PopUp_HeaderCAN;  //text()="Off Schedule Order"

@FindBy(xpath="//*[@id='emergency-check']/div[1]/div/div[2]/p[1]")
public WebElement PopUp_BodyCAN;   //text()="Is this an Off Schedule Order?"

@FindBy(id="emergency-check-submit")
public WebElement PopUp_ContinueButtonCAN;

@FindBy(id="cart-filter")
public WebElement searchProductBox;

@FindBy(xpath="//*[starts-with(@id,'base-product-id-')]")
public WebElement searchResult;

@FindBy(xpath="//*[@id='on-hand-inv-carton-0']") 
public WebElement Invntry_OnHandCT;

@FindBy(xpath="//*[@id='on-hand-inv-pack-0']")
public WebElement Invntry_OnHandPK;

@FindBy(xpath="//*[@id='on-hand-inv-carton-1']") 
public WebElement Invntry_OnHandCT1;

@FindBy(xpath="//*[@id='on-hand-inv-pack-1']")
public WebElement Invntry_OnHandPK1;

@FindBy(xpath="//*[@id='quantity-1']")
public WebElement OrderQntity1;

@FindBy(xpath="//*[@id='quantity-0']")
public WebElement OrderQntity;

@FindBy(xpath="//*[contains(@id,'cart-entry-')]/td[5]/span")
public WebElement itemPrice;

@FindBy(xpath="//*[starts-with(@id,'total-cost-')]")
public WebElement totalCost;

@FindBy(id="target-inv-0")
public WebElement targetInvntryValue;

@FindBy(xpath="//*[@id='on-hand-inv-carton-0']")
public WebElement onHandInvntryCarton;

@FindBy(xpath="//*[@id='on-hand-inv-pack-0']")
public WebElement onHandInvntryPack;

@FindBy(xpath="//*[@id='soq-0']")
public WebElement SOQ_Qty;

@FindBy(css="#cart-preferences>i")
public WebElement Settings_Ikon;


public WebElement isElementLoaded(WebDriver driver, WebElement elementToBeLoaded,int Time) 
{
    WebDriverWait wait = new WebDriverWait(driver, Time);
    WebElement element = wait.until(ExpectedConditions.visibilityOf(elementToBeLoaded));    
    return element;
}


public void addingColumns(WebDriver driver) throws Exception{
	implicit_Wait_ID_Sree(Settings_Ikon, 5000);		
	
	Settings_Ikon.click();
	prntResults("Clicked on Settings Ikon in cartpage");
	implicit_Wait_ID_Sree(settings_Reset, 5000);		

	settings_Reset.click();
	Thread.sleep(1000);
	prntResults("Clicked on Reset Button");
	
	List<WebElement> chkBoxes=driver.findElements(By.xpath("//*[@id='preferencesTag']/div[2]/div[2]/form/div[@class='col-xs-8']/div[@class='form-group']"));
	//System.out.println("List of chk box are: "+chkBoxes.size());
	for(WebElement chkBox :chkBoxes)
	{
		implicit_Wait_ID_Sree(chkBox, 5000);		
		chkBox.click();
		System.out.println(chkBox.getText());
	}
	implicit_Wait_ID_Sree(settings_Save, 5000);		
	
	settings_Save.click();
	prntResults("Clicked on  settings_Save");

	Thread.sleep(4000);
	//driver.findElement(By.xpath("//*[@id='main-search']")).click();
	prntResults("*****************");
}

//



@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[5]/div[2]/div/label/input")
public WebElement settings_prev_Inventory;

@FindBy(css="#cart-table>thead>tr[class='tablesorter-headerRow']>th[id='col-prev-inv']>div")
public WebElement col_prev_Inventory;

@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[5]/div[3]/div/label/input")
public WebElement settings_prev_Order;

@FindBy(css="#cart-table>thead>tr[class='tablesorter-headerRow']>th[id='col-prev-order']>div")
public WebElement col_prev_Order;

@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[5]/div[1]/div/label/input")
public WebElement settings_est_UnitPrice;

@FindBy(css="#cart-table>thead>tr[class='tablesorter-headerRow']>th[id='col-est-unit-price']>div")
public WebElement col_est_UnitPrice;

@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[5]/div[6]/div/label/input")
public WebElement settings_est_Cost;

@FindBy(css="#cart-table>thead>tr[class='tablesorter-headerRow']>th[id='col-est-cost']>div")
public WebElement col_est_Cost;

@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[5]/div[4]/div/label/span/span")
public WebElement Freshness;

@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[5]/div[5]/div/label/span")
public WebElement lowInvntry;

@FindBy(xpath="(//button[@type='submit'])[3]")
public WebElement settings_Save;

@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[7]/button[1]")
public WebElement settings_Reset;

@FindBy(css="table[id='cart-table']>tbody>tr[id='cart-entry-0']>td[class='first col-products product-detail cart-td']>div[class='product-item thumb trigger-product-details col-xs-3 p0']")
public WebElement Product_Img;

@FindBy(xpath=".//*[@id='preferencesTag']/div[2]/div[2]/form/div[3]/div/div/label/input")
public WebElement settings_Disable_PrdtImg;

@FindBy(xpath=".//*[@id='modal-show-last-edited-by']/div/div/div[3]/button")
public WebElement Cart_LastEditedBy_Popup_CancelButton;

@FindBy(xpath="//*[@id='main-search']")
public WebElement mainSearch;

@FindBy(xpath=".//*[@id='modal-soft-block']/div/div/div[@class='modal-body pb0']/div[@class='text-icon']/div[@class='text']/p[2]")
public WebElement ExciseMonitor_ErrorMessage;

@FindBy(css="#button-soft-block-amend-order")
public WebElement exciseMonitor_error_amendOrder;

@FindBy(css="#cart-day-forecast")
public WebElement Days_Of_Forecast;

@FindBy(id="forecast-change-recompute")
public WebElement Recompute_Yes;

@FindBy(id="forecast-change-not-recompute")
public WebElement Recompute_No;

@FindBy(css="#forecast-change-submit-button")
public WebElement Forecastchange_ConfirmButton;

@FindBy(css=".selectboxit-option-anchor")
public WebElement Average_Sales_Dropdown;



@FindBy(xpath="//*[@id='preferencesTag']/div[2]/div[2]/form/div[1]/div/a")
public WebElement Edit;

@FindBy(xpath="//*[@id='modal-edit-row-sequence-alert']/div/div/div[1]/h2")
public WebElement AreUSure;        //dialog box

@FindBy(linkText="Ok")
public WebElement OKbutton; //OK Button

@FindBy(xpath="(//button[@type='button'])[26]")
public WebElement Cancelbutton; //Cancel Button

//Sequence Page
@FindBy(xpath="//div[@id='page-content']/div/div/div/div[2]/div")
public WebElement SqnceOrderPageHeader; 

//Item in row no 1
@FindBy(xpath="//*[@id='sortable']/tr[1]/td[3]")
public WebElement SortableItem1;

@FindBy(xpath="//*[@id='sortable']/tr[1]/td[3]/div/span[1]")
public WebElement SortableItem1Text; 

//Item in row no 2
@FindBy(xpath="//*[@id='sortable']/tr[2]/td[3]")
public WebElement SortableItem2;

@FindBy(xpath="//*[@id='sortable']/tr[2]/td[3]/div/span[1]")
public WebElement SortableItem2Text;

//Item in row no 3
@FindBy(xpath="//*[@id='sortable']/tr[3]/td[3]")
public WebElement SortableItem3; 

@FindBy(xpath="//*[@id='sortable']/tr[3]/td[3]/div/span[1]")
public WebElement SortableItem3Text;

@FindBy(xpath="//*[@id='sortable']/tr[3]/td[4]/div/div[1]/i")
public WebElement TheUPArrowKey4Item3; 

//Item in row no 4
@FindBy(xpath="//*[@id='sortable']/tr[4]/td[3]")
public WebElement SortableItem4; 

@FindBy(xpath="//*[@id='sortable']/tr[4]/td[3]/div/span[1]")
public WebElement SortableItem4Text; 

@FindBy(xpath="//*[@id='sortable']/tr[4]/td[4]/div/div[1]/i")
public WebElement TheUPArrowKey4Item4; 

//Save changes
@FindBy(xpath="//*[@id='button-sequence-change-top']")
public WebElement SaveChanges; 

@FindBy(xpath="//*[@id='modal-show-last-edited-by']/div/div/div[1]/h2")
public WebElement popHeader;

@FindBy(xpath="//*[@id='modal-show-last-edited-by']/div/div/div[2]")
public WebElement popMesage;

@FindBy(linkText="Exit")
public WebElement Exit;

@FindBy(xpath="(//button[@type='button'])[24]")
public WebElement Continue;

public void CancelOrder(WebDriver driver) throws Exception{
	
	implicit_Wait_ID_Sree(Order_button, 5000);			
	Order_button.click();
	prntResults("Clicked on Order button");
	
	implicit_Wait_ID_Sree(Cancel_button, 5000);			
	Cancel_button.click();
	prntResults("Clicked on Cancel Order button");
	
	implicit_Wait_ID_Sree(CancelOrdrPopUP, 5000);
	Assert.assertEquals(CancelOrdrPopUP.getText(),"Cancel order");
	
	implicit_Wait_ID_Sree(YesButton, 5000);
	YesButton.click();
	prntResults("Clicked on Yes button");
	
	Thread.sleep(10000);
	if(driver.getTitle().equalsIgnoreCase("Error 500"))
		throw new Exception('\n'+"Hello Human: Page responded with 500 error. This Could be a defect."+'\n'+"Please check the same.");
	else
		implicit_Wait_ID_Sree(Order_button, 5000);			

		Assert.assertEquals(Order_button.getText(),"Create order");
	Thread.sleep(5000);
}
public void CancelOrder_AddingColums(WebDriver driver) throws Exception{
	
	/*implicit_Wait_ID_Sree(Order_button, 5000);			
	Order_button.click();
	prntResults("Clicked on Order button");*/
	
	implicit_Wait_ID_Sree(Cancel_button, 5000);			
	Cancel_button.click();
	prntResults("Clicked on Cancel Order button");
	
	implicit_Wait_ID_Sree(CancelOrdrPopUP, 5000);
	Assert.assertEquals(CancelOrdrPopUP.getText(),"Cancel order");
	
	implicit_Wait_ID_Sree(YesButton, 5000);
	YesButton.click();
	prntResults("Clicked on Yes button");
	
	Thread.sleep(20000);
	
	if(driver.getTitle().equalsIgnoreCase("Error 500"))
		throw new Exception('\n'+"Hello Human: Page responded with 500 error. This Could be a defect."+'\n'+"Please check the same.");
	else
		//implicit_Wait_ID_Sree(Order_button, 5000);
		Assert.assertEquals(Order_button.getText(),"Create order");
	    Thread.sleep(5000);
}

public void PopUp_CAN() throws Exception{
	implicit_Wait_ID_Sree(PopUp_ContinueButton, 5000);	
	if(PopUp_ContinueButton.isDisplayed())
	{
		    implicit_Wait_ID_Sree(PopUp_Header, 5000);			
			Assert.assertEquals(PopUp_Header.getText(), "Off Route Order (Thank-you for your order!)");
			PopUp_ContinueButton.click();
	}
	else
		prntResults("No Pop_up will appear for this User-This is working as intended");
}

public void CreateOrderRetailer(WebDriver driver,String CountryName) throws Exception
{
	try
	{
		if(Order_button.getText().equalsIgnoreCase("Order in progress")){
				
			
			CancelOrder(driver); 
		}
		   implicit_Wait_ID_Sree(Order_button, 5000);			
			Order_button.click();
		Thread.sleep(3000);
		try 
		{
			if(CountryName.equalsIgnoreCase("CAN")) {
				PopUp_CAN();
			}
			else if(CountryName.equalsIgnoreCase("AUS")) {
				PopUp_AU();
			}
			else {
				PopUp_NZ();
			}
		}
		catch(Exception exception)
		{
			System.err.println("Hello Human:Failed to verify the Pop-Up, Possibly due to test data set up.");
			ErrorUtil.addVerificationFailure(exception);
			throw new Exception("Hello Human:Failed to verify the Pop-Up, please check the data set up.", exception);
		}
			Thread.sleep(2000);
			Assert.assertEquals(Order_button.getText(),"Order in progress");
			Thread.sleep(4000);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}
}
public void implicit_Wait_ID(WebDriver driver,long time) throws Exception{

    for(int i=0;i<15;i++)
    {
        try
        {   
         int number = driver.findElements(By.xpath(".//html/body/header/div/div/div[1]/a")).size();
         System.out.println(number); 
         
         if((number>0))
          {
        	prntResults("Validating presence of Order button");  
        	break;
          }
         else
          {
        	 prntResults("Taking more time to load the element");  
             
            Thread.sleep(time);
          }
          }        
        catch(Exception e)
        {
        	Thread.sleep(time);
        }
    }    
}

public void implicit_Wait_ID2(WebDriver driver,long time) throws Exception{

    for(int j=0;j<20;j++)
    {
        try
        {   
         int number = driver.findElements(By.xpath("//*[@id='quantity-1']")).size();
         System.out.println(number); 
         
         if((number>0))
          {
        	prntResults("Validating presence of quantity box");  
        	break;
          }
         else
          {
            Thread.sleep(time);
          }
          }        
        catch(Exception e)
        {
        	Thread.sleep(time);
        }
    }    
}

public void CreateOrderClerk() throws Exception
{
	if(Order_button.getText().equalsIgnoreCase("Order in progress")||Order_button.getText().equalsIgnoreCase("Create order")){
		Order_button.click();
		
		    implicit_Wait_ID_Sree(ClerkPopUpHeader, 5000);			
			Assert.assertEquals(ClerkPopUpHeader.getText(), "Not permitted");
			
		
		
		ClerkPopUPOKButton.click();
		Thread.sleep(2000);
	}
	Thread.sleep(3000);
}
public void implicit_Wait_ID_Sree(WebElement element,long time) throws Exception{

	/*int z= 20;
	Time*/
    for(int i=0;i<40;i++)
    {    
    	try
        { 
         Dimension number = element.getSize();
         System.out.println(number); 

         int x = number.getHeight();
         int y = number.getWidth();
         
         if((x>0)||(y>0))
         {
        	prntResults("Validating the presence of"+element);  
        	break;
         }
         else
         {
            Thread.sleep(time);
         }
        
} 
   catch(Exception e)
{
	Thread.sleep(time);
}
    }
}
public void PopUp(){
	if(PopUp_Header.getText().equalsIgnoreCase("Off Schedule Order"))
	{
			Assert.assertEquals(PopUp_Header.getText(), "Off Schedule Order");
			Assert.assertEquals(PopUp_question.getText(), "Is this an Off Schedule Order?");
			Assert.assertTrue(PopUp_Yes.isSelected());
			PopUp_ContinueButton.click();
	}
	else{System.out.println("No Pop_up will appear for this User-This is working as intended");}
}


public void PopUp_AU() throws Exception{
	if(PopUp_Header.getText().equalsIgnoreCase("Off Route Order"))
	{
		//Assert.assertEquals(PopUp_Header.getText(), "Off Schedule Order");
		PopUp_ContinueButton.click();
	}
	else
		prntResults("No Pop_up will appear for this User-This is working as intended");
}

public void PopUp_NZ() throws Exception{
	if(PopUp_Header.getText().equalsIgnoreCase("Off Route Order"))
	{
		PopUp_ContinueButton.click();
	}
	else
		prntResults("No Pop_up will appear for this User-This is working as intended");
}

public void PopUpCAN(){
	if(PopUp_HeaderCAN.getText().equalsIgnoreCase("Off Route Order (Thank-you for your order!)"))
	{
		Assert.assertEquals(PopUp_HeaderCAN.getText(), "Off Route Order (Thank-you for your order!)");
		PopUp_ContinueButton.click();
	}
	else
		prntResults("No Pop_up will appear for this User-This is working as intended");
}


public void cartSearchByID(WebDriver driver,String productID) throws Exception{

	try
	{
		Thread.sleep(3000);
		
		//Just offset the ALert notification
		//driver.findElement(By.xpath("//*[@id='page-content']/div/div[2]/div/div[3]/div[2]/div[2]/p")).click();
		
		System.out.println("Searching for product: "+productID);
		searchProductBox.sendKeys(productID);
		Thread.sleep(1000);
		
		
		searchProductBox.sendKeys(Keys.RETURN);
		System.out.println("Searched the product: "+productID);
		System.out.println("Going to verify the returned product id");
		Thread.sleep(3000);
		
		
		//WebElement searchResult = driver.findElement(By.xpath(".//*[@id='cart-table']/tbody/tr/td[@id='"+productID+"']/following-sibling::td[@class='col-product-id']/span[not(@class='product-id hidden')]"));
		//searchResult.click(); //this is to off set the notification in CAN 
		//System.out.println(searchResult.getText());
		//Assert.assertEquals(searchResult.getText(), productID);
		System.out.println("Product searched completed & verified for");
		
			
	}
	catch(Exception e)
		{
		//System.err.println("Failed to Enter the Product number");
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("Failed to Enter the Product number");
		}
	} 

public void cartSearchByID(String productID) throws Exception
{
	try
	{
		searchProductBox.sendKeys(productID);
		searchProductBox.sendKeys(Keys.RETURN);
		Thread.sleep(2000);
		Assert.assertEquals(searchResult.getText(), productID);
		searchResult.click();
		System.out.println("Product searched completed & verified for "+productID);
		Thread.sleep(3000);
	}
	catch(Exception e)
		{
			System.err.println("Failed to Enter the Product number");
			ErrorUtil.addVerificationFailure(e);
			throw new Exception("Failed to Enter the Product number",e);
		}
} 

public void targetInvntryValue(String InvntryQty) throws Exception{
	Thread.sleep(3000);
	Assert.assertEquals(targetInvntryValue.getAttribute("value"), InvntryQty);
}

public void InventryOnHand()
{
	String value = "36.1";
	double number = Math.round(Double.parseDouble(value));  //convert string to double & do round off
	Double mydouble = Double.valueOf(number);    //convert double to premitive value-->unboxing
	int CT_value=Integer.valueOf(mydouble.intValue());
	System.out.println("CT= "+CT_value);
	Random rand = new Random();
	int EnterCartonValue = rand.nextInt(CT_value+1);   
	int CalculatePktValue = (CT_value-EnterCartonValue)*10;
	int PKValue = rand.nextInt(CalculatePktValue+1); //random is done on Integer
	
	double packet = Math.round(PKValue/10); //Convert the Int to Double to get ROUND OFF
	Double packetDouble = Double.valueOf(packet);
	int packetInt = Integer.valueOf(packetDouble.intValue());
	
	String CT_Val=Integer.toString(EnterCartonValue); //convert Integer to String for
	String PK_Val = Integer.toString(packetInt);
	onHandInvntryCarton.sendKeys(CT_Val);
	onHandInvntryPack.sendKeys(PK_Val);
	Assert.assertEquals(SOQ_Qty.getText(),CT_Val+PK_Val);
 }

public void calculatePrice(String OrderQuantity){
	String price=itemPrice.getText();
	String priceWithNumber=price.replace("$", "");
	Double displayPrice = Double.parseDouble(priceWithNumber); 
	Double calculatedPrice = displayPrice*Double.parseDouble(OrderQuantity);
	String stringPrice = String.format("%.2f", calculatedPrice); //Double.toString(calculatedPrice)
	prntResults("StrinPrice :"+stringPrice);
	String ExpectedPrice = "$"+stringPrice;
	System.out.println("ExpectedPrie"+ExpectedPrice);
	System.out.println("ActualPrice"+totalCost.getText().replace(",", ""));
	Assert.assertEquals(totalCost.getText().replace(",", ""), ExpectedPrice);
}

public void enterQtyforSearchedProduct(String productName, String Qty) throws Exception{
	searchProductBox.sendKeys("DUNHILL 20/200 DISTINCT BLUE IPB");
	System.out.println("Product searched");
	Assert.assertEquals(driver.findElement(By.linkText("DUNHILL 20/200 DISTINCT BLUE IPB")).getText(),"DUNHILL 20/200 DISTINCT BLUE IPB");
	System.out.println("Assertion done");
	Invntry_OnHandCT.sendKeys("10");
	System.out.println("enter qty");
	Invntry_OnHandCT.sendKeys("20");
	OrderQntity.sendKeys(Qty);
	Thread.sleep(2000);
	OrderQntity.sendKeys(Keys.ENTER);
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	Thread.sleep(2000);
	calculatePrice(Qty);
}

public void enterQtyforRandomProduct(String Qty) throws Exception{
/*	Invntry_OnHandCT1.clear();
	Invntry_OnHandCT1.sendKeys("10");
	Invntry_OnHandPK1.clear();
	Invntry_OnHandPK1.sendKeys("20");*/
	
	implicit_Wait_ID_Sree(OrderQntity1, 5000);			
	
	OrderQntity1.clear();
	OrderQntity1.sendKeys(Qty);
	implicit_Wait_ID_Sree(OrderQntity1, 5000);		
	
	OrderQntity1.sendKeys(Keys.ENTER);
	Thread.sleep(2000);
}


public void Adding_Columns() throws Exception 
{
	
	Settings_Ikon.click();
	prntResults("Clicked on Settings Ikon in cartpage");
	settings_Reset.click();
	Thread.sleep(1000);
	prntResults("Clicked on Reset Button");
	settings_prev_Inventory.click();
	Thread.sleep(1000);
	prntResults("Selected Prev Inventory Column");
	settings_prev_Order.click();
	Thread.sleep(1000);
	prntResults("Selected Prev Order Column");
	settings_est_UnitPrice.click();
	Thread.sleep(1000);
	prntResults("Selected Est.Unit Price Column");
	settings_est_Cost.click(); //This line it is failing
	Thread.sleep(1000);
	prntResults("Selected Est.Cost Column");
	settings_Save.click();
	prntResults("Clicked on Save");
	Thread.sleep(3000);
	
	try
	{
		Assert.assertEquals(col_prev_Inventory.getText(), "Prev. Inventory");
	}catch (Exception e)
	{
		throw new Exception(col_prev_Inventory+ "Element not clicable",e);
	}
	try
	{
		Assert.assertEquals(col_prev_Order.getText(), "Prev. Order");	
	}catch (Exception e)
	{
		throw new Exception(col_prev_Order+ "Element not clicable",e);
	}	
}

public void Disable_ProductImage() throws Exception  //Ruth
{
	try
	{
		Settings_Ikon.click();
		prntResults("Clicked on Settings Ikon in cartpage");
		settings_Reset.click();
		prntResults("Clicked on Reset Button");
		settings_Disable_PrdtImg.click();
		prntResults("Selected Disable Product Image Option");
		settings_Save.click();
		prntResults("Clicked on Save");
		/*String Style_value1 = Product_Img.getAttribute("style");
		prntResults("Style:::"+Style_value1);*/
		if(Product_Img.getAttribute("style").equalsIgnoreCase("display: none;"))
		{
		System.out.println("Success: Images are not dispalyed for Products!!!");
		}
		else
		{
		//	capturescreenshot(this.getClass().getSimpleName()+"_"+count);
			prntResults("FAILED : Images are displayed for Products");
			throw new Exception("FAILED : Images are displayed for Products");
		}

	}catch(Throwable exception)
	{
		ErrorUtil.addVerificationFailure(exception); 
		prntResults("Failed: Not able to click on Ignore and continue");
		throw new Exception("Failed: Not able to click on Columns", exception);	
	}
}

public void SequenceOrderInCart(WebDriver driver) throws Exception{
	    implicit_Wait_ID_Sree(Settings_Ikon, 5000);			
	
		Settings_Ikon.click();
		implicit_Wait_ID_Sree(settings_Reset, 5000);			
		
		settings_Reset.click();
		implicit_Wait_ID_Sree(Edit, 5000);			
		
		Edit.click();
		Thread.sleep(2000);
		
		implicit_Wait_ID_Sree(AreUSure, 5000);		
		Assert.assertEquals(AreUSure.getText(), "Are you sure?");
		implicit_Wait_ID_Sree(OKbutton, 5000);		
			OKbutton.click();
			implicit_Wait_ID_Sree(SqnceOrderPageHeader, 8000);		
				
		prntResults(SqnceOrderPageHeader.getText());
	//	Assert.assertEquals(SqnceOrderPageHeader.getText(), "You are editing sequence order of the products");
	
		String itemInRow3=SortableItem3Text.getText();
		implicit_Wait_ID_Sree(SortableItem3, 8000);		
		
		SortableItem3.click();
		implicit_Wait_ID_Sree(TheUPArrowKey4Item3, 8000);		
		
		TheUPArrowKey4Item3.click();
		implicit_Wait_ID_Sree(SortableItem1Text, 8000);		
			Assert.assertEquals(SortableItem1Text.getText(), itemInRow3);
		System.out.println("row 3 moved to row 1");
	
		//When item 4 moves to 1, item 1 moves to 2
		String IteminRow1=SortableItem1Text.getText();
		String IteminRow4 = SortableItem4Text.getText();
		prntResults("IteminRow4 :"+IteminRow4);
		
		implicit_Wait_ID_Sree(SortableItem4, 8000);		
		SortableItem4.click();
		
		implicit_Wait_ID_Sree(TheUPArrowKey4Item4, 8000);		
		TheUPArrowKey4Item4.click();
	
		implicit_Wait_ID_Sree(SortableItem1Text, 8000);			
		Assert.assertEquals(SortableItem1Text.getText(), IteminRow4);
		
		System.out.println("row 4 moved to row 1");		
		implicit_Wait_ID_Sree(SortableItem2Text, 8000);		
		
		Assert.assertEquals(SortableItem2Text.getText(),IteminRow1 );
		System.out.println("row 1 moved to row 2");
	
		//Save Changes 
		implicit_Wait_ID_Sree(SaveChanges, 8000);		
		SaveChanges.click();
		
		Thread.sleep(8000);
		String IteminRow1SortPage = IteminRow4;
		System.out.println("Item in Row1 Sort Page: "+IteminRow1SortPage);
		Thread.sleep(8000);
		
		//sorting Validation On Cart Page	
		String ID = driver.findElement(By.xpath("//*[@id='base-product-id-1']")).getText();  //Sandeep Changed this from 1 to 0 in CAN test
		System.out.println("product id: "+ID);
		String CartPage1stRowItem = driver.findElement(By.xpath("//*[@id='"+ID+"']/div[2]/span/a")).getText();
		System.out.println("Cart item in row 1: "+CartPage1stRowItem);
		Thread.sleep(8000);
		Assert.assertEquals(CartPage1stRowItem,IteminRow1SortPage);
		Thread.sleep(3000);
		}

public void OrderSharedByMultiplierUsr() throws Exception{
	Order_button.click();
	System.out.println("clicked on oreder for second user");
	Thread.sleep(5000);
	Assert.assertEquals(popHeader.getText(), "Cart Edited By");
	System.out.println("Pop Up Header: "+popHeader.getText());
	System.out.println("The message in pop body is: "+popMesage.getText());
	Assert.assertTrue(Exit.isDisplayed());
	Assert.assertTrue(Continue.isDisplayed());
	Exit.click();
	
}

public void offRoutePopupnew(WebDriver driver,String countryName) throws Exception   //Ruth
{
try{
int count = driver.findElements(By.cssSelector("#emergency-check-submit")).size();

if(countryName.equalsIgnoreCase("CAN"))
{
	if ((!(count == 0))&&(PopUp_ContinueButton.isDisplayed())) 
	{
		Assert.assertEquals(PopUp_Header.getText(), "Off Route Order (Thank-you for your order!)");
		PopUp_ContinueButton.click();
		prntResults("Clicked on Continue Button");
	}
	else{
			prntResults("It is an On-Route Order");
		}
}
else
{
	if ((!(count == 0))&&(PopUp_ContinueButton.isDisplayed())) 
	{
		//Assert.assertEquals(PopUp_Header.getText(), "Off Schedule Order");
		//Assert.assertEquals(PopUp_question.getText(), "Is this an Off Schedule Order?");
		//Assert.assertTrue(PopUp_Yes.isSelected());
		PopUp_ContinueButton.click();
		prntResults("Clicked on Continue Button");
	}
	else{
		prntResults("It is an On-Route Order");
	}
}
}
catch(Throwable exception){
		//reports
		ErrorUtil.addVerificationFailure(exception);
		System.out.println("Failed: Not able to click on Off Route Continue");
		//prntResults("Failed: Not able to click on Off Route Continue");
		throw new Exception("Failed: Not able to click on Off Route Continue", exception);
		}
}


public void CreateOrder(WebDriver driver, String country) throws Exception{  //Ruth
try {
	String LabelText=Order_button.getText();
	prntResults("The label of the Order button present is:"+LabelText);
	Thread.sleep(3000);
	
	//==============To click on Create Order Button====//
	if(LabelText.equalsIgnoreCase("Create order"))
	{
		Order_button.click();
		prntResults("Clicked on Create Order Button");
		//driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		offRoutePopupnew(driver,country);
	}
	//====To click on Order In Progress Button=============//
	else {
		CancelOrder(driver);
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		Order_button.click();
		prntResults("Clicked Create Order Button");		
		offRoutePopupnew(driver,country);
	}
}
	catch(Exception e)
		{
		System.err.println("Failed to verify the Pop-Up, Possibly due to test data set up.");
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("Failed to verify the Pop-Up, please check the data set up.");
		}
}

public void Recompute_DaysofForecast(String Daysofforecast1,String Daysofforecast2) throws Exception
{
	Thread.sleep(2000);
	Days_Of_Forecast.click();
	Days_Of_Forecast.sendKeys(Keys.BACK_SPACE);
	Days_Of_Forecast.sendKeys(Keys.BACK_SPACE);
	Days_Of_Forecast.sendKeys(Daysofforecast2);
	Thread.sleep(2000);
	prntResults("Entered "+Daysofforecast2+" in Days of Forecast");
	Days_Of_Forecast.sendKeys(Keys.TAB);
	Thread.sleep(2000);
	Recompute_No.click();
	prntResults("Clicked on Donot re-calculate button");
	Thread.sleep(1000);
	Forecastchange_ConfirmButton.click();
	prntResults("Clicked on Confirm button");
	Thread.sleep(3000);
	Days_Of_Forecast.click();
	Days_Of_Forecast.sendKeys(Keys.BACK_SPACE);
	Days_Of_Forecast.sendKeys(Keys.BACK_SPACE);
	Thread.sleep(2000);
	Days_Of_Forecast.sendKeys(Daysofforecast1);
	prntResults("Entered "+Daysofforecast1+" in Days of Forecast");
	Thread.sleep(2000);
	Days_Of_Forecast.sendKeys(Keys.TAB);
	Thread.sleep(2000);
	Recompute_Yes.click();
	prntResults("Clicked on Yes re-calculate button");
	Thread.sleep(1000);
	Forecastchange_ConfirmButton.click();
	prntResults("Clicked on Confirm button");
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
	// Get the Load Event End
	long loadEventEnd = (Long) js.executeScript("return window.performance.timing.loadEventEnd;");
	// Get the Navigation Event Start
	long navigationStart = (Long) js.executeScript("return window.performance.timing.navigationStart;");
	// Difference between Load Event End and Navigation Event Start is Page Load Time
	System.out.println("Page Load Time is " + (loadEventEnd - navigationStart)/1000 + " seconds.");

}


@FindBy(xpath="//li/a[@class='selectboxit-option-anchor']/span")
public WebElement SelectItems_Dropdown;


public void selectOrders(WebDriver driver,String AverageSales)throws Exception {

	try
	{
		int items = driver.findElements(By.xpath("//li/a[@class='selectboxit-option-anchor']/span")).size();
		driver.findElement(By.xpath(".//*[@id='avgSaleSelectBoxItArrowContainer']")).click();
		for(int i = 1; i <= items; i++)
		{
			String myEle=driver.findElement(By.xpath("//li["+i+"]/a[@class='selectboxit-option-anchor']")).getText();
			if(myEle.contains(AverageSales))
			{
				driver.findElement(By.xpath("//li["+i+"]/a[@class='selectboxit-option-anchor']")).click(); 
				//Clicked on the index of the that has your label / value
				break;
		    }
		  }
		Thread.sleep(3000);
	}
	catch (Exception e){
		ErrorUtil.addVerificationFailure(e);
		prntResults("Failed: Validation of Orders in OrderHistory Page Failed");
		throw new Exception("Failed: Validation of Orders in OrderHistory Page Failed", e);
	}
}

public void verifyCT_PA_values_cartPage(WebDriver driver, String CT_value, String PA_value) throws Exception
{

	String locator = "//label[contains(.,'"+CT_value+"')]/following-sibling::label[contains(.,'"+PA_value+"')]";
	if(driver.findElement(By.xpath(locator)).isDisplayed())
	{
		prntResults("As Expected CT and PA values are displayed as "+ CT_value+" and "+PA_value +" in CartPage");
	}
	else{
		throw new Exception("Failed : As CT and PA values are displayed as "+ CT_value+" and "+PA_value +" in CartPage");
	}
	
}

public int getCurrent_CT_values_CartPage(WebDriver driver) throws Exception
{
	String current_CT_value = CT_value_CartPage.getAttribute("value");
	int current_CT_val = Integer.parseInt(current_CT_value);
	prntResults("The Current CT Value from Cartpage is : "+current_CT_val);
	return current_CT_val;
}


public void validateCT_PA_values_cartPage(WebDriver driver, String CT_value, String PA_value, String product_id1, String product_id2, String product_id3, String order_quantity1, String order_quantity2, String order_quantity3) throws Exception
{

	verifyCT_PA_values_cartPage(driver,CT_value, PA_value);
	prntResults("___________________________________________");
	Thread.sleep(3000);
	enter_OrderQuantity_forProduct(driver,product_id1,order_quantity1);
	verifygetCurrent_CT_values_CartPage(driver, CT_value, order_quantity1);
	CT_value =Integer.toString(getCurrent_CT_values_CartPage(driver));
	prntResults("___________________________________________");
	Thread.sleep(2000);
	//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	enter_OrderQuantity_forProduct(driver,product_id2,order_quantity2);
	Thread.sleep(3000);
	verifygetCurrent_CT_values_CartPage(driver, CT_value, order_quantity2);
	CT_value =Integer.toString(getCurrent_CT_values_CartPage(driver));
	prntResults("___________________________________________");
	Thread.sleep(2000);
	//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	enter_OrderQuantity_forProduct(driver,product_id3,order_quantity3);
	Thread.sleep(2000);
	verifygetCurrent_CT_values_CartPage(driver, CT_value, order_quantity3);
	CT_value =Integer.toString(getCurrent_CT_values_CartPage(driver));
	prntResults("___________________________________________");
	Thread.sleep(3000);

}

public void enter_OrderQuantity_forProduct(WebDriver driver, String product_id, String order_quantity) throws Exception
{
	String locator = ".//*[@id='cart-table']/tbody/tr/td[@id='"+product_id+"']/following-sibling::td[@class='order-qty col-order-qty']/span/input";
	Thread.sleep(3000);
	//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.findElement(By.xpath(locator)).clear();
	driver.findElement(By.xpath(locator)).sendKeys(order_quantity);
	Thread.sleep(2000);
	driver.findElement(By.cssSelector("body")).sendKeys(Keys.TAB);
	Thread.sleep(2000);
	prntResults("Successfully entered Order quantity as "+order_quantity+" for Product with Product_ID = "+product_id);
	Thread.sleep(4000);
}

public void verifygetCurrent_CT_values_CartPage(WebDriver driver, String CT_value, String order_quantity) throws Exception
{
	int val1= getCurrent_CT_values_CartPage(driver);	//get value from UI
	
	//calculate value
	int val2 = Integer.parseInt(CT_value);
	int val3 = Integer.parseInt(order_quantity);
	if(val1 == (val2-val3))
	{
		prntResults("As Expected The Calculated CT value and current CT value in Cartpage are same as : "+(val2-val3));
	}
	else
	{
		System.err.println("The Calculated CT value and current CT value in Cartpage are not same");
		throw new Exception("The Calculated CT value and current CT value in Cartpage are not same");
	}
}

public void verifyExciseMonitor_ErrorMessage(String exciseMonitor_errorMsg) throws Exception
{
	if(ExciseMonitor_ErrorMessage.getText().equalsIgnoreCase(exciseMonitor_errorMsg))
	{
		prntResults("As expected Error Pop is displayed as ' "+exciseMonitor_errorMsg+" '");
		exciseMonitor_error_amendOrder.click();
	}
	else{
		prntResults("The Error Pop is not displayed as ' "+exciseMonitor_errorMsg+" '");
		throw new Exception("The Error Pop is not displayed as ' "+exciseMonitor_errorMsg+" '");
	}
	Thread.sleep(3000);
	
}

public void amendOrder_for_negative_CT_Value(WebDriver driver, String product_id, String order_quantity ) throws Exception
{
	enter_OrderQuantity_forProduct(driver,product_id,order_quantity);
	int value = getCurrent_CT_values_CartPage(driver);
	if( value >= 0)
	{
		prntResults("As Expected The Current CT value is "+value+" and is Positive");
	}
	else
	{
		prntResults("Failed as The Current CT value is "+value+" and is Negative");
		throw new Exception("Failed as The Current CT value is "+value+" and is Negative");
	}
	Thread.sleep(3000);
}


}
