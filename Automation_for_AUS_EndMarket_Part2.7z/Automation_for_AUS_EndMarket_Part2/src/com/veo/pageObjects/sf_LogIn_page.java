package com.veo.pageObjects;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.veo.base.LocalTestBase;

public class sf_LogIn_page extends LocalTestBase {

	@FindBy(css="div.row > h1")
	public WebElement loginHeader;
	
	@FindBy(css = "a[href='#retailer']")
	public	WebElement SF_LoginPage_RetailerTab;

	@FindBy(name="j_username")
	public WebElement Retail_Username;

	@FindBy(name="j_password")
	public WebElement Retail_Password;

	@FindBy(id = "ageCheckboxRetailer") //Retailer page CheckBox
	public WebElement SF_LoginPage_RETAILERAgeCheckbox;
	
	@FindBy(id = "retailer-login-button") //Retailer page Login Button
	public WebElement SF_LoginPage_RETAILERLoginButton;
	
	@FindBy( xpath = "//a[@href='/login/pw/request-retailer']") // Clerk page Login Button
    public WebElement SF_LoginPage_ForgotPassword_Retailer;

	@FindBy(linkText = "Store Manager/Employee Login")
	public WebElement CAN_SF_LoginPage_ClerkTab;
	
	@FindBy(css="a[href='#clerk']")
	public WebElement SF_LoginPage_ClerkTab;
	
	@FindBy(id="clerk-email-address")
	public WebElement Clerk_Username;

	@FindBy(id="clerk-password")
	public WebElement Clerk_Password;
	
	@FindBy(id = "ageCheckboxClerk") // Clerk page CHeckBox
	public WebElement SF_LoginPage_CLERKAgeCheckbox;

	@FindBy(id = "clerk-login-button") // Clerk page Login Button
	public WebElement SF_LoginPage_CLERKLoginButton;

	@FindBy(css="#div-global-message-error>p")
	public WebElement Clerk_Disabled_login;

	@FindBy(css="#div-global-message-error>p")
	public WebElement Disabled_login_ErrTxt;

	@FindBy( xpath = "//section/a/h1/img")
	public WebElement SF_LoginPage_VeoImage;

	/******************************************************************
	 * This is the method to run the login
	 * @throws InterruptedException 
	 *******************************************************************/
	/*
	public void log_In(String EndMrkt,String userType,String username, String password) throws InterruptedException{
		//Assert.assertEquals(loginHeader.getText(), "Login");
		//if (userType.equalsIgnoreCase("Trusted Clerk")) { // for Clerk Login 
		//if(userType.equalsIgnoreCase("Engagement Clerk")||userType.equalsIgnoreCase("Trusted Clerk")||userType.equalsIgnoreCase("Fully Trusted Clerk")){
		if(userType.equalsIgnoreCase("Retailer")){
		
			Retail_Username.clear();
			Retail_Username.sendKeys(username);
			Retail_Password.sendKeys(password);
			SF_LoginPage_RETAILERAgeCheckbox.click();
			SF_LoginPage_RETAILERLoginButton.click();
		
		} 
		else
		{ // for Retail tab
			Retail_Username.clear();
			Retail_Username.sendKeys(username);
			Retail_Password.sendKeys(password);
			SF_LoginPage_RETAILERAgeCheckbox.click();
			SF_LoginPage_RETAILERLoginButton.click();
			Thread.sleep(2000);
			if(EndMrkt.equalsIgnoreCase("CAN")){
				CAN_SF_LoginPage_ClerkTab.click();
			} else
			{
				SF_LoginPage_ClerkTab.click();	
			}
			Clerk_Username.clear();
			Clerk_Username.sendKeys(username);
			Clerk_Password.sendKeys(password);
			SF_LoginPage_CLERKAgeCheckbox.click();
			SF_LoginPage_CLERKLoginButton.click();
		}

	}*/
	

	public void Clerk_Disabled_LogIn(String username, String password){
		SF_LoginPage_ClerkTab.click();
		Clerk_Username.sendKeys(username);
		Clerk_Password.sendKeys(password);
		SF_LoginPage_CLERKAgeCheckbox.click();
		SF_LoginPage_CLERKLoginButton.click();
		Assert.assertEquals(Clerk_Disabled_login.getText(),"There is an issue with your account, please contact your store manager.");
}


public void log_In(String userType,String username, String password) throws Exception
{
	if(userType.equalsIgnoreCase("Engagement Clerk")||userType.equalsIgnoreCase("Trusted Clerk")||userType.equalsIgnoreCase("FullyTrusted Clerk")){
		SF_LoginPage_ClerkTab.click();
		Clerk_Username.clear();
		Clerk_Username.sendKeys(username);
		Clerk_Password.sendKeys(password);
		SF_LoginPage_CLERKAgeCheckbox.click();
		SF_LoginPage_CLERKLoginButton.click();
		
	
	}
	else
	{
		SF_LoginPage_RetailerTab.click();
		Retail_Username.clear();
		
		//WebDriverWait wait = new WebDriverWait(driver, 30);
		//wait.until(ExpectedConditions.elementToBeClickable(Retail_Username));
		//System.out.println("Yeeeeeyyyyy found the Usr Name");
		
		Retail_Username.sendKeys(username);
		//wait.until(ExpectedConditions.elementToBeClickable(Retail_Password));
		Retail_Password.sendKeys(password);
		SF_LoginPage_RETAILERAgeCheckbox.click();
		SF_LoginPage_RETAILERLoginButton.click();
		/*JavascriptExecutor js = (JavascriptExecutor) driver;
		// Get the Load Event End
		long loadEventEnd = (Long) js.executeScript("return window.performance.timing.loadEventEnd;");
		// Get the Navigation Event Start
		long navigationStart = (Long) js.executeScript("return window.performance.timing.navigationStart;");
		// Difference between Load Event End and Navigation Event Start is Page Load Time
		prntResults("Page Load Time is " + (loadEventEnd - navigationStart)/1000 + " seconds.");
*/
	
	}
	prntResults("Login Successful");
}

public void Clerk_Disabled_LogIn(String CountryName,String UserType,String username, String password){
	if(UserType.equals("Retailer"))
	{
		Retail_Username.clear();	
		Retail_Username.sendKeys(username);
		prntResults("Entered Username as: "+username);
		Retail_Password.sendKeys(password);
		prntResults("Entered Password as: "+password);
		SF_LoginPage_RETAILERAgeCheckbox.click();
		prntResults("Clicked on Age CheckBox");
		SF_LoginPage_RETAILERLoginButton.click();
		prntResults("Clicked on Login Button");
		if(CountryName.equalsIgnoreCase("CAN"))
		{
		Assert.assertEquals(Disabled_login_ErrTxt.getText(),"Your account has been disabled, please contact your store manager.");
		}
		else if(CountryName.equalsIgnoreCase("AUS"))
		{
			Assert.assertEquals(Disabled_login_ErrTxt.getText(),"We have upgraded the security on Veo and this requires a password change. Your password requires a capital, a lower case, a number and a symbol and should be 8 characters or more. Please refer to your recent Veo email for further instructions.");
		}
		else
		{
			Assert.assertEquals(Disabled_login_ErrTxt.getText(),"Your account has been disabled, please contact your store manager.");
		}
	}
	else
	{
		SF_LoginPage_ClerkTab.click();
		Clerk_Username.sendKeys(username);
		prntResults("Entered Username as: "+username);
		Clerk_Password.sendKeys(password);
		prntResults("Entered Password as: "+password);
		SF_LoginPage_CLERKAgeCheckbox.click();
		prntResults("Clicked on Age CheckBox");
		SF_LoginPage_CLERKLoginButton.click();
		prntResults("Clicked on Login Button");
		if(CountryName.equalsIgnoreCase("CAN"))
		{
		Assert.assertEquals(Disabled_login_ErrTxt.getText(),"You have entered invalid password credentials, please try again");
		}
		else
		{
			Assert.assertEquals(Disabled_login_ErrTxt.getText(),"You have entered invalid password credentials, please try again");
		}
	}
}


}