package com.veo.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class hmc_Login_Page extends LocalTestBase{

@FindBy(css="#Main_user")
public WebElement hmc_LoginPage_Username;

@FindBy(css="#Main_password")
public WebElement hmc_LoginPage_Password;

@FindBy(css="#Main_label")
public WebElement hmc_LoginPage_LoginBtn;

@FindBy(css="div[id='Explorer[mcc]_label']")
public WebElement hmc_HomePage_Home;

public void Login_Hmc(String username, String password) throws Exception{
   
    try 
    {    
    	hmc_LoginPage_Username.clear();
    	hmc_LoginPage_Username.sendKeys(username);
		prntResults("Entered the Username");
		hmc_LoginPage_Password.clear();
		hmc_LoginPage_Password.sendKeys(password);
		prntResults("Entered the Password");
		hmc_LoginPage_LoginBtn.click();
		prntResults("Clicked on Login button");
		Thread.sleep(2000);
		boolean homebuttonPresence = hmc_HomePage_Home.isDisplayed();
		if(homebuttonPresence==true) 
		{
			prntResults("Loggedin Successfully as validation of Home Button in Homepage is Passed");
		}
    }
    catch (Throwable t) 
    {
		ErrorUtil.addVerificationFailure(t);			
		System.err.println("Failed: Failed to Login HMC");
		throw new Exception("Failed: Failed to Login HMC" ,t);	
    }
}

}
