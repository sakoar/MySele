package com.veo.pageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class bo_Login_Page extends LocalTestBase{

@FindBy(css="input[name='j_username']")
public WebElement bo_LoginPage_Username;

@FindBy(css="input[name='j_password']")
public WebElement bo_LoginPage_Password;

@FindBy(css="select[class='z-select']")
public WebElement bo_LoginPage_Lang_Selection;

@FindBy(css="*[class*='login_btn']")
public WebElement bo_LoginPage_LoginBtn;

@FindBy(css="button[class*='refresh z-button']")
public WebElement bo_RefreshBtn;

@FindBy(xpath="//span[contains(.,'Wrong credentials.')]")
public WebElement bo_WrongCrediatials;

public void Login_Backoffice(String username, String password) throws Exception
{
    try 
    {
    	Thread.sleep(3000);
    	bo_LoginPage_Username.clear();
    	bo_LoginPage_Username.sendKeys(username);
		prntResults("Entered the Username");
		bo_LoginPage_Password.clear();
		bo_LoginPage_Password.sendKeys(password);
		prntResults("Entered the Password");
		Thread.sleep(2000);
		bo_LoginPage_Password.sendKeys(Keys.TAB);
		prntResults("Clicked on TAB");
		Thread.sleep(2000);
		bo_LoginPage_LoginBtn.click();
		prntResults("Clicked on Login button");
		Thread.sleep(5000);
/*		boolean submitbuttonPresence = bo_RefreshBtn.isDisplayed();
		if(submitbuttonPresence==true) 
		{
			prntResults("Loggedin Successfully as validation of Refresh Button in Homepage is Passed");
		}*/
    }
    catch (Throwable t) 
    {
		ErrorUtil.addVerificationFailure(t);			
		prntResults("Failed: Failed to Login Backoffice");
		throw new Exception("Failed: Failed to Login Backoffice" ,t);	
    }
}

public void Backoffice_DisabledLogin(String username, String password) throws Exception
{
    try
    {    
    	bo_LoginPage_Username.clear();
    	bo_LoginPage_Username.sendKeys(username);
		prntResults("Entered the Username");
		bo_LoginPage_Password.clear();
		bo_LoginPage_Password.sendKeys(password);
		prntResults("Entered the Password");
		bo_LoginPage_Password.sendKeys(Keys.TAB);
		prntResults("Clicked on TAB");
		bo_LoginPage_LoginBtn.click();
		prntResults("Clicked on Login button");
		Thread.sleep(2000);
		boolean WrongCredentialsBox = bo_WrongCrediatials.isDisplayed();
		if(WrongCredentialsBox==true) 
		{
			prntResults("Not logged in to Backoffice ---- Disable Login is Passed !!!");
		}
    }
    catch (Throwable t)
    {
		ErrorUtil.addVerificationFailure(t);			
		//capturescreenshot(this.getClass().getSimpleName()+"_DisabledLogin");
		prntResults("Failed: Able to Login Backoffice");
		System.err.println("Failed: Able to Login Backoffice");
		throw new Exception("Failed: Able to Login Backoffice" ,t);	
    }
}

}