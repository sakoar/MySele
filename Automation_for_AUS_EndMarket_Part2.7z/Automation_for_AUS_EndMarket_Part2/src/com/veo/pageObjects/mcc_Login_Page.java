package com.veo.pageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class mcc_Login_Page extends LocalTestBase{

@FindBy(name="j_username")
public WebElement mcc_LoginPage_Username;

@FindBy(name="j_password")
public WebElement mcc_LoginPage_Password;

@FindBy(xpath="//input[@class='z-combobox-inp']")
public WebElement mcc_LoginPage_Lang_Selection;

@FindBy(xpath="//td[@class='z-button-cm']")
public WebElement mcc_LoginPage_LoginBtn;

@FindBy(css=".main_container>.one_area>.logo>img")
public WebElement mcc_HomePage_Logo;

@FindBy(css="span[class*='loginErrorLabel z-label']")
public WebElement mcc_LoginPage_WrongCredentials;


public void Login_Mcc(String username, String password) throws Exception{
   
    try 
    {    
    	mcc_LoginPage_Username.clear();
    	mcc_LoginPage_Username.sendKeys(username);
		prntResults("Entered the Username");
		Thread.sleep(1000);
		mcc_LoginPage_Password.clear();
		mcc_LoginPage_Password.sendKeys(password);
		prntResults("Entered the Password");
		Thread.sleep(1000);
		mcc_LoginPage_Password.sendKeys(Keys.TAB);
		prntResults("Clicked on TAB");
		Thread.sleep(1000);
		mcc_LoginPage_LoginBtn.click();
		prntResults("Clicked on Login button");
		Thread.sleep(2000);
		boolean submitbuttonPresence = mcc_HomePage_Logo.isDisplayed();
		if(submitbuttonPresence==true) 
		{
			prntResults("Loggedin Successfully as validation of Logo in Homepage is Passed");
		}
    }
    catch (Throwable t) 
    {
		ErrorUtil.addVerificationFailure(t);			
		//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("Failed: Failed to Login MCC");
		throw new Exception("Failed: Failed to Login MCC" ,t);	
    }

}

public void Mcc_DisabledLogin(String username, String password) throws Exception{
	   
    try 
    {    
    	mcc_LoginPage_Username.clear();
    	mcc_LoginPage_Username.sendKeys(username);
		prntResults("Entered the Username");
		mcc_LoginPage_Password.clear();
		mcc_LoginPage_Password.sendKeys(password);
		prntResults("Entered the Password");
		mcc_LoginPage_Password.sendKeys(Keys.TAB);
		prntResults("Clicked on TAB");
		mcc_LoginPage_LoginBtn.click();
		prntResults("Clicked on Login button");
		Thread.sleep(2000);
		boolean WrongCredentialsBox = mcc_LoginPage_WrongCredentials.isDisplayed();
		if(WrongCredentialsBox==true) 
		{
			prntResults("Not logged in to Mcc ---- Disable Login is Passed !!!");
		}
    }
    catch (Throwable t) 
    {
		ErrorUtil.addVerificationFailure(t);			
		//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("Failed: Able to Login MCC");
		System.err.println("Failed: Able to Login MCC");
		throw new Exception("Failed: Able to Login MCC" ,t);	
    }

}

}
