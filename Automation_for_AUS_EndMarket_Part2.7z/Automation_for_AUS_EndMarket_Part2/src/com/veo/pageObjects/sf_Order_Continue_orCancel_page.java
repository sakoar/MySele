package com.veo.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;

public class sf_Order_Continue_orCancel_page  extends LocalTestBase{

@FindBy(css="#ignore-soft-block")
public WebElement ignoreAndContinue_button;  

@FindBy(xpath="html/body/header/div/div/div[1]/a")
public WebElement Order_button; 

@FindBy(css="h1.text-center")
public WebElement CenterTextHome;

@FindBy(css="div.row > h1")
public WebElement CenterText_CreateOredr;

@FindBy(id="continue")
public WebElement Continue_button;

@FindBy(xpath="//*[@id='error-modal']/div/div/div[1]/h2")
public WebElement errorMsgHeadr;

@FindBy(xpath="//*[@id='error-modal']/div/div/div[2]/div/div[2]/p")
public WebElement errorMsgBody;

@FindBy(xpath="(//button[@type='submit'])[6]")
public WebElement errorMsgOkButn;

@FindBy(id="cancel")
public WebElement Cancel_button;

@FindBy(xpath="//*[@id='modal-cancel-order-block']/div/div/div[1]/h2")
public WebElement CancelOrdrPopUP;

@FindBy(xpath="//*[@id='modal-cancel-order-block']/div/div/div[3]/div/button")
public WebElement NoButton;

@FindBy(xpath="//*[@id='modal-cancel-order-block']/div/div/div[3]/div/a")
public WebElement YesButton;

@FindBy(id="save-exit")
public WebElement SaveExit_button;

@FindBy(xpath="//*[@id='modal-soft-block']/div/div/div[1]/h2")
public WebElement CanOrderPopUpHeader;

@FindBy(xpath=".//*[@id='modal-soft-block']/div/div/div[2]/div/div[2]/p[2]")
public WebElement CanOrderPopUpMsge;

@FindBy(xpath="//*[@id='button-soft-block-amend-order']")
public WebElement CanOrderPopUpChngeOrdrButn;

@FindBy(xpath="//*[@id='ignore-soft-block']")
public WebElement CanOrderPopUPIgnoreBtn;

public void ContinueOrder(WebDriver driver, String userType) throws Exception{
	Continue_button.click();
	prntResults("Clicked on Continue button");
	Thread.sleep(2000);
	
	if(userType.equalsIgnoreCase("Trusted Clerk")) 
	{
		try
		{
			Assert.assertEquals(errorMsgHeadr.getText(), "Not permitted");
			//Assert.assertEquals(errorMsgBody.getText(), "Your permissions do not allow you to submit an order.");
			Thread.sleep(2000);
		}
		catch(Exception e){
		e.printStackTrace();
		} 
		finally{
		errorMsgOkButn.click();
		prntResults("Clicked on Ok Button in Trusted Clerk Not Permitted Dialog Box");
		Thread.sleep(2000);
	
		Cancel_button.click();
		Thread.sleep(3000);
		//Assert.assertEquals(CancelOrdrPopUP.getText(),"Cancel order");
		//Thread.sleep(2000);
		YesButton.click();
		Thread.sleep(2000);
	}
}
	Thread.sleep(3000);
}


public void ContinueOrder(String userType) throws Exception{
	Continue_button.click();
	if(userType.equalsIgnoreCase("Trusted Clerk")) {
		Assert.assertEquals(errorMsgHeadr.getText(), "Not permitted");
		System.out.println(errorMsgHeadr.getText());
		Assert.assertEquals(errorMsgBody.getText(), "Your permissions do not allow you to submit an order.");
		System.out.println(errorMsgBody.getText());
		errorMsgOkButn.click();
		System.out.println("Clicked on the button");
		//CancelOrder();
		}
	else{
		System.out.println("Clicked on Continue button");	
	}
	
}

public void CanOrderPopUP() throws Exception{
	prntResults("Checking the Order pop up fro CAN");
	Assert.assertEquals(CanOrderPopUpHeader.getText(),"A few things we'd recommend looking at...");
	Assert.assertEquals(CanOrderPopUpMsge.getText(),"You are submitting your order outside your Ordering Window.");
	CanOrderPopUPIgnoreBtn.click();
	prntResults("Order pop-up checked, going to continue order");
}

public void CancelOrder(WebDriver driver) throws Exception
{
	if(Order_button.getText().equalsIgnoreCase("Order in progress"))
	{
		Order_button.click();
		Thread.sleep(3000);
	}
	
	Cancel_button.click();
	Thread.sleep(3000);
	Assert.assertEquals(CancelOrdrPopUP.getText(),"Cancel order");
	Thread.sleep(2000);
	YesButton.click();
	Thread.sleep(2000);
}

public void SavenExitOrder() throws Exception{
	SaveExit_button.click();
	Thread.sleep(2000);
	prntResults("Clicked on Save and Exit button");
}

}