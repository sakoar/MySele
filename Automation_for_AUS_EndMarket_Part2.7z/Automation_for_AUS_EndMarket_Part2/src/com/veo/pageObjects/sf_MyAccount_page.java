package com.veo.pageObjects;

import java.util.List;

import com.veo.base.LocalTestBase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class sf_MyAccount_page extends LocalTestBase {

@FindBy(css = ".row>h1")
public WebElement MyAccountPageHeader;

@FindBy(xpath = ".//*[@class='section']/h2[contains(text(),'Profile')]")
public WebElement MyAccountProfile;

@FindBy(xpath = ".//*[@class='section']/h2[contains(text(),'Store details')]")
public WebElement MyAccountStoreDetails;

@FindBy(id="my-account-menu")
public WebElement Home_Page_ManIcon;

@FindBy(xpath="//div/div[2]/nav/ul/li[1]/a/i")
public WebElement ManIcon_MyAccount_Button;

@FindBy(css = "#a-my-account-add-clerk")
public WebElement AddStoreAssistantButton;

@FindBy(css = "#clerk-firstname")
public WebElement FirstNameTextBox;

@FindBy(css = "#clerk-lastname")
public WebElement LastNameTextBox;

@FindBy(css = "#clerk-email")
public WebElement EmailIdTextBox;

@FindBy(css = "#clerk-telephone")
public WebElement TelephoneTextBox;

@FindBy(css = "#clerk-permissions1")
public WebElement FullyTrustedStoreAssistantRadioButton;

@FindBy(css = "#clerk-permissions2")
public WebElement TrustedStoreAssistantRadioButton;

@FindBy(css = "#clerk-permissions3")
public WebElement EngagementStoreAssistantRadioButton;

@FindBy(xpath = ".//*[@id='ageConfirmed' and @type='checkbox']")
public WebElement AgeConfirmCheckBox;

@FindBy(css = "#button-save-clerk")
public WebElement SaveButton;

@FindBy(css = "#div-global-message-information>p")
public WebElement ClerkCreationSuccessMessage;

@FindBy(css = "#showAllClerk")
public WebElement ShowAllClerkCheckBox;

@FindBy(xpath = ".//*[@class='veo-pale-blue']")
public WebElement AllStoreAssistants;

@FindBy(css = "[title='Edit notifications']")
public WebElement EditNotificationButton;

@FindBy(css = "#emailNotifications1")
public WebElement Email_CommunicationsCheckBox;

@FindBy(css = "#emailNotifications2")
public WebElement Email_AccountCheckBox;

@FindBy(css = "#emailNotifications3")
public WebElement Email_OrderConfirmationCheckBox;

@FindBy(css = "#emailNotifications4")
public WebElement Email_OrderReminderCheckBox;

@FindBy(css = "#smsNotifications1")
public WebElement SMS_AccountCheckBox;

@FindBy(css = "#smsNotifications2")
public WebElement SMS_OrderConfirmationCheckBox;

@FindBy(css = "#smsNotifications3")
public WebElement SMS_OrderReminderCheckBox;

@FindBy(xpath = ".//*[@id='edit-notification-form']/button")
public WebElement SaveEditNotificationButton;

@FindBy(css = "#div-global-message-information>p")
public WebElement NotificationUpdatedSuccessMessage;

@FindBy(xpath = ".//*[@href='/my-account/update-password']")
public WebElement ChangePassword;

@FindBy(css = "#current-password")
public WebElement CurrentPasswordTextBox;

@FindBy(css = "#new-password")
public WebElement NewPasswordTextBox;

@FindBy(css = "#confirm-password")
public WebElement ConfirmNewPasswordTextBox;

@FindBy(css = "#submit-customer-change-password")
public WebElement SaveNewPassword;

@FindBy(css = "#div-global-message-information>p")
public WebElement PasswordUpdatedSuccessMessage;

@FindBy(xpath=".//*[@id='retailer-clerks-table']/tbody")
public WebElement StoreAssistant_Table;

@FindBy(xpath="//button[contains(.,'Save')]")
public WebElement MyAccount_Save;

@FindBy(css="#showAllClerk")   
public WebElement Loyalty_MyAccount_ShowAllClerk_CheckBox;

@FindBy(css="#myaccount_status_validate")
public WebElement Loyalty_MyAccount_Validate_Button; 

@FindBy(css="div[id='clerk-validate']>div>div>form>div>button[id='emergency-check-button-cancel']")
public WebElement Loyalty_MyAccount_Validate_Cancel_Button; 

@FindBy(css="div[id='clerk-validate']>div>div>form>div>button[id='emergency-check-button-save']")
public WebElement Loyalty_MyAccount_Validate_Confirm_Button; 

@FindBy(css="#myaccount_status_active")
public WebElement Loyalty_MyAccount_Activate_Button; 

@FindBy(css="div[id='clerk-status-change']>div>div>form>div>button[id='emergency-check-button-cancel']")
public WebElement Loyalty_MyAccount_Activate_Cancel_Button; 

@FindBy(css="div[id='clerk-status-change']>div>div>form>div>button[id='emergency-check-button-save']")
public WebElement Loyalty_MyAccount_Activate_Save_Button; 

@FindBy(css="#myaccount_status_unactive")
public WebElement Loyalty_MyAccount_Deactivate_Button;

@FindBy(css="div[id='clerk-status-change']>div>div>form>div>button[id='emergency-check-button-cancel']")
public WebElement Loyalty_MyAccount_Deactivate_Cancel_Button; 

@FindBy(css="div[id='clerk-status-change']>div>div>form>div>button[id='emergency-check-button-save']")
public WebElement Loyalty_MyAccount_Deactivate_Save_Button; 

public void verifyMyAccountPage() throws Exception
{
	NavigateToMyAccountPage();
	if(!(MyAccountPageHeader.getText().equalsIgnoreCase("MY ACCOUNT")))
		throw new Exception("Failed to verify the My Account Header in  My Account Page");
	
	//if(!(MyAccountProfile.getText().equalsIgnoreCase("Profile")))
		//throw new Exception("Failed to verify the Profile in  My Account Page");
	
	//if(!(MyAccountStoreDetails.getText().equalsIgnoreCase("Store details")))
		//throw new Exception("Failed to verify the Store details in  My Account Page");

	prntResults("Successfully Verified My Accounts Page");
}

public void AddClerk(String firstname, String lastname, String emailid, String phoneno, String clerktype, String successmessage) throws Exception
{
	Home_Page_ManIcon.click();
	ManIcon_MyAccount_Button.click();
	Thread.sleep(2000);
	AddStoreAssistantButton.click();
	prntResults("Clicked on Store Assistant button");
	Thread.sleep(2000);
	FirstNameTextBox.clear();
	FirstNameTextBox.sendKeys(firstname);
	prntResults("Entered Firstname as "+firstname);
	LastNameTextBox.clear();
	LastNameTextBox.sendKeys(lastname);
	prntResults("Entered Lastname as "+lastname);
	EmailIdTextBox.clear();
	EmailIdTextBox.sendKeys(emailid);
	prntResults("Entered EmailID as "+emailid);
	TelephoneTextBox.clear();
	TelephoneTextBox.sendKeys(phoneno);
	prntResults("Entered Phone number as "+phoneno);
	
	if(clerktype.equalsIgnoreCase("Trustedclerk"))
	{
		TrustedStoreAssistantRadioButton.click();
		prntResults("Clicked on Trusted Store Assistant Radio Button");
	}
	else if(clerktype.equalsIgnoreCase("Engagementclerk"))
	{
		EngagementStoreAssistantRadioButton.click();
		prntResults("Clicked on Engagement Store Assistant Radio Button");
	}
	else if(clerktype.equalsIgnoreCase("FullyTrustedclerk"))
	{
		FullyTrustedStoreAssistantRadioButton.click();
		prntResults("Clicked on Fully Trusted Store Assistant Radio Button");
	}
	else{
		throw new Exception("Unknown Parameter passed");
	}
	AgeConfirmCheckBox.click();
	prntResults("Clicked on Age Confirm Checkbox");
	SaveButton.click();
	prntResults("Clicked on Save button");
	Thread.sleep(2000);
	if(!(ClerkCreationSuccessMessage.getText().equalsIgnoreCase(successmessage)))
	{
		throw new Exception("Failed : Successful Clerk Creation message is not displayed");
	}
	prntResults("Successfully Created the Store Assistant");
}

public void verifyActiveandDeactiveClerks(WebDriver driver) throws Exception
{
	Home_Page_ManIcon.click();
	ManIcon_MyAccount_Button.click();
	Thread.sleep(2000);
	int beforeassistants= driver.findElements(By.xpath(".//*[@class='veo-pale-blue']/tr")).size();
	ShowAllClerkCheckBox.click();
	prntResults("Clicked on Show All Clerk CheckBox");
	int afterassistants= driver.findElements(By.xpath(".//*[@class='veo-pale-blue']/tr")).size();
	prntResults("The number of Active Clerks are "+beforeassistants);
	prntResults("The number of Deactivated Clerks are "+(afterassistants-beforeassistants));
	prntResults("Successfully verified Activated and Deactived Clerks");
}


public void EditNotifications(String notifications_edited_message) throws Exception
{
	NavigateToMyAccountPage();
	EditNotificationButton.click();
	Thread.sleep(2000);
	Email_AccountCheckBox.click();
	SMS_AccountCheckBox.click();
	SaveEditNotificationButton.click();
	Thread.sleep(2000);
	if(!(NotificationUpdatedSuccessMessage.getText().equalsIgnoreCase(notifications_edited_message)))
	{
		prntResults("Failed : The Notification Updated success message is not displayed as Expected");
		throw new Exception("Failed : The Notification Updated success message is not displayed as Expected");
	}
	prntResults("Successfully Edited Notifications in My Accounts page");
}

public void ModifyPassword(String currentPassword, String newPassword, String successmessage) throws Exception
{
	NavigateToMyAccountPage();
	ChangePassword.click();
	prntResults("Clicked on Change Password link");
	Thread.sleep(2000);
	CurrentPasswordTextBox.clear();
	CurrentPasswordTextBox.sendKeys(currentPassword);
	prntResults("Entered Current Password");
	NewPasswordTextBox.clear();
	NewPasswordTextBox.sendKeys(newPassword);
	prntResults("Entered New Password");
	ConfirmNewPasswordTextBox.clear();
	ConfirmNewPasswordTextBox.sendKeys(newPassword);
	prntResults("Entered Confirm New Password");
	SaveNewPassword.click();
	prntResults("Clicked on Save Button");
	Thread.sleep(3000);
	if(!(PasswordUpdatedSuccessMessage.getText().equalsIgnoreCase(successmessage)))
	{
		throw new Exception("Failed : Successful Password updation message is not displayed");
	}
	prntResults("Successful Password updation message is displayed as "+successmessage);
}

public void NavigateToMyAccountPage(WebDriver driver) throws Exception
{
	Home_Page_ManIcon.click();
	ManIcon_MyAccount_Button.click();
	Thread.sleep(2000);
	
	if(driver.getTitle().equalsIgnoreCase("Error/Erreur 500"))
	{
		System.err.println('\n'+"Hello Human: Page responded with 500 error. This Could be a defect."+'\n'+"Please check the same.");
		prntResults('\n'+"Hello Human: Page responded with 500 error. This Could be a defect."+'\n'+"Please check the same.");
		throw new Exception('\n'+"Hello Human: Page responded with 500 error. This Could be a defect."+'\n'+"Please check the same.");
	}
	else{
		
	}
	prntResults("Successfully navigated to My Account page");
}

public void NavigateToMyAccountPage() throws Exception
{
	Home_Page_ManIcon.click();
	ManIcon_MyAccount_Button.click();
	Thread.sleep(2000);
	prntResults("Successfully navigated to My Account page");
}

public void ClerkValidation() throws Exception
{
	Loyalty_MyAccount_Validate_Button.click();
	prntResults("Clicked on Validate Button");
	Thread.sleep(2000);
	Loyalty_MyAccount_Validate_Cancel_Button.click();
	prntResults("Clicked on Cancel Button");  
	Thread.sleep(2000);
	Loyalty_MyAccount_Validate_Button.click();
	prntResults("Clicked on Validate Button");
	Loyalty_MyAccount_Validate_Confirm_Button.click();
	prntResults("Clicked on Confirm Button");
	Loyalty_MyAccount_Deactivate_Button.click();
	prntResults("Clicked on Deactivate Button");  
	Loyalty_MyAccount_Deactivate_Cancel_Button.click();
	prntResults("Clicked on Cancel Button");
	Thread.sleep(2000);
	Loyalty_MyAccount_Deactivate_Button.click();
	prntResults("Clicked on Deactivate Button");
	Loyalty_MyAccount_Deactivate_Save_Button.click();
	prntResults("Clicked on Save Button");
	Thread.sleep(2000);
	Loyalty_MyAccount_ShowAllClerk_CheckBox.click();
	prntResults("Clicked on ShowAllClerk CheckBox");
	Thread.sleep(2000);
	Loyalty_MyAccount_Activate_Button.click();
	prntResults("Clicked on Activate Button");
	Loyalty_MyAccount_Activate_Cancel_Button.click();
	prntResults("Clicked on Cancel Button");
	Thread.sleep(2000);
	Loyalty_MyAccount_Activate_Button.click();
	prntResults("Clicked on Activate Button");
	Loyalty_MyAccount_Activate_Save_Button.click();
	prntResults("Clicked on Save Button");
}

public void Deactivate_StoreAssistant(WebDriver driver, String CountryName,String Name_to_searchfor) throws Exception {

WebElement mytable = StoreAssistant_Table;			

// To calculate no of rows In table.
List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
int rows_count = rows_table.size();
prntResults("Number of clerk present/visible in MyAccount Page are  "+rows_count);
			
// To calculate no of columns In table			
List<WebElement> columns=rows_table.get(0).findElements(By.tagName("th"));			
prntResults("Number of columns:"+columns.size());			
prntResults("No of rows:"  + rows_count);

int i=1;

for (WebElement radio : rows_table) 
{
	System.out.println(radio.getText());
	System.out.println(i);
	int j = i;
	prntResults("J is :"+j);
	i = i + 1;
	if (radio.getText().contains(Name_to_searchfor)) 
	{
		// radio.click();
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,1000)", "");
		if(CountryName.equalsIgnoreCase("AUS")||CountryName.equalsIgnoreCase("NZ"))
		{
		int k = i-2;
		prntResults("KKK :"+k);
		driver.findElement(By.xpath(".//*[@id='status-select-" + k+ "SelectBoxIt']")).click();
		prntResults("Clicking on the Dropdown");
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//*[@id='status-select-" + k+ "SelectBoxItOptions']/li[2]/a")).click();
		prntResults("Clicked on Deactivate Account");

		}
		else
		{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//html/body/div[2]/div/div[3]/div[2]/form/table/tbody/tr["+j+"]/td[2]/ul/li[2]")).click();
		prntResults("Clicked on Deactivate Account");
		Thread.sleep(5000);
		}
		MyAccount_Save.click();
		prntResults("Clicking on Save button");
		prntResults("Deactivated the account for   " + Name_to_searchfor);
		break;
		}
	else 
	{
		if(i>rows_count)
		{
			prntResults("Couldnot find the searched Clerk name in My Account page to Deactivate   " + Name_to_searchfor);
		}
	}
}
}



}
