package com.veo.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class hmc_Home_Page extends LocalTestBase{

@FindBy(css="a[id*='Tree/GenericExplorerMenuTreeNode[user]_label']")
public WebElement hmc_HomePage_UserLink;

@FindBy(css="a[id*='Tree/GenericLeafNode[Employee]_label']")
public WebElement hmc_HomePage_User_Employee;

@FindBy(css="td[id*='Tree/GenericLeafNode[Employee]_null_null_label']")
public WebElement hmc_HomePage_User_Employee_Create;

@FindBy(xpath=".//*[@id='Tree/GenericLeafNode[Employee]_!create_Employee_label']")
public WebElement hmc_HomePage_Create_Employee;

@FindBy(css="input[id*='Content/StringEditor[in Content/Attribute[.uid]]_input']")
public WebElement hmc_HomePage_Create_Employee_Id;

@FindBy(css="input[id*='Content/StringEditor[in Content/Attribute[Employee.uid]]_input']")
public WebElement hmc_Search_Employee_Id;

@FindBy(css="input[id*='Content/StringEditor[in Content/Attribute[.name]]_input']")
public WebElement hmc_HomePage_Create_Employee_Name;

@FindBy(css="select[id*='Content/AllInstancesSelectEditor[in Content/Attribute[.sessionLanguage]]_select']")
public WebElement hmc_HomePage_Create_Employee_Lang;

@FindBy(css="input[id*='ajaxinput_Content/AutocompleteReferenceEditor[in Content/GenericItemList]']")
public WebElement hmc_HomePage_Create_Employee_Grp;

@FindBy(css="div[id*='Content/OrganizerCreatorSaveAndCopyToolbarAction[saveandcreate]_label']")
public WebElement hmc_Employee_Create_or_SaveLabel;

@FindBy(css="span[id*='Content/EditorTab[Employee.password]_span']")
public WebElement hmc_PwdTab;

@FindBy(css="input[id*='Content/EncryptedPasswordEditor_new']")
public WebElement hmc_PwdTab_NewPwd;

@FindBy(css="input[id*='Content/EncryptedPasswordEditor_repeat']")
public WebElement hmc_PwdTab_RepeatPwd;

@FindBy(css="a[id*='Content/OrganizerComponent[organizersearch][Employee]_togglelabel'][title='Search']")
public WebElement hmc_SeachLink;

@FindBy(css="input[id*='Content/StringEditor[in Content/GenericCondition[Employee.uid]]_input']")
public WebElement hmc_Seach_SearchID;

@FindBy(css="span[id*='Content/OrganizerSearch[Employee]_searchbutton']")
public WebElement hmc_Seach_SearchBtn;

@FindBy(css="td[class*='sorted']")
public WebElement hmc_SearchListID;

@FindBy(css="div[id*='Content/ImageToolbarAction[organizer.editor.save.title]']")
public WebElement hmc_Save_Label;

@FindBy(css="td[id*='Content/ClassificationOrganizerList[Employee]_!remove_true_label']")
public WebElement hmc_employee_Search_Remove;

@FindBy(css="td[class*='olcEmpty']")
public WebElement hmc_employee_Search_NoResultsFound;


public void Hmc_Employee_Deletion(WebDriver driver, String Modified_ID) throws Exception
{
	try
	{
		hmc_SeachLink.click();	//To Click On Search Link
		prntResults("Clicked On Search Link");

		hmc_Seach_SearchID.clear();
		hmc_Seach_SearchID.sendKeys(Modified_ID);	//To Provide Search ID
		prntResults("Given Search ID : "+Modified_ID);

		hmc_Seach_SearchBtn.click();	//To Click On Search Button
		prntResults("Clicked On Search Button");

		String locator = "//div/div[contains(.,'"+Modified_ID+"')]";
		String ResultsId = driver.findElement(By.xpath(locator)).getText();
		if(ResultsId.equals(Modified_ID))
		{
		    rightClick(driver,locator);
            Thread.sleep(3000);

            hmc_employee_Search_Remove.click();				
			isAlertPresent(driver);								   
			Thread.sleep(5000);	

			hmc_Seach_SearchID.clear();
			prntResults("Cleared the Search Field");		   
			hmc_Seach_SearchID.sendKeys(Modified_ID);
			prntResults("Search for the deleted Agent");

			hmc_Seach_SearchBtn.click();
			prntResults("Click on Search Button");

			if(!(hmc_employee_Search_NoResultsFound.getText().equalsIgnoreCase("The search was finished. No results were found.")))
		   {
			   prntResults("Failed!!! Validation of No results");
			   //capturescreenshot(this.getClass().getSimpleName()+"_Pic1");
				return;
			}
		   	prntResults("Success: Removed Account for Account Representative");
		   	prntResults("Account Representative Removed Account is: "+Modified_ID);
		}
		else
		{
			prntResults("Account is not Created for Account Representative");
			//capturescreenshot(this.getClass().getSimpleName()+"_Pic2");
			throw new Exception("Account is not Created for Account Representative");
		}
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		//capturescreenshot(this.getClass().getSimpleName()+"_Pic3");
		prntResults("FAILED --- Problem in deleting Employee in HMC, Please refer Screenshots"); 
		System.err.println("FAILED --- Problem in deleting Employee in HMC, Please refer Screenshots");
		throw e;
	}
}


public void Hmc_Employee_Modification(WebDriver driver,String old_ID,String New_ID) throws Exception
{
	try
	{
		hmc_SeachLink.click();	//To Click On Search Link
		prntResults("Clicked On Search Link");
		hmc_Seach_SearchID.clear();
		hmc_Seach_SearchID.sendKeys(old_ID);	//To Provide Search ID
		prntResults("Given Search ID : "+old_ID);
		hmc_Seach_SearchBtn.click();	//To Click On Search Button
		prntResults("Clicked On Search Button");
		String locator = "//div/div[contains(.,'"+old_ID+"')]";
		String ResultsId = driver.findElement(By.xpath(locator)).getText();

		if(ResultsId.equals(old_ID))
		{
			DoubleClick(driver,locator);	//DoubleClicked on Search List Results
			prntResults("Double Clicked on the Search List Results");
			hmc_Search_Employee_Id.clear();
			Thread.sleep(1000);
			hmc_Search_Employee_Id.sendKeys(New_ID);	//To Provide Id
			prntResults("Given ID: "+New_ID);	
			hmc_Save_Label.click();	//To Click on Save Button
			prntResults("Clicked on Save Button");
		}
		else
		{
			prntResults("Account is not modified for Account Representative");
			//capturescreenshot(this.getClass().getSimpleName()+"_Pic4");
			throw new Exception("Account is not modified for Account Representative");
		}
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e); 
		//capturescreenshot(this.getClass().getSimpleName()+"_Pic5");
		prntResults("FAILED --- Problem in modifing Employee in HMC"); 
		System.err.println("FAILED --- Problem in modifing Employee in HMC");
		throw new Exception("FAILED --- Problem in modifing Employee in HMC",e);
	}
}

public void Hmc_EmployeeCreation(WebDriver driver, String ID,String Name,String Language,String UserGroup,String NewPassword,String RepeatPassword) throws Exception
{
	try
	{
		hmc_HomePage_UserLink.click(); 
		prntResults("Clicked on User Link");
		rightClick(driver,"//a[@id='Tree/GenericLeafNode[Employee]_label']");
		prntResults("Right Clicked Employee");		 
		moveToElement(driver,hmc_HomePage_User_Employee_Create);	// Move to Create
		prntResults("Mouse hover the Create");
		hmc_HomePage_Create_Employee.click();	 
		prntResults("Clicked on Employee Option");
		Thread.sleep(3000);
		hmc_HomePage_Create_Employee_Id.clear();
		Thread.sleep(1000);
		hmc_HomePage_Create_Employee_Id.sendKeys(ID);	//To Provide Id
		prntResults("Given ID: "+ID);
		hmc_HomePage_Create_Employee_Name.clear();
		Thread.sleep(1000);
		hmc_HomePage_Create_Employee_Name.sendKeys(Name);	//To Provide Name
		prntResults("Given Name: "+Name);
		dropdownByVisibleText(driver,hmc_HomePage_Create_Employee_Lang, Language);	//To Select Language
		prntResults("Selected Language: "+Language);
		hmc_HomePage_Create_Employee_Grp.clear();
		hmc_HomePage_Create_Employee_Grp.sendKeys(UserGroup);	//To Add Groups
		Thread.sleep(1000);

		if(UserGroup.equalsIgnoreCase("CustomerService"))
		{
			hmc_HomePage_Create_Employee_Grp.sendKeys(Keys.ARROW_UP);
			hmc_HomePage_Create_Employee_Grp.sendKeys(Keys.ARROW_UP);
			hmc_HomePage_Create_Employee_Grp.sendKeys(Keys.ENTER);
			prntResults("Clicked on Enter");
			prntResults("Added Group is: "+UserGroup);
		}
		else
		{
		hmc_HomePage_Create_Employee_Grp.sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(1000);
		hmc_HomePage_Create_Employee_Grp.sendKeys(Keys.ENTER);
		prntResults("Added Group is: "+UserGroup);
		}
		Thread.sleep(4000);
		hmc_Employee_Create_or_SaveLabel.click();	//To Click on Create Button
		prntResults("Clicked on Create Button");
		Thread.sleep(4000);
		hmc_PwdTab.click();	//To Click on Password Tab
		prntResults("Clicked on Password Tab");
		hmc_PwdTab_NewPwd.clear();
		hmc_PwdTab_NewPwd.sendKeys(NewPassword);	//To Provide New Password
		prntResults("Given New Password: "+NewPassword);
		hmc_PwdTab_RepeatPwd.clear();
		hmc_PwdTab_RepeatPwd.sendKeys(RepeatPassword);	//To Provide Repeat Password
		prntResults("Given Repeat Password: "+RepeatPassword);
		hmc_Save_Label.click();	//To Click on Save Button
		prntResults("Clicked on Save Button");
		
	}
	catch(Exception e) 
	{
		ErrorUtil.addVerificationFailure(e);
		////capturescreenshot(this.getClass().getSimpleName()+"_Pic6");
		prntResults("FAILED --- Problem in Creating Employee in HMC"); 
		System.err.println("FAILED --- Problem in Creating Employee in HMC");
		throw e;
	}
}

@FindBy(xpath = ".//*[@id='Tree/GenericExplorerMenuTreeNode[cms2]_label']")
public WebElement Hmc_HomePage_WCMS;

@FindBy(xpath = ".//*[@id='Tree/GenericLeafNode[CMSSite]_label']")
public WebElement Hmc_HomePage_WebSites;

@FindBy(xpath = ".//*[@id='Content/OrganizerListEntry[GO Smart]_img']")
public WebElement Hmc_HomePage_Gomsartimage;

@FindBy(xpath = ".//*[@id='Content/EditorTab[CMSSite.tab.basesite.configuration]_span']")
public WebElement Hmc_HomePage_ConfigurationTab;

@FindBy(xpath = ".//*[@id='Content/DateTimeEditor[in Content/Attribute[CMSSite.startdate]]_time']")
public WebElement Hmc_HomePage_WCMS_Websites_StartDate;

@FindBy(xpath = ".//*[@id='Content/DateTimeEditor[in Content/Attribute[CMSSite.enddate]]_time']")
public WebElement Hmc_HomePage_WCMS_Websites_EndDate;

@FindBy(xpath = ".//*[@id='Content/ImageToolbarAction[organizer.editor.save.title]_label']")
public WebElement Hmc_HomePage_WCMS_Websites_Save;

@FindBy(xpath = ".//*[@id='Content/DateTimeEditor[in Content/Attribute[CMSSite.startdate]]_date']")
public WebElement Hmc_HomePage_WCMS_Websites_Config_StartDate;

@FindBy(xpath = ".//*[@id='Content/DateTimeEditor[in Content/Attribute[CMSSite.enddate]]_date']")
public WebElement Hmc_HomePage_WCMS_Websites_Config_EndDate;

@FindBy(xpath = ".//*[@id='Toolbar/ImageToolbarAction[closesession]_img']")
public WebElement Hmc_HomePage_LogOut;


public void Edit_WCMS_Websites_Start_End_Date(String datee, String newTime1, String newTime2) throws Exception
{

	Hmc_HomePage_WCMS.click();	
	prntResults("Clicked on WCMS");
	Hmc_HomePage_WebSites.click();
	prntResults("Clicked on Websites");
	Hmc_HomePage_Gomsartimage.click();
	Thread.sleep(3000);
	Hmc_HomePage_ConfigurationTab.click();	
	prntResults("Clicked on Configuration Tab");
	Thread.sleep(3000);
	////capturescreenshot(this.getClass().getSimpleName()+"_"+"newtime1");
	
	Hmc_HomePage_WCMS_Websites_Config_StartDate.clear();		
	Hmc_HomePage_WCMS_Websites_Config_StartDate.sendKeys(datee);
	prntResults("Entered Config Start date as "+datee);
	Hmc_HomePage_WCMS_Websites_Config_EndDate.clear();
	Hmc_HomePage_WCMS_Websites_Config_EndDate.sendKeys(datee);
	prntResults("Entered Config End date as "+datee);

	Hmc_HomePage_WCMS_Websites_StartDate.clear();
	Hmc_HomePage_WCMS_Websites_StartDate.sendKeys(newTime1);
	prntResults("Entered Start date as "+newTime1);

	Hmc_HomePage_WCMS_Websites_EndDate.clear();
	Hmc_HomePage_WCMS_Websites_EndDate.sendKeys(newTime2);
	prntResults("Entered End date as "+newTime1);
	//capturescreenshot(this.getClass().getSimpleName()+"_"+"newtime2");		

	Hmc_HomePage_WCMS_Websites_Save.click();
	prntResults("Clicked on Save Button");
	Thread.sleep(2000);
}


@FindBy(xpath=".//a[@id='Tree/GenericExplorerMenuTreeNode[b2bcommercegroup]_label']")
public WebElement hmc_HomePage_B2BCommerce;

@FindBy(xpath=".//a[@id='Tree/GenericLeafNode[B2BCustomer]_label']")
public WebElement hmc_B2B_Customer;

@FindBy(xpath=".//input[@id='Content/StringEditor[in Content/GenericCondition[B2BCustomer.uid]]_input']")
public WebElement hmc_B2B_Customer_ID_Textbox;

@FindBy(xpath=".//span[@id='Content/OrganizerSearch[B2BCustomer]_searchbutton']")
public WebElement hmc_B2B_Customer_Search_button;

@FindBy(xpath=".//*[@id='Content/ClassificationOrganizerList[B2BCustomer]_innertable']")
public WebElement hmc_B2B_Customer_Searched_Item;

@FindBy(xpath=".//*[@id='Content/EditorTab[B2BCustomer.password]_span']")
public WebElement hmc_B2B_Customer_Password_Tab;

@FindBy(xpath=".//*[@id='Content/EncryptedPasswordEditor_new']")
public WebElement hmc_B2B_Customer_Password_Textbox;

@FindBy(xpath=".//*[@id='Content/EncryptedPasswordEditor_repeat']")
public WebElement hmc_B2B_Customer_ConfirmPassword_Textbox;

@FindBy(xpath=".//*[@id='Content/ImageToolbarAction[organizer.editor.save.title]_label']/u")
public WebElement hmc_B2B_Customer_Save_Button;

@FindBy(xpath=".//*[@id='Toolbar/ImageToolbarAction[closesession]_img']")
public WebElement hmc_Logout_Button;

@FindBy(xpath=".//a[@id='Content/OrganizerComponent[organizersearch][B2BCustomer]_togglelabel']")
public WebElement hmc_B2B_Customer_Search_label;

@FindBy(xpath=".//*[@id='Content/ClassificationOrganizerList[B2BCustomer][delete]_img']")
public WebElement hmc_B2B_Customer_delete_user;

public void set_password_for_Users(WebDriver driver,String username,String password) throws Exception
{

	hmc_HomePage_B2BCommerce.click();
	hmc_B2B_Customer.click();
	hmc_B2B_Customer_ID_Textbox.clear();
	hmc_B2B_Customer_ID_Textbox.sendKeys(username);
	hmc_B2B_Customer_Search_button.click();
	DoubleClick_Element(driver,hmc_B2B_Customer_Searched_Item);
	Thread.sleep(3000);
	hmc_B2B_Customer_Password_Tab.click();
	Thread.sleep(5000);
	hmc_B2B_Customer_Password_Textbox.clear();
	hmc_B2B_Customer_Password_Textbox.sendKeys(password);
	hmc_B2B_Customer_ConfirmPassword_Textbox.clear();
	hmc_B2B_Customer_ConfirmPassword_Textbox.sendKeys(password);
	Thread.sleep(1000);
	hmc_B2B_Customer_Save_Button.click();
	Thread.sleep(3000);
	prntResults("Successfuly changed the password of "+username+" to "+password);
}

public void Delete_Users(WebDriver driver,String username) throws Exception
{
	Thread.sleep(2000);
	hmc_B2B_Customer_Search_label.click();
	Thread.sleep(2000);
	hmc_B2B_Customer_ID_Textbox.clear();
	hmc_B2B_Customer_ID_Textbox.sendKeys(username);
	hmc_B2B_Customer_Search_button.click();
	Thread.sleep(2000);
	hmc_B2B_Customer_Searched_Item.click();
	hmc_B2B_Customer_delete_user.click();
	Thread.sleep(2000);
	isAlertPresent(driver);
	Thread.sleep(2000);
	prntResults("Successfuly deleted the user "+username);
}
public void Cleanup_Data(WebDriver driver,String ID) throws Exception
{
	hmc_Seach_SearchID.clear();
	hmc_Seach_SearchID.sendKeys(ID);
	prntResults("Entered the ID in Search field");
	hmc_Seach_SearchBtn.click();
	prntResults("Clicked on Search Button");
	String locator = ".//*[@id='Content/ClassificationOrganizerList[Employee]_innertable']/tbody/tr[2]/td";
	String ResultsId = driver.findElement(By.xpath(locator)).getText();
	if(ResultsId.equals("The search was finished. No results were found."))
	{
		prntResults("The searched ID is already Deleted!!!!");
	}
	else
	{
		rightClick(driver,locator);
        Thread.sleep(3000);

        hmc_employee_Search_Remove.click();				
		isAlertPresent(driver);								   
		Thread.sleep(5000);	
	}
}
}
