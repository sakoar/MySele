package com.veo.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class bo_Logout_Page extends LocalTestBase{

@FindBy(xpath="//div[@class='z-div']/a[@class='z-toolbarbutton']/span")
public WebElement bo_logoutPage_Logout;

public void Backoffice_Logout() throws Exception {
	try 
	{
		Thread.sleep(2000);
		bo_logoutPage_Logout.click();
		prntResults("Clicked on Logout Button");
		prntResults("Logout Successfull");	
	}
	catch(Exception e)
	{
		capturescreenshot(this.getClass().getSimpleName()+"_Logout_Error");
		ErrorUtil.addVerificationFailure(e); 
		System.err.println("Not able to Amend the selected order"); 
		throw new Exception("Not able to Amend the selected order");
	}
}
}
