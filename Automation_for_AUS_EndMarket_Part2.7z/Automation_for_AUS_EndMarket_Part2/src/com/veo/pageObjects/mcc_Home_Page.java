package com.veo.pageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class mcc_Home_Page extends LocalTestBase{


@FindBy(css="a[href='/cmscockpit']")
public WebElement mcc_HomePage_WcmsLink;

@FindBy(css="a[href='/productcockpit']")
public WebElement mcc_HomePage_PCMLink;

@FindBy(css="a[href='/hmc/hybris?select=marketing']")
public WebElement mcc_HomePage_HMCLink;

@FindBy(name="j_username")
public WebElement cmsCockpit_userID_textbox;
	
@FindBy(name="j_password")
public	WebElement cmsCockpit_Password_textbox;

@FindBy(xpath="//input[@class='z-combobox-inp']")
public WebElement cms_LoginPage_Lang_Selection;

@FindBy(css=".z-button-cm")
public WebElement cmsCockpit_Login_button;

@FindBy(xpath="//tr/td[1]/div/a")
public WebElement cms_Home_icon;

@FindBy(name="j_username")
public WebElement PCM_userID_textbox;

@FindBy(name="j_password")
public	WebElement PCM_Password_textbox;

@FindBy(xpath="//input[@class='z-combobox-inp']")
public WebElement pcm_LoginPage_Lang_Selection;

@FindBy(css=".z-button-cm")
public WebElement PCM_Login_button;

@FindBy(xpath="//div[1]/div/table/tbody/tr/td[1]/div/a")
public WebElement PCM_Home_icon;

@FindBy(css="#Main_user")
public WebElement hmc_LoginPage_Username;

@FindBy(css="#Main_password")
public WebElement hmc_LoginPage_Password;

@FindBy(css="#Main_label")
public WebElement hmc_LoginPage_LoginBtn;

@FindBy(css="div[id='Explorer[mcc]_label']")
public WebElement hmc_HomePage_Home;

@FindBy(xpath="//a[contains(.,'Log out')]")
public WebElement mcc_HomePage_Logout;



public void mcc_DeployAgent_validation(WebDriver driver, String Username,String Pwd) throws Exception
{
	try
	{
		mcc_HomePage_WcmsLink.click(); 
		prntResults("Clicked on WCMS Link");
		Thread.sleep(3000);
		Login_CMS(Username,Pwd);
		prntResults("Success: Deployment Associate User is Logged in WCMS Cockpit");
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);

		mcc_HomePage_PCMLink.click();
		prntResults("Clicked on PCM Link");
		Thread.sleep(2000);
		Login_PCM(Username,Pwd);
		prntResults("Success: Deployment Associate User is Logged in PCM Cockpit");
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		mcc_HomePage_HMCLink.click();
		prntResults("Clicked on HMC Link");
		//Login_Hmc(Username,Pwd);
		boolean homebuttonPresence = hmc_HomePage_Home.isDisplayed();
		if(homebuttonPresence==true) 
		{
			prntResults("Loggedin Successfully as validation of Home Button in Homepage is Passed");
		}
		prntResults("Success: Deployment Associate User is Logged in HMC Cockpit");
		
		driver.navigate().back();
		Thread.sleep(2000);
		//driver.navigate().back();
		
		mcc_HomePage_Logout.click();
		Thread.sleep(2000);
		prntResults("Clicked On Logout Link");
	}
catch(Exception e) 
{
ErrorUtil.addVerificationFailure(e); 
//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
prntResults("Failed --- Validation of Deployment Agent"); 
System.err.println("Failed --- Validation of Deployment Agent");
throw e;
}
}

public void Login_CMS(String username, String password) throws Exception{
	   
    try 
    {    
    	cmsCockpit_userID_textbox.clear();
    	cmsCockpit_userID_textbox.sendKeys(username);
		prntResults("Entered the Username");
    	Thread.sleep(1000);
		cmsCockpit_Password_textbox.clear();
		cmsCockpit_Password_textbox.sendKeys(password);
		prntResults("Entered the Password");
    	Thread.sleep(1000);
		//driver.findElement(By.cssSelector("body")).sendKeys(Keys.TAB);
		cmsCockpit_Password_textbox.sendKeys(Keys.TAB);
		prntResults("Clicked on TAB");    	
		Thread.sleep(1000);
		cmsCockpit_Login_button.click();
		prntResults("Clicked on Login button");
    	Thread.sleep(2000);
    	boolean submitbuttonPresence = cms_Home_icon.isDisplayed();
		if(submitbuttonPresence==true) 
		{
			prntResults("Loggedin Successfully as validation of Menu in Homepage is Passed");
		}
    }
    catch (Throwable t) 
    {
		ErrorUtil.addVerificationFailure(t);			
		capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("Failed: Failed to Login CMS");
		throw new Exception("Failed: Failed to Login CMS" ,t);	
    }

}

public void Login_PCM(String username, String password) throws Exception{
   
    try 
    {    
    	PCM_userID_textbox.clear();
    	PCM_userID_textbox.sendKeys(username);
    	Thread.sleep(1000);
		prntResults("Entered the Username");
		PCM_Password_textbox.clear();
		PCM_Password_textbox.sendKeys(password);
    	Thread.sleep(1000);
		prntResults("Entered the Password");
		//driver.findElement(By.cssSelector("body")).sendKeys(Keys.TAB);
		PCM_Password_textbox.sendKeys(Keys.TAB);
		prntResults("Clicked on TAB");
    	Thread.sleep(1000);
		PCM_Login_button.click();
		prntResults("Clicked on Login button");
    	Thread.sleep(2000);
    	boolean submitbuttonPresence = PCM_Home_icon.isDisplayed();
    	Thread.sleep(2000);
		if(submitbuttonPresence==true) 
		{
			prntResults("Loggedin Successfully as validation of Menu in Homepage is Passed");
		}
    }
    catch (Throwable t) 
    {
		ErrorUtil.addVerificationFailure(t);			
		prntResults("Failed: Failed to Login PCM");
		throw new Exception("Failed: Failed to Login PCM" ,t);	
    }

}


public void Login_Hmc(String username, String password) throws Exception{
   
    try 
    {    
    	hmc_LoginPage_Username.clear();
    	hmc_LoginPage_Username.sendKeys(username);
		prntResults("Entered the Username");
		hmc_LoginPage_Password.clear();
		hmc_LoginPage_Password.sendKeys(password);
		prntResults("Entered the Password");
		hmc_LoginPage_LoginBtn.click();
		prntResults("Clicked on Login button");
		boolean homebuttonPresence = hmc_HomePage_Home.isDisplayed();
		if(homebuttonPresence==true) 
		{
			prntResults("Loggedin Successfully as validation of Home Button in Homepage is Passed");
		}
    }
    catch (Throwable t) 
    {
		ErrorUtil.addVerificationFailure(t);			
		//capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		prntResults("Failed: Failed to Login HMC");
		throw new Exception("Failed: Failed to Login HMC" ,t);	
    }

}

}
