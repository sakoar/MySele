package com.veo.pageObjects;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;


public class PCM_LogIn_page extends LocalTestBase{
		
	@FindBy(name="j_username")
	public WebElement PCM_userID_textbox;
	
	@FindBy(name="j_password")
	public	WebElement PCM_Password_textbox;

	@FindBy(css=".z-button-cm")
	public WebElement PCM_Login_button;
	
	@FindBy(xpath="//div[1]/div/table/tbody/tr/td[1]/div/a")
	public WebElement PCM_Home_icon;
	

	public void PMS_log_In(WebDriver driver, String username, String password) throws Exception
	{
		try
		{
			PCM_userID_textbox.clear();
			PCM_userID_textbox.sendKeys(username);
			prntResults("Entered Username "+username);
			PCM_Password_textbox.clear();
			PCM_Password_textbox.sendKeys(password);
			prntResults("Entered Password "+password);
			press_Tab_button(driver);
			PCM_Login_button.click();
			prntResults("Clicked on Login button");
			Thread.sleep(5000);
		}
		catch (Exception exception) 
		{
			System.err.println("Failed to Login to Product Cockpit");
			prntResults("Failed to Login to Product Cockpit");
			capturescreenshot(this.getClass().getSimpleName() + "_Login_Failed");
			throw new Exception("Failed to Login to Product Cockpit", exception);
		} 
	}

	


}
