package com.veo.pageObjects;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;


public class cms_LogIn_page extends LocalTestBase{
		
	/******************************************************************
	 * This is for log in
	 *******************************************************************/
	@FindBy(name="j_username")
	public WebElement cmsCockpit_userID_textbox;
	
	@FindBy(name="j_password")
	public	WebElement cmsCockpit_Password_textbox;

	@FindBy(css=".z-button-cm")
	public WebElement cmsCockpit_Login_button;
	
	@FindBy(xpath="//tr/td[1]/div/a")
	public WebElement cms_Home_icon;
	

	/******************************************************************
	 * This is the method to run the login
	 * @throws Exception 
	 *******************************************************************/
	public void cmsCockpit_log_In(WebDriver driver, String username, String password) throws Exception
	{
		try
		{
			cmsCockpit_userID_textbox.clear();
			cmsCockpit_userID_textbox.sendKeys(username);
			prntResults("Entered Username "+username);
			cmsCockpit_Password_textbox.clear();
			cmsCockpit_Password_textbox.sendKeys(password);
			prntResults("Entered Password "+password);
			press_Tab_button(driver);
			cmsCockpit_Login_button.click();
			prntResults("Clicked on Login button");
			if(cms_Home_icon.isDisplayed())
			{
				prntResults("Successfully logged into WCMS Cockfit");
			}
		}
		catch (Exception exception) 
		{
			System.err.println("Failed to Login to WCMS Cockpit");
			prntResults("Failed to Login to WCMS Cockpit");
			capturescreenshot(this.getClass().getSimpleName() + "_Login_Failed");
			throw new Exception("Failed to Login to WCMS Cockpit");
		} 
	}

}
