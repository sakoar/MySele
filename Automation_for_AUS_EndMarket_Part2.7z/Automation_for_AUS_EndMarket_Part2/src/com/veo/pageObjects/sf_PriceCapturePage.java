package com.veo.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class sf_PriceCapturePage extends LocalTestBase{
	
@FindBy(css=".row>h1")
public WebElement PriceCapture_Header;

@FindBy(css="a[href='/priceCapture/priceCapturePage']")
public WebElement PriceCapture_Button;

@FindBy(css="#error-modal>.modal-dialog.modal-xs>.modal-content>.modal-body.pb0>.text-icon>.text>p")
public WebElement EngagementClerk_PriceCapture_Error;

@FindBy(css="#error-modal>.modal-dialog.modal-xs>.modal-content>.modal-footer>.btn.btn-default.btn-sm.fr")
public WebElement EngagementClerk_PriceCapture_Error_OkBtn;

@FindBy(xpath="//a[@href='/priceCapture/priceCapturePage']")
public WebElement PriceCapture_Capture_SellingPrice;

@FindBy(css="#continue")
public WebElement PriceCapture_Continue_Button;

@FindBy(css="#cancel")
public WebElement PriceCapture_Cancel_Button;	

@FindBy(css=".btn.btn-default.btn-sm.fl")
public WebElement PriceCapture_Cancel_No_Button;	

@FindBy(xpath="//a[contains(.,'Yes')]")
public WebElement PriceCapture_Cancel_Yes_Button;

@FindBy(css="#actualPriceID0")
public WebElement PriceCapture_Quantity_Input0;	

@FindBy(css="#actualPriceID1")
public WebElement PriceCapture_Quantity_Input1;

@FindBy(css="#actualPriceID2")
public WebElement PriceCapture_Quantity_Input2;

@FindBy(css="#actualPriceID3")
public WebElement PriceCapture_Quantity_Input3;

@FindBy(css="#pricecapture-ignore-soft-block")
public WebElement PriceCapture_Ignore_and_Continue_Button;	

@FindBy(css="#submit")
public WebElement PriceCapture_Submit_Button;


public void EngagementClerk_PriceCapture() throws Exception {
	try
	{
		Assert.assertEquals(EngagementClerk_PriceCapture_Error.getText(), "Your permissions do not allow you to view price capture page");
		prntResults("Verified text in Not Permitted Dialog box for Engagement Clerk");
		EngagementClerk_PriceCapture_Error_OkBtn.click();
		prntResults("Clicked on OK Button in Not Permitted Dialog box for Engagement Clerk");
	}
	catch(Exception exception){
		System.err.println("Failed to verify Not Permitted Dialog box for Engagement Clerk");
		prntResults("Failed to verify Not Permitted Dialog box for Engagement Clerk");
		ErrorUtil.addVerificationFailure(exception);
		throw new Exception("Failed to verify Not Permitted Dialog box for Engagement Clerk", exception);
	}
}

public void Capture_PriceCapture() throws Exception
{	
	Thread.sleep(3000);
	PriceCapture_Capture_SellingPrice.click();
	Thread.sleep(3000);
}	

public void Cancel_PriceCapture() throws Exception
{		
	Thread.sleep(3000);
	PriceCapture_Cancel_Button.click();
	Thread.sleep(3000);
	PriceCapture_Cancel_No_Button.click();
	Thread.sleep(2000);
	PriceCapture_Cancel_Button.click();
	Thread.sleep(2000);
	PriceCapture_Cancel_Yes_Button.click();		
	prntResults("canceled Price Capture");
	Thread.sleep(3000);
}

public void Enter_PriceValues(String Volume) throws Exception
{
	Thread.sleep(2000);
	PriceCapture_Quantity_Input0.clear();
	PriceCapture_Quantity_Input0.sendKeys(Volume);
	Thread.sleep(2000);
	PriceCapture_Quantity_Input1.clear();
	PriceCapture_Quantity_Input1.sendKeys(Volume);
	Thread.sleep(2000);
	PriceCapture_Quantity_Input2.clear();
	PriceCapture_Quantity_Input2.sendKeys(Volume);
	Thread.sleep(2000);
	PriceCapture_Quantity_Input3.clear();
	PriceCapture_Quantity_Input3.sendKeys(Volume);
	prntResults("Enter PriceValues Price Capture");
	Thread.sleep(3000);
}

@FindBy(css="#pricecapture-ignore-soft-block")
public WebElement PriceCapture_ignoreAndContinue;


public void Submit_PriceCapture(WebDriver driver) throws Exception
{
	Thread.sleep(3000);
	PriceCapture_Continue_Button.click();
	Thread.sleep(3000);
	int ignorebutton = driver.findElements(By.cssSelector("#pricecapture-ignore-soft-block")).size();
	
	if(ignorebutton > 0)
	{
		PriceCapture_ignoreAndContinue.click();
		Thread.sleep(2000);
	}
	prntResults("submiting Price Capture");
}
}
