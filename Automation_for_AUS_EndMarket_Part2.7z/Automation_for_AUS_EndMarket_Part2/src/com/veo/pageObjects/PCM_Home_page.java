package com.veo.pageObjects;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;


public class PCM_Home_page extends LocalTestBase{
		

	@FindBy(xpath="//tr/td[1]/input")
	public WebElement PCM_Home_Searchbox;
	
	@FindBy(xpath="//tr/td[5]/span/table/tbody/tr[2]/td[2]/img")
	public	WebElement PCM_Home_SearchIcon;

	@FindBy(xpath="//tr/td[1]/input")
	public WebElement PCM_search_box;
	
	@FindBy(xpath="//td[5]/span/table/tbody/tr[2]/td[2]/img")
	public WebElement PCM_search_Icon;
	
	@FindBy(xpath="//div/div[2]/div[4]/div[1]/div[2]/div/div[1]/span")
	public WebElement PCM_searched_Item;
	
	@FindBy(xpath="//tr/td[1]/table/tbody/tr/td[5]/div/img[3]")
	public WebElement PCM_edit_Icon;
	
	@FindBy(xpath="//tr/td[3]/div/div/div/div/textarea")
	public WebElement PCM_edit_TextArea;
	
	@FindBy(xpath="//div[2]/div/div/div/div[2]/div[3]/div[1]/div[1]/div")
	public WebElement PCM_minimizeEditTextarea;

	public void searchProduct(WebDriver driver, String productID) throws Exception
	{
		PCM_Home_Searchbox.clear();
		PCM_Home_Searchbox.sendKeys(productID);
		Thread.sleep(3000);
		prntResults("Entered Product ID "+productID);
		PCM_Home_SearchIcon.click();
		prntResults("Clicked on Search Icon");
		Thread.sleep(3000);
			
	}

	public void editDescription(WebDriver driver, String new_ProductDesc) throws Exception
	{
		Thread.sleep(3000);
		PCM_searched_Item.click();
		prntResults("Clicked on Search result "+PCM_searched_Item.getText());
		Thread.sleep(3000);
		PCM_edit_Icon.click();
		prntResults("Clicked on Edit Icon");
		Thread.sleep(3000);
		PCM_edit_TextArea.clear();
		PCM_edit_TextArea.sendKeys(new_ProductDesc);
		Thread.sleep(3000);
		PCM_minimizeEditTextarea.click();
		Thread.sleep(3000);
	}

}
