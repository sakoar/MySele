package com.veo.pageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.veo.base.LocalTestBase;

public class sf_Products_Page extends LocalTestBase {

/***************************************************************************/

@FindBy(xpath=".//*[@id='page-content']/div/div[2]/div/div[1]/div[1]/div/span/ul/li[4]/a")
public WebElement products_showall_button;

@FindBy(xpath=".//*[@id='catalog-filter']")
public WebElement products_searchbar;

@FindBy(xpath="//div[@class='content']/p")
public WebElement product_content;

@FindBy(xpath=".//*[@id='products-details-lightbox']/div/div/div[1]/button[@class='close']")
public WebElement product_content_close;

public void searchProduct(WebDriver driver,String product_ID) throws Exception{

	Thread.sleep(2000);
	products_showall_button.click();
	prntResults("Clicked on Show all Button");
	Thread.sleep(2000);
	products_searchbar.clear();
	products_searchbar.sendKeys(product_ID);
	prntResults("Entered Product Id as :"+product_ID);
	Thread.sleep(2000);
	press_Enter_button(driver);
	Thread.sleep(2000);
	
}

public void verifyDescription(WebDriver driver,String product_ID, String new_ProductDesc) throws Exception{
	searchProduct(driver,product_ID);
	String locator = "//a[@data-id="+product_ID+" and contains(.,'Read More')]";
	driver.findElement(By.xpath(locator)).click();
	prntResults("Clicked on Read More");
	Thread.sleep(2000);
	if(product_content.getText().equalsIgnoreCase(new_ProductDesc))
	{
		prntResults("As expected the Product Description is edited");
	}
	else{
		prntResults("Failed as The Product Description is not edited");
		throw new Exception("Failed as The Product Description is not edited");
	}
	Thread.sleep(2000);
	product_content_close.click();
	prntResults("Clicked on Close button");
	Thread.sleep(4000);
}

}
