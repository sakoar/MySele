package com.veo.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class sf_MyProgramsPage extends LocalTestBase{

@FindBy(css=".row>h1")
public WebElement MyProgramPage_Header;

@FindBy(xpath="//h2[contains(.,'Acceptance')]//following-sibling::div/div/label//following-sibling::input[@id='acceptstatPending']")
public WebElement ListingPage_PendingCheckbox;

@FindBy(xpath="//h2[contains(.,'Acceptance')]//following-sibling::div/div/label//following-sibling::input[@id='acceptstatAccepted']")
public WebElement ListingPage_AcceptedCheckbox;

@FindBy(xpath="//h2[contains(.,'Program')]//following-sibling::div/label//following-sibling::input[@id='programstatIn Progress']")
public WebElement ListingPage_InProgressCheckbox;


public static String isCheckBoxChecked(WebElement locator) {

    prntResults("Checking if the checkbox related to '"+locator+"' is checked or not.");
   
    try {    
         //Assuming the objLocator contains xpath
        if (locator.isSelected()) 
        {
        	prntResults("Checkbox related to: '"+locator+"' is checked.");           
        }else
        {
        	prntResults("Checkbox related to: '"+locator+"' is not checked!!");           
            return "Fail" + ": Checkbox related to: '"+locator+"' is not checked!!";
        }
    }
    catch (Throwable t) 
    {
    	prntResults("Error while Checking if the checkbox related to '"+locator+"' is checked or not. -" + t.getMessage());
        return "Fail"+": Error while Checking if the checkbox related to '"+locator+"' is checked or not. -" + t.getMessage();
    }
    return "Pass"+": Checkbox related to: '"+locator+"' is checked.";
}

public void Navigation_buttons_MyPrograms(WebDriver driver, String UserType,String MyProgram_Name) throws Exception{
	try{
		if(MyProgram_Name.equalsIgnoreCase("Listing Page")&&(UserType.equalsIgnoreCase("Retailer")|| UserType.equalsIgnoreCase("FullyTrusted Clerk")))
		{
			Assert.assertTrue(MyProgramPage_Header.isDisplayed());
			Assert.assertEquals(MyProgramPage_Header.getText(),"MY PROGRAMS");
			isCheckBoxChecked(ListingPage_AcceptedCheckbox);
			isCheckBoxChecked(ListingPage_InProgressCheckbox);
		}
		else if(MyProgram_Name.equalsIgnoreCase("Tracking Page")&&(UserType.equalsIgnoreCase("Retailer")|| UserType.equalsIgnoreCase("FullyTrusted Clerk")))
		{
			Assert.assertTrue(MyProgramPage_Header.isDisplayed());
			Assert.assertEquals(MyProgramPage_Header.getText(),"MY PROGRAM PERFORMANCE");
			int ProgramCount = driver.findElements(By.xpath(".//*[@id='accordion']/li")).size();
			prntResults("No.Of.Programs in Tracking Page is :"+ProgramCount);
	    
			for(int i=1;i<=ProgramCount;i++)
			{
				String ProgramHeader = driver.findElement(By.xpath(".//*[@id='accordion']/li["+i+"]/div[2]/h2")).getText();
				prntResults(i+ " Program header is : "+ProgramHeader);
				String Status = driver.findElement(By.xpath(".//*[@id='accordion']/li["+i+"]/div[2]/p[2]/strong")).getText();
				prntResults(i+" Program Status is :"+Status);
				String daysRemaining = driver.findElement(By.xpath(".//*[@id='accordion']/li["+i+"]/div[2]/p[4]")).getText();
				prntResults(i+" Program - Days Remaining :"+daysRemaining);
				String brands = driver.findElement(By.xpath(".//*[@id='accordion']/li["+i+"]/div[2]/p[5]")).getText();
				prntResults(i+" Program - Brands :"+brands);
			}
		}
		else
			prntResults("Validating My Programs for "+UserType);
	}
	catch(Exception e)
	{
		System.err.println("Failed to do validation in My Programs ->"+MyProgram_Name+" Page");
		capturescreenshot(this.getClass().getSimpleName()+"_"+count);
		ErrorUtil.addVerificationFailure(e);
		throw new Exception("Failed to do validation in My Programs ->"+MyProgram_Name+" Page", e);
	}
}

}
