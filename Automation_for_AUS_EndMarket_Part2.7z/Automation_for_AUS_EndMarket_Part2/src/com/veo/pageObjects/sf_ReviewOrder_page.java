package com.veo.pageObjects;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;

public class sf_ReviewOrder_page extends LocalTestBase{
	
	@FindBy(css="h2.upper.large  > span")
	public WebElement ReviewOrderPage;
	
	@FindBy(xpath="//div[@id='page-content']/div/div[2]/div[2]/div[2]/dl[2]/dd")
	public WebElement estimatedTotal;
	
	@FindBy(xpath="//*[@id='total-cost-0']")
	public WebElement eachItemCost;
	
	@FindBy(id="review-success-place-order")
	public WebElement PlaceOrderButton;
	
	@FindBy(id="button-review-amend-order")
	public WebElement ChangeOrder;
	
	@FindBy(css="#continue")
	public WebElement Order_Continue;

	@FindBy(css="#dd-order-code")
	public WebElement OrderNo;
	
	public void ReviewPageVerification(){
		Assert.assertEquals("REVIEW ORDER", ReviewOrderPage.getText());
	}
	
	public void PlacingOrder() throws Exception{
		PlaceOrderButton.click();
		prntResults("Clicked on Place Order button");
		Thread.sleep(5000);
	}
	
	public void reviewPageChangeOrder() throws Exception{
		ChangeOrder.click();
		Thread.sleep(2000);
	}
	

    public String Checkout(WebDriver driver) throws Exception
    {
		String Order_No="";
		try
		{
			Order_Continue.click();
			ignoreAndContinue(driver);
			Thread.sleep(3000);
			PlacingOrder();
			Thread.sleep(3000);
			Order_No=OrderNo.getText();
			prntResults("Successfully Placed an Order !!!");
			prntResults("Order Number is : "+Order_No);
		}
		catch(Exception e)
		{
			System.err.println("Failed to verify the Pop-Up, Possibly due to test data set up.");
			ErrorUtil.addVerificationFailure(e);
            throw new Exception("Failed to verify the Pop-Up, please check the data set up.", e);
		}
		return Order_No;
    }

}
