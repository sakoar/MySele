package com.veo.pageObjects;

import java.awt.Robot;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

//import com.sun.glass.events.KeyEvent;
import com.veo.base.LocalTestBase;
import com.veo.util.ErrorUtil;
import com.veo.util.TestUtil;

public class Google_Analytics_Page extends LocalTestBase{

@FindBy(xpath=".//*[@id='identifierId']")
public WebElement GA_Username;

@FindBy(xpath=".//*[@id='next']")
public WebElement GA_Next;

@FindBy(xpath=".//*[@id='password']/div[1]/div/div[1]/input")
public WebElement GA_Password;

@FindBy(xpath=".//*[@id='signIn']")
public WebElement GA_SignIn_button;

@FindBy(css=".C_TITLE_PRIMARY_RAW")
public WebElement GA_Audience_Overview;

@FindBy(xpath="//ng-include/span[contains(.,'Audience')]")
public WebElement GA_Audience;

@FindBy(xpath="//ng-include/span[contains(.,'Behavior')]")
public WebElement GA_Behavior;

@FindBy(xpath="//span[contains(.,'Site Content')]")
public WebElement GA_Site_Content;

@FindBy(xpath="//span[contains(.,'All Pages')]")
public WebElement GA_Site_Content_AllPages;

@FindBy(xpath=".//*[@id='ID-rowTable']/tbody/tr")
public WebElement GA_table_AllPages;

@FindBy(xpath="html/body/div[1]/div[2]/div/div[2]/div/div[5]/div[2]/div/div/div/div[2]/div/div[1]/div[3]/div/div[2]/div[3]/div[3]/div[1]/div/span[1]/span[1]/select")
public WebElement GA_Dropdown;

@FindBy(xpath="html/body/div[1]/div[1]/div[2]/div[2]/form/div[2]/div/div[2]/div[1]/content")
public WebElement GA_EmailNext_Button;

@FindBy(xpath="html/body/div[1]/div[1]/div[2]/div[2]/form/div[2]/div/div/div[2]/div[1]/content/span")
public WebElement GA_PasswordNext_Button;



public void login_to_GoogleAnalytics(WebDriver driver, String username, String password) throws Exception
{

		driver.get("https://accounts.google.com/ServiceLogin");
		Thread.sleep(3000);
		GA_Username.clear();
		GA_Username.sendKeys(username);
		prntResults("Entered the Username");
		GA_EmailNext_Button.click();
		prntResults("Clicked Next button");
		Thread.sleep(3000);	
		
		GA_Password.sendKeys(password);			
		prntResults("Entered the Password");
		GA_PasswordNext_Button.click();
		prntResults("Clicked on Signin button");
		Thread.sleep(5000);
		driver.get("https://analytics.google.com/analytics/web");
		Thread.sleep(5000);

		if(GA_Audience_Overview.isDisplayed())
		{
			prntResults("Successfully Launched Google analytics Site");
		}
		else{
			prntResults("Failed: Failed to Launch Google analytics Site");
			throw new Exception("Failed: Failed to Launch Google analytics Site");
		}
		Thread.sleep(3000);
}


public void page_visitReport(WebDriver driver, String dropdown_value) throws Throwable
{
	Thread.sleep(3000);
	GA_Audience.click();
	Thread.sleep(2000);
	GA_Behavior.click();
	prntResults("Clicked on Behavior");
	Thread.sleep(2000);
	GA_Site_Content.click();
	prntResults("Clicked on Site Content");
	GA_Site_Content_AllPages.click();
	prntResults("Clicked on All Pages");
	Thread.sleep(4000);

	Actions actions2 = new Actions(driver);
	actions2.sendKeys(Keys.PAGE_DOWN).perform();	
	prntResults("Navigated to End of Page Successfully");
		
	dropdownByValue(driver,GA_Dropdown,dropdown_value);
	Thread.sleep(4000);
	moveToElement(driver, GA_Dropdown);

	int size = driver.findElements(By.xpath(".//*[@id='ID-rowTable']/tbody/tr")).size();	
	for(int i=1;i<=size;i++)
	{
		if(!(i==size))
		{
			Thread.sleep(2000);
			String contents = driver.findElement(By.xpath("//div[@class='_GAvE ID-explorer-table-dataTable-key-0-"+i+"']")).getText();
			Thread.sleep(2000);
			TestUtil.writePageVisitReport1(Reporting_Veo_XLS, "WebAnalytics_Report", i+1, contents);
			Thread.sleep(2000);
			String contents2 = driver.findElement(By.xpath(".//*[@id='ID-rowTable']/tbody/tr["+i+"]/td[4]")).getText();
			Thread.sleep(2000);
			TestUtil.writePageVisitReport2(Reporting_Veo_XLS, "WebAnalytics_Report", i+1, contents2);
		}
	}
	prntResults("Page Visit report is successfully written in Excel");
}




}
