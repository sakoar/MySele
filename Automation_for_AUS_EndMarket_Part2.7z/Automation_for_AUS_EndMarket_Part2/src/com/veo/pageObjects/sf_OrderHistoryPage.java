package com.veo.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.veo.base.LocalTestBase;

public class sf_OrderHistoryPage extends LocalTestBase {
	
@FindBy(xpath=".//*[@id='retailer-clerks-table']/tbody")
public WebElement StoreAssistant_Table;

@FindBy(xpath=".//*[@id='history-table']/tbody/tr[1]/td[1]/div/a")
public WebElement OrderHistory_Order1;

}
